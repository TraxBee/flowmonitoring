export STAGING_DIR=/media/sunny/work/f1c100s_sdk/host/arm-buildroot-linux-gnueabi/sysroot/
export CROSS_COMPILE=/media/sunny/work/f1c100s_sdk/host/bin/arm-buildroot-linux-gnueabi-
#export CROSS_COMPILE=/home/sunny/Documents/gcc-linaro-7.4.1-2019.02-x86_64_arm-linux-gnueabihf/bin/arm-linux-gnueabihf-


${CROSS_COMPILE}gcc -o test_skm lime2g_skm.c uart.c sunxi_gpio.c lcd_lime.c  -lpthread
${CROSS_COMPILE}gcc -o test_kam lime2g.c uart.c sunxi_gpio.c lcd_lime.c -lpthread
${CROSS_COMPILE}gcc -o demo demo.c sunxi_gpio.c  -lpthread
${CROSS_COMPILE}gcc -o nrf tft1.c sunxi_gpio.c -lpthread

#${CROSS_COMPILE}gcc -o test -I ${STAGING_DIR}usr/include/freetype2  uart.c sunxi_gpio.c lcd_lime.c framebuffer.c fblib.c lime2g.c log.c -lpthread -lfreetype

#sshpass -p "limepi123" rsync -a  terminus.ttf root@192.168.29.37:/tmp/mmc
#sshpass -p "limepi123" rsync -a  test_skm root@192.168.29.37:/tmp/mmc


#${CROSS_COMPILE}gcc -o https_arm https.c  -lpthread -lcrypto -lssl 
#${CROSS_COMPILE}gcc -o smwrite smwrite.c  -lpthread -lcrypto -lssl 
#gcc -o https_pc https.c  -lpthread -lcrypto -lssl 
#${CROSS_COMPILE}gcc -o mqtt traxbee.c  -lpthread -lmosquitto

${CROSS_COMPILE}gcc -o ctft tft1.c sunxi_gpio.c -lpthread
#${CROSS_COMPILE}gcc -o setmac setmac.c
#${CROSS_COMPILE}gcc -o wiegand wiegand.c
#${CROSS_COMPILE}gcc -o tiny tiny.c -lpthread
#${CROSS_COMPILE}gcc -o check_in check_internet.cpp -lstdc++

#echo "copyig to target.."
#sleep 1 
#sshpass -p "root" scp test root@192.168.1.1:/www
#sshpass  -p "root1234" scp test root@10.42.0.121:/tmp/mmc
#scp test_skm root@185.144.156.236:/var/www/html/test
#sshpass   scp gpio root@185.144.156.236:/var/www/html/
#sshpass  -p "limepi123" scp test_limepi root@192.168.212.235:/tmp/mmc
echo "Done!!"
#ls
#wget http://185.144.156.236/test -O /tmp/mmc/test;sync
#openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -sha256 -days 3650 -nodes -subj "/C=IN/ST=Gujarat/L=Vadodara/O=Traxbee/OU=Traxbee/CN=Traxbee.com"
