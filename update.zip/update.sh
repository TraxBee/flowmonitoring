sleep 20
sh -c  "date -s  \"`curl -s "http://worldtimeapi.org/api/timezone/Asia/Kolkata.txt" | grep -m1 datetime  | tail -c 33 | sed  's/T/ /g' | tr -s '\n' '\0'`\""
#sleep 10
touch /tmp/flash/etag.txt
while [ true ]
do
    #sh -c  "date -s  \"`curl -s "http://worldtimeapi.org/api/timezone/Asia/Kolkata.txt" | grep -m1 datetime  | tail -c 33 | sed  's/T/ /g' | tr -s '\n' '\0'`\""
    curl -fks  --etag-compare /tmp/flash/etag.txt    https://raw.githubusercontent.com/TraxBee/flowmonitoring/main/update.zip   -o /tmp/flash/update.zip
    file="/tmp/flash/update.zip"
    if [ -f "$file" ]
    then
        sh -c  "date -s  \"`curl -s "http://worldtimeapi.org/api/timezone/Asia/Kolkata.txt" | grep -m1 datetime  | tail -c 33 | sed  's/T/ /g' | tr -s '\n' '\0'`\""
        curl -fks  --etag-save /tmp/flash/etag.txt  https://raw.githubusercontent.com/TraxBee/flowmonitoring/main/update.zip   -I
        unzip -o /tmp/flash/update.zip  -d /root
        sync
        rm /tmp/flash/update.zip
        killall acs
        cp -rf /root/acs /tmp/
        sleep 2
    else
        echo "$file not found."
    fi
    sleep 15
done
