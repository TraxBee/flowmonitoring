#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <termios.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <linux/input.h>
#include <fcntl.h>
#include <sys/signal.h>
#include <features.h>
#include <math.h>
#include <pthread.h>
#include <linux/spi/spidev.h>
#include<linux/socket.h>
#include<arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include "lcd.h"
int CLIENT_TIMEOUT=2400;
#define FSIZE 2000
#define BUFSIZE 2048
#define RED puts("\e[38;2;255;0;0m");
#define GREEN puts("\e[38;2;0;255;0m");
#define BLUE puts("\e[38;2;0;0;255m");
#define YELLOW puts("\e[38;2;244;241;66m");
#define PINK puts("\e[38;2;244;66;113m");
#define ORANGE puts("\e[38;2;244;119;80m");
#define CLEAR puts("\e[0m");

//#define PCB_V1 1

//#define AUTO_RESET 1
#define MODEM_EN  1
//#define PROJ_MAHI 1
#define PROJ_KMD 1

#ifdef PROJ_MAHI
char ws_type=1; //weight-scale input type
#endif

#ifdef PROJ_KMD
char ws_type=0; //weight-scale input type
#endif
int client_abort=0;
char check_update=0;
char modem_type=0;
char session_format=1;
int kb_fd;
char keyboard_ok=1;
int free_ram=0;
char session_single_dp=0;
char rate_disable=0;
char modem_enable=0; 
int fmosi,fclk;
int print_ctrl;
int device=0;
int auto_reboot=0;
char print_opt;
char value_off='0';
char value_on='1';
const char  ws_text[][6] = {"Liter","Kg   "}; 
char ws_mode=0; //default Lt print/display
char lit_mode=0; // 000.0 or 000.00
char fat_only=0; //default fat & snf both input
char regional=0; //defualt english labels
char edit_rtc=0;
char edit_record=0;
char en_disp_rate = 0;
char usb_session=0;
char xhour;
char xmin;
char enable_wifi=0;
int sockfd_wifi;
int retval=1;
int pcycle=10; // set payment cycle = 10 days
void printer_send(int,char *,int);
#define KEY_HIGH   write(fkey,&value_on,1);
#define KEY_LOW    write(fkey,&value_off,1);
#define PRINT_CR   printer_send(uart1_fd,"\r\n",2);
#define PRINT_TB1  write(uart1_fd,"       ",7)
#define PRINT_TB2  write(uart1_fd,"       ",7)
#define PRINT_TB3  write(uart1_fd,"       ",7)
#define PRINT_SP   write(uart1_fd,"     ",5);
#define PRINT_EJECT      write(uart1_fd,EJECT,1);
const char *pDevice = "/dev/input/event0";
const char *wsrequest = "GET /wsredirectnew/wshttphandler.ashx HTTP/1.1\nOrigin: www.sample.com\nSec-WebSocket-Version: 13\nSec-WebSocket-Key: kGhlIHNhbXBsZSBub25jZQ==\nConnection: Upgrade\nHost: dpu.agdisk.com\nUpgrade: websocket\n\n";
int round1(float num)
{
    return num < 0 ? num - 0.5 : num + 0.5;
}
//#define M1_OFF  write(fmux1,&value_on,1);
//#define M2_OFF  write(fmux2,&value_on,1);

//#define M1_ON write(fmux1,&value_off,1);
//#define M2_ON write(fmux2,&value_off,1);

#define M1_ON  ;//write(fmux2,&value_on,1);
#define M2_ON  ;//write(fmux2,&value_on,1);

#define M1_OFF ;//write(fmux2,&value_off,1);
#define M2_OFF ;//write(fmux2,&value_off,1);

#ifdef PCB_V1
#define PT_OFF  write(print_ctrl,&value_off,1);
#define PT_ON   write(print_ctrl,&value_on,1);
#else
#define PT_ON   write(print_ctrl,&value_off,1);
#define PT_OFF  write(print_ctrl,&value_on,1);
#endif
//#define M1_ON  write(fmux1,&value_on,1);system("echo in > /sys/class/gpio/gpio27/direction");
//#define M2_ON  write(fmux2,&value_on,1);system("echo in > /sys/class/gpio/gpio17/direction");

//#define M1_OFF  system("echo out > /sys/class/gpio/gpio27/direction");write(fmux1,&value_off,1);
//#define M2_OFF  system("echo out > /sys/class/gpio/gpio17/direction");write(fmux2,&value_off,1);

#define EN_WSCALE   M2_ON;
#define EN_FAT      M2_ON;
#define EN_PRINT    M2_ON;
#define EN_GPRS     M2_ON;

#define GET_ID    1    //2,3 milk collection entry

#define SET_DPU   4
#define MASTER    15
#define SET_RTC   21 //19

#define SES_REP   24 //22

#define PAY_REP   37  //26 payment or bonus report
#define EDIT      43  //32 edit colletion data
#define LEDGER    47  //35

#define PASSWORD  60
#define USBMENU   64
#define PRINT_OK  70
#define DAIRY_REP 75
#define MEMBER    80 // EDIT or PRINT
#define COLLECTION     85 // Milk Collection or Deduction
#define SAVE_SESSION  95
#define INFO  102

/*

*/
unsigned int mmlist[2000]; // enable/disable list
char nstate []  =  {'N','C'};
unsigned char EJECT[] = {12,25,82};
unsigned char reset_password=0;
int reg_id[2000];  // maximum 2000 member

char labels[50][30]; // regional printing label

char network[6][5]  = {"BSNL","VODA","IDEA","AIRT","DOCO","RJIO"};
const char apn[][30] =  {"bsnlnet","www","internet","airtelgprs.com","TATA.DOCOMO.INTERNET","Jionet"};

const char month_str[][4] = {"JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"};

char dpu_settings[9][17];//syc buffer for settings file

float rate_chart[90][150];//110 BUF/MIX

float rate_chart2[90][150];//110 COW

pthread_t thread_analyzer;
int fmux1,fmux2,fkey;
int summery_buf_can,summery_cow_can;

int flag_scan=0;
float omc_lit,omc_fat,omc_snf;
float xomc_fat=0;
float xomc_snf=0;

char lit_dirty,fat_dirty;
char clit_dirty,cfat_dirty;
char dis_rate=1;
time_t t;
struct tm tm;
int fd;
unsigned char set_page=0;
char key_mode=0; //numeric
char key_pos=0;
int  kwait_feed=0;
unsigned char fstate=0;
unsigned char sstate=0;
char print_en=0;
char display_en=0;
char gprs_lock=1;
char entry_delete=0;
unsigned char con=0;
unsigned char mblink=0;
unsigned char home_counter=2;
int uart0_fd,uart1_fd,uart2_fd; //ttyS0 ttyS1 ttyS2


struct sigaction saio;
//unsigned char frame1[512];

unsigned char str[100];
pthread_t thread1;
char message[17];
char company_name[30];
char member_id[5];
char IMEI[17];
char scode[5];
unsigned int mid;
float bonus=1;

int rx1_bytes,nbyte;
unsigned char key=0;
unsigned char cmax=0;
unsigned long key_code;
unsigned char c[3];

int id;
int session;
int special_report=0;
int deduct_report=0;
int edit_mode=0;
int edit_pass=0;
int usb_inserted=0;
char temp_buf[400];
char temp_buf2[200];
char str_buf[200];
char manual_date[10];

char milk_type=0;
const char k1[] = {'A','B','C','1'};
const char k2[] = {'D','E','F','2'};
const char k3[] = {'G','H','I','3'};
const char k4[] = {'J','K','L','4'};
const char k5[] = {'M','N','O','5'};
const char k6[] = {'P','Q','R','6'};
const char k7[] = {'S','T','U','7'};
const char k8[] = {'V','W','X','8'};
const char k9[] = {'Y','Z',' ','9'};
int serial_open(const char *device, int rate);
void get_key(unsigned long key_code);
void print_options();
void load_rate_chart(unsigned char * filepath,char flag);
void load_rtc();
void load_settings();
void enable_regional();
void exit_regional();
void print_where();
void ask_mtype();
void print_passbook();
void system_call(char * cmd,char *output);
void system_call2(char * cmd,char *output);
void print_session_report( int mode,int session,int typ);
void print_payment_report(unsigned char * from,unsigned char * to);
void print_bonus_report(int mid,unsigned char * from,unsigned char * to);
void kbhit_wait();
unsigned char modem_status();
extern int set_speed (int fd, int speed);
extern int set_interface_attribs (int fd, int speed, int parity);
extern void set_blocking (int fd, int should_block);
extern int set_interface_attribs2 (int fd, int speed, int parity);
extern void set_blocking2 (int *fd, int should_block);
struct union_info
{
      float local_sale;
      float union_receipt;
      float milk_fat;
      float milk_snf;
      double lamount;
      double uamount;

};

struct union_info uinfo[2];
int union_index=0;

/*
void signal_handler_IO (int status)
{
       //c[0]=c[1]= c[2] = 0xff;
       //transfer(lcd_fd,c,c,3);
       //printf("KEY PRESSED: %02X %02X %02X \r\n",c[0],c[1],c[2]);
        //int nbyte;
        usleep(20000); // 5ms
	if(nbyte = read(uart1_fd,frame1,16))           //UART1:GPRS Modem
        {
                //puts("*\n");
        	rx1_bytes = nbyte;
        	while(nbyte || rx1_bytes<448) {nbyte = read(uart1_fd,&frame1[rx1_bytes],64); rx1_bytes +=nbyte; usleep(10000);}
        	frame1[rx1_bytes] =0;
                printf("%s\n",frame1);

            //key = frame1[0]; // simulate keyboard
        }
}
*/
int ws_write(int fd,unsigned char * buf,unsigned int size)
{
  unsigned char  ws_header[8];
  int ws_size,i;
  ws_header[0]=0x82;
  if(dpu_settings[6][15]=='Y') return 0;
  if(size <=125)
  {
      ws_header[1] = 0x80 | size;
      ws_header[2]= ws_header[3]=  ws_header[4]= ws_header[5]=0; //MASK
      ws_size=6;
  }
  else
  {
     ws_header[1] = 0x80 | 126;
     ws_header[2]= size >> 8;
     ws_header[3]= size & 0x00ff;
     ws_header[4]= ws_header[5]=  ws_header[6]= ws_header[7]=0;//MASK   
     ws_size=8;
  }
  if(enable_wifi==0)
  {
      puts("sending using modem....");
      write(fd,ws_header,ws_size); //ws header
      write(fd,buf,size);//payload
      sleep(1);
  }
  else
  {
      puts("sending using wifi....");
      while(sockfd_wifi<=0 || client_abort!=0)usleep(50000);
      if(sockfd_wifi>0)
      {
        write(sockfd_wifi,ws_header,ws_size); //ws header
        write(sockfd_wifi,buf,size);//payload      
        usleep(50000);//50000
      }
  }
}

unsigned char  frame1[2000];
unsigned char  output[500];
//int wfd;
FILE *wfd;
unsigned char xframe1[2024];
unsigned char xack[100];
unsigned char cmd_buf[128];
char flag_filedone=0; 
char download_started=0;


void * thread_uart0(void * ptr)  //modem data receive
{
   int i,offset;
   int nbyte;
   int nblock=0;
   int received_block=0;
   char sbuf[50];
   time_t t1;
   struct tm tm1;
   set_blocking(uart0_fd,1);
   while(nbyte = read(uart0_fd,frame1,16))           //UART1:GPRS Modem
   //while(1)
   {
            //puts("        rx isr 1");
            usleep(25000); // 5ms
            set_blocking(uart0_fd,0);
             
        	rx1_bytes = nbyte;
        	while(nbyte && rx1_bytes < 600) {nbyte = read(uart0_fd,&frame1[rx1_bytes],50); rx1_bytes +=nbyte;usleep(90000);if(flag_scan && rx1_bytes > 100 )break;}
        	frame1[rx1_bytes] =0;
            puts(frame1);
            if(rx1_bytes < 100) memcpy(cmd_buf,frame1,100);
            printf("gprs bytes=%d\r\n",rx1_bytes);
            if(flag_scan)
            {
            //puts(frame1);
            //printf("          len=%d %s\r\n",strlen(frame1),frame1);
            }
            //puts("\n");
            //for(i=0;i<rx1_bytes;i++) printf("%02X ",frame1[i]);
            //puts("\n");
            if(flag_scan ==0 )
            {
            if(frame1[1] == 126)offset = 4;
            else   offset =2;
            memcpy(xframe1,&frame1[offset],rx1_bytes-offset);
            memcpy(frame1,xframe1,rx1_bytes-offset);
            rx1_bytes -=offset; 
            frame1[rx1_bytes] =0;
            puts(frame1);
            }
            
                if(frame1[0] == '#' && frame1[1] == '#' && frame1[2] == '#' ) //###wpage=0,rpage=2048$$
                {
                    //--puts(frame1);
                }
            
                if(frame1[0] == '$' && frame1[1] == '$' && frame1[2] == '$' ) // file upload
                {
                   puts("receiving file....");//$$$CMD,0,1,ASLKDFJ
                   if(nblock >= 0)
                   {
                       sprintf(sbuf,"Received:%d-%d",received_block,nblock); lcd_puts(0,3,sbuf);  update_lcd();
                   }
                   gprs_lock=0;//clear server-command feed
                   switch(frame1[9])
                   {
                       case '9': // no. of file block 
                         nblock = atoi(&frame1[11]);
                         download_started=1;
                         received_block=0;
                         lcd_puts(0,0,"[Receiving File]");  update_lcd();
                         lcd_puts(0,2,"                ");  update_lcd();
                         //sprintf(xframe1,"I%s\r\n",IMEI);puts(xframe1);
                         //ws_write(uart0_fd,xframe1,strlen(xframe1));//ACK       
                         sprintf(xframe1,"#FACK I%s %s  G$$$CMD,GET_RATE%%%d\r\n",IMEI,IMEI,received_block);
                         strcpy(xack,xframe1);
                         ws_write(uart0_fd,xframe1,strlen(xframe1));
                         usleep(50000);
                         tcflush(uart0_fd,TCIOFLUSH);
                       break;
                       case '1': //first block
                           
                       case '5': // first & last blcok
                         if(frame1[9] == '1')received_block=0;
                         received_block++; 
                         //if(frame1[7]=='1'){system("rm /tmp/r1.zip");wfd = fopen("/tmp/r1.zip","wb");}
                         //else             
                         system("rm /tmp/r2.zip");wfd = fopen("/tmp/r2.zip","wb");
                         
                         //printf("DATA@0x153= %X\r\n",frame1[0x153]);
                         fwrite(&frame1[11],1,rx1_bytes-11,wfd);
                         printf("FIRST BLOCK %d\r\n",rx1_bytes-11);
                         
                         if(frame1[9] == '1'){sprintf(xframe1,"#FACK I%s %s  G$$$CMD,GET_RATE%%%d\r\n",IMEI,IMEI,received_block);puts(xframe1);}
                         else if(frame1[9]=='5'){sprintf(xframe1,"#FACK I%s %s G$$$CMD,GET_RATE\r\nDONE",IMEI,IMEI);puts(xframe1);nblock=0;}
                         usleep(100000);
                         strcpy(xack,xframe1);
                         ws_write(uart0_fd,xframe1,strlen(xframe1));//ACK
                         if(frame1[9]=='5')
                         {
                                        lcd_puts(0,1,"  [File Saved]  ");  update_lcd();
                                        nblock=0;
                                        fclose(wfd);
                                        printf("LAST BLOCK %d\r\n",rx1_bytes-11); 
                                        system_call2("unzip -t /tmp/r2.zip",output);
                                        if(strstr(output,"No errors detected in compressed data of /tmp/r2.zip")>0)
                                        {
                                            system("sync");
                                            system_call2("unzip -o /tmp/r2.zip -d /tmp/mmc",output);system("sync");  
                                            //system_call2("cp /tmp/dpu/test  /tmp/mmc/test",output);
                                            system("sync");
                                            //system_call2("rm /tmp/dpu/test",output);
                                            //system("sync");
                                            //get_server_cfg(1);//update server.cfg
                                            load_settings();
                                            //--load_rate_chart("/tmp/mmc/rate1.csv",0);   
                                            gprs_lock=100;
                                            flag_filedone=123;
                                            clear_lcd();lcd_puts(0,1,"DPU Rebooting...");update_lcd();
                                        }
                                       else
                                        {
                                            clear_lcd();lcd_puts(0,1,"DPU Rebooting...");lcd_puts(0,2,"Update Fail  ...");update_lcd(); 
                                        }
                                        system("reboot");
                                        //No errors detected in compressed data of /tmp/r2.zip.
                         }
                       break;
                       case '2': //n...data block
                       t1 = time(NULL);
		               tm1 = *localtime(&t1);
                       
                           received_block++;
                           if(wfd) fwrite(&frame1[11],1,rx1_bytes-11,wfd);
                           
                         printf("N BLOCK %d\r\n",rx1_bytes-11);
                         sprintf(xframe1,"#FACK I%s %s  G$$$CMD,GET_RATE%%%d\r\n",IMEI,IMEI,received_block);
                         tcflush(uart0_fd,TCIOFLUSH);
                         strcpy(xack,xframe1);
                         //usleep(100000);
                         ws_write(uart0_fd,xframe1,strlen(xframe1));  
                         printf("%02d:%02d:%02d\r\n",tm1.tm_hour, tm1.tm_min,tm1.tm_sec);
                         puts(xframe1);                       
                         //ws_write(uart0_fd,IMEI,strlen(IMEI));//ACK
                       break;
                       case '0': //last data block
                         received_block++;  
                         nblock=0;
                         lcd_puts(0,1,"  [File Saved]  "); update_lcd();  
                         if(wfd)fwrite(&frame1[11],1,rx1_bytes-11,wfd);
                         if(wfd)fclose(wfd);
                         printf("LAST BLOCK %d\r\n",rx1_bytes-11); 
                         /*
                         if(frame1[7] == '1') { system("sync");system_call2("unzip -o /tmp/r1.zip -d /tmp/dpu",output);system("sync");                        
                          
                          }
                         else if(frame1[7] == '2')
                         {
                             system("sync"); system_call2("unzip -o /tmp/r2.zip -d /tmp/dpu",output);system("sync");

                         }*/
                         system("sync"); 
                         system_call2("unzip -t /tmp/r2.zip",output);
                         if(strstr(output,"No errors detected in compressed data of /tmp/r2.zip")>0)
                         {
                            system_call2("unzip -o /tmp/r2.zip -d /tmp/mmc",output);system("sync");
                            //system_call2("cp /tmp/dpu/test  /tmp/mmc/test",output);system("sync");
                            //write(uart0_fd,output,100);                            
                            //if(strlen(frame1)>0) write(uart0_fd,"Invalid File\r\n",14); 
                                
                            //write(uart0_fd,dpu_settings[2],strlen(dpu_settings[2]));//ACK
                            sprintf(xframe1,"#FACK I%s %s G$$$CMD,GET_RATE\r\nDONE",IMEI,IMEI);puts(xframe1);
                            //write(uart0_fd,IMEI,strlen(IMEI));
                            //write(uart0_fd,"\r\nDONE",6);
                            ws_write(uart0_fd,xframe1,strlen(xframe1));
                            
                           // system_call2("cp /tmp/dpu/test  /tmp/mmc/test",output);
                            ///system("sync");
                            //system_call2("rm /tmp/dpu/test",output);
                            //system("sync");
                            
                            //get_server_cfg(1);//update server.cfg
                            load_settings();
                            //--load_rate_chart("/tmp/mmc/rate1.csv",0);
                            flag_filedone=123;
                            clear_lcd();lcd_puts(0,1,"DPU Rebooting...");update_lcd();
                            //if(dpu_settings[6][8] == 'Y')
                            // load_rate_chart("/tmp/dpu/rate2.csv",1);
                         }
                         else
                         {
                              clear_lcd();lcd_puts(0,1,"DPU Rebooting...");lcd_puts(0,2,"Update Fail  ...");update_lcd(); 
                         }
                         gprs_lock=100;
                         system("reboot");
                       break;
                   }
                   update_lcd();
                   
                   memset(frame1,0,611);
                }
                set_blocking(uart0_fd,1);
                //usleep(300000);//500ms
   }
   puts("!!!!!!!        Panic: UART Thread aborted         !!!!!!!!!!!!");
}
char  frame2[800];
int rx2_bytes;
int analyzer_stop=0;
void * thread_uart1(void * ptr) // Analyzer receive
{
   int i,device=0;
   int nbyte,retval;
   retval=1;
   
    if(uart1_fd)close(uart1_fd);     
    system("stty -F /dev/ttyS1 9600 min 0 time 5 -isig -icanon -iexten  -echok -echoctl -echoke -opost "); 
    //system("stty -F /dev/ttyS1 2400 -raw"); 
    usleep(500000);
    uart1_fd = open ("/dev/ttyS1", O_RDWR | O_NOCTTY | O_SYNC);    
    //--set_interface_attribs2 (uart1_fd,B2400,0);
    set_blocking(uart1_fd,0);
    //set_blocking(uart1_fd,0);
    usleep(400000);     
   //set_blocking(uart1_fd,1);  
   sleep(1);
   flag_scan=1;
   //pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
   while(1)
   {
      
       if(flag_scan)
       {
            puts("Analyzer data...1");
           
           usleep(20000);
        while(nbyte = read(uart1_fd,frame2,64)&&flag_scan)    
        //if(ioctl(uart1_fd, FIONREAD, &nbyte)>0 )
        {
             // 5ms
            usleep(150000);
            //nbyte = read(uart1_fd,frame2,nbyte);
            puts("Analyzer data...2");
            //puts(frame2);
            analyzer_stop=0;
            usleep(150000);
            //--set_blocking(uart1_fd,0);
            if(nbyte)
            {
            rx2_bytes = nbyte;

            
            while(nbyte>0 && rx2_bytes < 300) {nbyte = read(uart1_fd,&frame2[rx2_bytes],128); rx2_bytes +=nbyte;  usleep(250000); if(flag_scan==0)break;}
            
            frame2[rx2_bytes] =0;
            printf("nbyte=%d,rx2_bytes=%d,analyzer=%s\r\n",nbyte,rx2_bytes,frame2);

            }
            //tcflush(uart1_fd,TCIFLUSH);
            //usleep(400000);            
            //set_blocking2(uart1_fd,1);
            //--while(flag_scan==0){usleep(200000);}//wait for online mode..
            
            rx2_bytes=0;
        }
        //tcflush(uart1_fd,TCIFLUSH);
        tcflow(uart1_fd,TCOOFF);
        usleep(100000);
        tcflow(uart1_fd,TCOON);
       }
       else
       {
        //--tcflush(uart1_fd,TCIFLUSH);
        
        puts("................");
        usleep(200000);
        
        break;
       }
   }
   flag_scan=0;
   puts("\n\n\n\n *********************** Thread Exit Analyzer");
   close(uart1_fd); 
    //system("stty -F /dev/ttyS1 9600 min 0 time 5 -isig -icanon -iexten  -echok -echoctl -echoke -opost "); usleep(200000);
    //uart1_fd = open ("/dev/ttyS1", O_RDWR | O_NOCTTY | O_SYNC);  */  
   analyzer_stop=1;
   pthread_exit(&retval);

}

unsigned char  frame3[512];
int rx3_bytes;
char str_temp[200];
void * thread_uart2(void * ptr) // wscale receive
{
   int i,device=0;
   int nbyte;
   set_blocking(uart2_fd,1);
   while(nbyte = read(uart2_fd,frame3,16))           
   {
    usleep(15000); // 5ms
    
    if(flag_scan)
    {
     
      set_blocking(uart2_fd,0);
      rx3_bytes = nbyte;
      while(nbyte && rx3_bytes < 480) {nbyte = read(uart2_fd,&frame3[rx3_bytes],50); rx3_bytes +=nbyte;usleep(50000);}
      frame3[rx3_bytes] =0;    
      puts(frame3);
      set_blocking(uart2_fd,1);
    }
   }
}
int record_exist=0;

/*
float get_rate(float fat,float snf,int mid)
{
            int fi,si;

            if(fat < 0.5 ) fat = 0.5;
		    if(snf < 6.5 ) snf = 6.5;
            
	        if(fat > 12.5) fat =12.5;
            if(snf >12) snf = 12;

	        printf("%f:%f\n",fat,snf);

            if(fat >= 0.5) { fi = ( round1((float)(fat - 0.5)*10)); }
            else fi = 0;
	        if(snf >= 6.5) { si = (round1((float)(snf - 6.5)*10));  si++; }
            else si =1;


            if(dpu_settings[6][8]=='Y') //check buf/cow = Y/N ..?
            {
               if(mid <1000)
               {
                 return rate_chart[si][fi];  //buf milk
               }
               else
               {
                 return rate_chart2[si][fi]; //cow milk
               }
            }

            return rate_chart[si][fi]; //mix milk


}*/

float get_rate(float fat,float snf,int mid)
{
            int fi,si;

            if(fat < 0.5 ) fat = 0.5;
		    if(snf < 5.5 ) snf = 5.5;
            
	        if(fat > 12.5) fat =12.5;
            if(snf >12) snf = 12;

	        printf("%f:%f\n",fat,snf);

            if(fat >= 0.5) { fi = ( round1((float)(fat - 0.5)*10)); }
            else fi = 0;
	        if(snf >= 5.5) { si = (round1((float)(snf - 5.5)*10));  si++; }
            else si =1;


            if((dpu_settings[6][8]=='Y'||dpu_settings[6][8]=='S')) //check buf/cow = Y/N ..?
            {
               if(mid <1000)
               {
                 return rate_chart[si][fi];  //buf milk
               }
               else
               {
                 return rate_chart2[si][fi]; //cow milk
               }
            }

            return rate_chart[si][fi]; //mix milk


}

int  member_active(int mid)
{ 
    int i;

    if(access( "/tmp/mmc/mmlist.txt", F_OK ) == -1 ) return 1; //if no file exist enable all
    if(mmlist[0] == 0xFFF)  return 1; // if file is empty enable all

    printf("Member: %d",mid);
    for(i=0;i<2000;i++)
    {
       if(mid == mmlist[i]  )
       {
          puts("Exist");
          return 1;
       }
       if((dpu_settings[6][8]=='Y'||dpu_settings[6][8]=='S') && mid == (mmlist[i]+1000)) // Cow/Buf enabled
       {
          puts("Exist");
          return 1;
       }


    }
    return 0;//no match found
}
int get_password(unsigned char  cmax,unsigned char cstart)
{
        if(isdigit(key))  // numeric value only
        {
               con = 0;
               cursor_off();
               update_lcd();

		if(cx<cmax)
		{
			lcd_putc(cx,cy,'*');
                        str_buf[cx-cstart] = key;
			update_lcd();
			cx++;
		}
                con =1;
	}
	else if(key == 'q')
	{
               if(cx == cstart ){fstate=0; flag_scan=0; usb_inserted=0; key=1;home_counter=0;return 0;}//exit to default screen
	       if(cx>cstart)cx--;
               str_buf[cx-cstart] = 0;
	}
	else if(key == 0x0a && lcd_buffer[cy][cmax-1] != '_')
	{
               kwait_feed=0;
               str_buf[cx-cstart] = 0;
               return 1;
	}
	else
	{
		lcd_putc(cx,cy,'_');
		update_lcd();
	}
	key =0;
        return 0;

}
int get_text(unsigned char  cmax,unsigned char cstart)
{

        if( (key >= '0' && key <= '9') || (key >= 'A' && key <= 'Z')|| key == ' ')  // alpha-numeric value only
        {
               con = 0;
               cursor_off();
               update_lcd();

		if(cx<cmax)
		{
			lcd_putc(cx,cy,key);
			update_lcd();
			if(key_mode==0)cx++;
                        if(lcd_buffer[cy][cx]=='/' || lcd_buffer[cy][cx]==':' || lcd_buffer[cy][cx]==','  || lcd_buffer[cy][cx]=='.') cx++;

		}
                con =1;
		//key=0;
	}
	else if(key == 'q')
	{
	   //printf("cx= %d,cstart= %d\r\n",cx,cstart);
	   
               if(cx == cstart){fstate=0; flag_scan=0; usb_inserted=0; load_settings(); key=1;home_counter=0;return 0;}//exit to default screen
	       if(cx>cstart)cx--;
               if(lcd_buffer[cy][cx]=='/' || lcd_buffer[cy][cx]==':' || lcd_buffer[cy][cx]==',' || lcd_buffer[cy][cx]=='.') cx--;

	}
	else if(key == 0x0a && lcd_buffer[cy][cmax-1] != '_')
	{
               kwait_feed=0;

               return 1;
	}
	else
	{
		lcd_putc(cx,cy,'_');
		update_lcd();
	}
	key =0;
        return 0;

}
unsigned long entry_offset;
char entry_file[100];
char actual_time[10];
char delete_pwd[4];
float deduct;

void send_sms(char * mob,char *body)
{
    unsigned char eod[] = {0x1a,0x00};
    char line[16];

    line[0]=0x03;line[1]=0x06;line[2]=0x09;
    //sleep(1);
    write(uart0_fd,line,3); sleep(3);   //activate AT only mode
    //puts(mob);
    //puts(body);    
        
	write(uart0_fd,"AT\r\n",4); usleep(300000);
	write(uart0_fd,"AT\r\n",4); usleep(300000);
    
	write(uart0_fd,"AT+CMGS=\"",9); 
	write(uart0_fd,mob,strlen(mob));//PDU>Length  Text Mobile
	write(uart0_fd,"\",129\r\n",7);   // now wait for '>'  
	sleep(1);
	write(uart0_fd,body,strlen(body)); //text body
    
    //write(uart1_fd,"\r\n",2); 
	sleep(1);
	write(uart0_fd,eod,1);
	sleep(1);
    line[0]=0x05;line[1]=0x06;line[2]=0x07;
    sleep(2);
    write(uart0_fd,line,3); sleep(1);   //de-activate AT only mode
    write(uart0_fd,line,3); sleep(1);   //de-activate AT only mode
}
char tpbuf[256];
char tpstr[256];
void tp_write(int fd,char * str,int size)
{
    //printf(str);
    
    //close(uart1_fd);
    memset(tpbuf,0,256);
    sprintf(tpbuf,"echo -n '%s' > /dev/ttyS1",str);
    
    system_call(tpbuf,tpstr);
    usleep(10000);
    //uart1_fd = open ("/dev/ttyS1", O_RDWR | O_NOCTTY | O_SYNC);
    
}
char last_rdisplay[200];
void get_data()
{

        float lit,fat,snf,rate,xfat,xsnf;
        int li,fi,si,i,uart1_fd_local,uid;
        
        FILE * fd_s1,* fd_s2;
        char sc=0;
        
        char dflag[2]={' ','*'};
        double amount;
        unsigned long offset;
        float pc_amount,pc_liter;
        int div_value;
        if(dis_rate==2 && key=='q')
         { 
            key = 1;    // simulate key press
            flag_scan = 0;
            fstate = GET_ID;
            dis_rate=0;
            //omc_fat=0;
            //omc_snf=0;
            //omc_lit=0;
            //xfat=0;
            //xsnf=0;
            puts("Exit RateDisplay\r\n");
            return;
         }

        if( (key >= '0' && key <= '9') || (key >= 'A' && key <= 'Z'))  // numeric value only
        {
            if(cx<cmax)
            {

                if(cy==1 && key != lcd_buffer[cy][cx])        { lit_dirty=1; clit_dirty=1; }
                if((cy == 2||cy==3) && key!= lcd_buffer[cy][cx]){ fat_dirty=1; cfat_dirty=1; }

                lcd_putc(cx,cy,key);
                update_lcd();
                cx++;
                //--if(cy == 1) lit_dirty=1;
                //--if(cy == 2) fat_dirty=1;

            }

            if(lcd_buffer[cy][cx] == '.')  // skip '.'
            {
               con = 0;
               cursor_off();
               update_lcd();
               cx++;
               con = 1;
            }
            key =0;
        }
        else if(key == 'q')
        {


          if(cy < 1)             // MID
          {
             if(cx>10)cx--;
          }
          if(cy == 1)            //LTR
          {
             if(cx>9)cx--;
          }

          if(cy == 2 || cy == 3)  //FAT/SNF
          {
             if(cx>10)cx--;
          }
          if(lcd_buffer[cy][cx] == '.')  // skip '.'
          {
               con = 0;
               cursor_off();
               update_lcd();
               cx--;
               lcd_putc(cx,cy,'_');
               con = 1;
          }
          else
          {
              lcd_putc(cx,cy,'_');
              update_lcd();
          }
          key =0;
        }
        //else if(key == 0x0a)
        else if(key == 0x0a)
        {
          key =0;
          usleep(100000);tcflush(uart1_fd,TCIOFLUSH);    
          if( (cy < 3-fat_only /*&& lcd_buffer[cy][cmax-1] != '_'*/) || cy == 0)
          {
            
            div_value =1;
            if(lcd_buffer[cy][cmax-1] == '_') {puts("divide by 10");div_value = 10;}
            if(cy ==1 && lcd_buffer[cy][cmax-1] == '_' && lit_mode == 1) {puts("divide by 100"); if(cx>13)div_value=10; else div_value =100;}
             
             if( cy==1) {
                 if(lit_mode==0) { sprintf(str_temp,"%05.1f",atof(&lcd_buffer[cy][9])/div_value);memcpy(&lcd_buffer[cy][9],str_temp,5); }
                  if(lit_mode==1) { sprintf(str_temp,"%06.2f",atof(&lcd_buffer[cy][9])/div_value);memcpy(&lcd_buffer[cy][9],str_temp,6); }
            }
             else if( cy == 2) {sprintf(str_temp,"%04.1f",atof(&lcd_buffer[cy][10])/div_value);memcpy(&lcd_buffer[cy][10],str_temp,4);}
             
             
            
            
             con=0;
             if(cy==0 && cx >10)
             {
		i=0;memcpy(temp_buf,&lcd_buffer[0][10],4); while(i<5){if(temp_buf[i++]=='_')break;} temp_buf[i-1]=0;
		mid = atoi(temp_buf);

            if(dpu_settings[6][8]=='S')
            {
               ask_mtype();
               
               if(milk_type==0 && mid<1000)
               {
                  mid +=1000;
               }
            
            }

		sprintf(temp_buf,"%04d",mid);
		
		
		
		
		lcd_puts(10,0,temp_buf);
                //set_interface_attribs (uart2_fd, B2400, 0);
                
                if(edit_mode==0)
                {
			// send command to serial display
			//EN_FAT;
			sprintf(temp_buf,"\nM%04d000000000000",mid);
			write(uart2_fd,temp_buf,strlen(temp_buf));
			usleep(100000);
            
		  t = time(NULL);
		  tm = *localtime(&t);
	          if(tm.tm_hour <= 12)sprintf(temp_buf,"/tmp/mmc/morning/%02d_%02d.dat",tm.tm_mon+1,tm.tm_year-100);
                  else              sprintf(temp_buf,"/tmp/mmc/evening/%02d_%02d.dat",tm.tm_mon+1,tm.tm_year-100);
                  printf("PATH:%s\n",temp_buf);
	              fd_s1 = fopen(temp_buf,"rb");
	              str_buf[0]=0;str_buf[9]=0;
                  if(fd_s1)
                  {       memset(str_buf,0,43);
		          offset = (tm.tm_mday-1)*(2000*43) + (mid*43);
	  		      fseek(fd_s1,offset,SEEK_SET);
			      fread(str_buf, 43,1,fd_s1); str_buf[43]=0;
		          fclose(fd_s1);
                  puts(str_buf);puts("\n");

                  }
		          if((isdigit(str_buf[0]) && isdigit(str_buf[9]) )|| member_active(mid)==0) // record already exist
		          {
		            con=0;lcd_notify("  RECORD EXIST  ",1);
                            sleep(1);
		            fstate=GET_ID;key=1;return;
		          }
                  
                   deduct = 0;
                   
                   memset(frame2,0,500);
                   memset(frame3,0,500);
                    //--set_interface_attribs2 (uart1_fd,B2400,0);//
                    
                    //set_interface_attribs2 (uart1_fd,B2400,0);
                    set_interface_attribs2 (uart2_fd,B9600,0);//
                   //set_speed(uart1_fd,B2400);
                                
                   
                   //set_blocking(uart1_fd,1);//
                   
                   puts("read data\n");
                   
                   //
                   pthread_create( &thread_analyzer , NULL , thread_uart1 , NULL);
                   usleep(400000);
                   //--flag_scan=1;
                   
                   
                   device = 0;
                   omc_lit=0;//24/12/2016  
                   
                   
                   

                   
                   //memset(frame2,0,200);

                   rx1_bytes=0;
                   
                   dis_rate = 0; 
                   if(en_disp_rate)dis_rate=1;
                }
                else  //reload stored value
                {
		    tm.tm_mday = atoi(&manual_date[0]);
		    tm.tm_mon  = atoi(&manual_date[3])-1;
		    tm.tm_year = atoi(&manual_date[6]);
	            if(session==1)sprintf(temp_buf,"/tmp/mmc/morning/%02d_%02d.dat",tm.tm_mon+1,tm.tm_year);
                    else          sprintf(temp_buf,"/tmp/mmc/evening/%02d_%02d.dat",tm.tm_mon+1,tm.tm_year);
                    printf("FILE:%s\n",temp_buf);
                    strcpy(entry_file,temp_buf); //filepath used for deleting entry

	            fd_s1 = fopen(temp_buf,"rb");
                    offset = (tm.tm_mday-1)*(2000*43) + (mid*43);
                    entry_offset = offset;
		    if(fd_s1)
		    {
		      fseek(fd_s1,offset,SEEK_SET);
		      fread(str_buf, 43,1,fd_s1); str_buf[43]=0;
                      printf("%s\r\n",str_buf);
                      if(isdigit(str_buf[0]) && isdigit(str_buf[9]) && strlen(str_buf)>40)
                      {
                          printf("last value:%s\r\n",str_buf);
                          if(str_buf[7]=='1') lit_dirty=1;
                          if(str_buf[6]=='1') fat_dirty=1;
                          str_buf[20] = str_buf[25] = str_buf[34] = str_buf[42] = 0;
                          deduct = atof(&str_buf[35]); //last stored deduction value
                          xhour = atoi(&str_buf[0]);
                          xmin = atoi(&str_buf[3]);

                          if(lit_mode==0){str_buf[14]=0;lcd_puts(9,1,&str_buf[9]);}
                          else           {str_buf[15]=0;lcd_puts(9,1,&str_buf[9]);}

                          lcd_puts(10,2,&str_buf[16]);
                          if(fat_only==0)lcd_puts(10,3,&str_buf[21]);
                          update_lcd();
                          //added following to display rate/lit
                          //omc_lit =atof(&str_buf[9]);
                          //omc_fat=atof(&str_buf[16]);
                          //omc_snf=0;
                          //if(fat_only==0) omc_snf=atof(&str_buf[21]);
                      }
                      fclose(fd_s1);
                    }
                   dis_rate = 0; 
                   if(en_disp_rate)dis_rate=1;

                }


             }
             
             cursor_off();
             update_lcd();
                       // Edit next paramet
             if(cy>0)cy++;
             else if(cy==0 && cx >10) cy++;
             
             
             cx=10;
             cmax = 14; // for lit FAT/SNF
             if(cy==1 && lit_mode)          cmax  =15; //000.00 lit
             if(cy==1) cx=9;


            con=1;
            key =0;
         }

         else if((cy ==3-fat_only /* 2022 && lcd_buffer[cy][cmax-1] != '_'*/) && dis_rate==1)
         {
                 flag_scan=0;
                 usleep(300000);
                 //lag_scan=0;
                 //we got fat & snc display rate/lit  for 2 sec
                 //if(dis_rate >=1 )
                div_value =1; 
                if(lcd_buffer[cy][cmax-1] == '_') div_value = 10;             
                sprintf(str_temp,"%04.1f",atof(&lcd_buffer[cy][10])/div_value);memcpy(&lcd_buffer[cy][10],str_temp,4);dflag[cy]=1;update_lcd(); sleep(1);                 
                 
                 omc_lit = atof(&lcd_buffer[1][9]);
                 omc_fat = atof(&lcd_buffer[2][10]);
                 omc_snf=0;
                 if(fat_only==0) omc_snf = atof(&lcd_buffer[3][10]);
                 { 
                     rate = get_rate(omc_fat,omc_snf,mid);
                     con=0;
                     sprintf(temp_buf,"RATE  : %5.2f  ",rate);
                     lcd_notify2(temp_buf,0);

                     if(ws_mode==0)sprintf(temp_buf,"LITER : %5.2f     ",omc_lit);
                     else          sprintf(temp_buf,"KG    : %5.2f     ",omc_lit);
                     
                     lcd_notify2(temp_buf,1); 

                     sprintf(temp_buf,"FAT   :  %4.1f     ",omc_fat);
                     lcd_notify2(temp_buf,2); 
                     if(fat_only==0){
                     sprintf(temp_buf,"SNF   :  %4.1f     ",omc_snf);
                     lcd_notify2(temp_buf,3); 
                     }

                     //sleep(3); con=1;update_lcd(); 
                     //if(dis_rate<10)dis_rate++;
                 }
                 dis_rate=2;
                 key =0;
                 if(entry_delete) key=0x0a;//skip screen
         }

         else if(cy ==3-fat_only /* 2022 && lcd_buffer[cy][cmax-1] != '_' */&& (dis_rate==2 || dis_rate==0))
         {
            //---------flag_scan=0;
            dis_rate = 0;
            //----tcflow(uart1_fd,TCOOFF);
            //set_interface_attribs2 (uart1_fd, B19200, 0);

            div_value =1; 
            if(lcd_buffer[cy][cmax-1] == '_') div_value = 10;             
            sprintf(str_temp,"%04.1f",atof(&lcd_buffer[cy][10])/div_value);memcpy(&lcd_buffer[cy][10],str_temp,4);dflag[cy]=1;update_lcd(); sleep(1);

/*
            if(dpu_settings[5][15] == 'Y' && edit_mode ==0)   //tare enabled
            {
                puts("Tare Weight...\n");
                usleep(500000);
                EN_WSCALE; usleep(100000);

                #ifdef PROJ_MAHI
                str_buf[0] = '@';
                write(uart1_fd,str_buf,1);//TARE WEIGHT
                #else
                str_buf[0] = 0x1b;str_buf[1] = 'T';str_buf[2] = 0x0d;str_buf[3] = 0x0a;
                write(uart1_fd,str_buf,4);//TARE WEIGHT
                #endif
                usleep(200000);
            }


*/


            t = time(NULL);
            tm = *localtime(&t);
            sprintf(actual_time,"%02d:%02d",tm.tm_hour,tm.tm_min);
            if(edit_mode)
            {
                tm.tm_mday = atoi(&manual_date[0]);
                tm.tm_mon  = atoi(&manual_date[3])-1;
                tm.tm_year = atoi(&manual_date[6])+100;
                //if(session == 1) {tm. = xhour;tm.tm_min = xmin;tm.tm_sec = 0;}   // morning
                //else             {tm.tm_hour = 18;tm.tm_min = 30;tm.tm_sec = 0;}  // evening
                /*if(lit_dirty==0 && fat_dirty==0){ // value unchanged so keep time old
                tm.tm_hour = xhour;tm.tm_min = xmin;tm.tm_sec = 0;
                }*/

                if(clit_dirty==0 && cfat_dirty==0){ // value unchanged so keep time old
                tm.tm_hour = xhour;tm.tm_min = xmin;tm.tm_sec = 0;
                }

            }

            printf("now: %d-%d-%d %d:%d:%d\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);

            if(edit_mode==0)
            {
                if(tm.tm_hour <= 12) // Before 12 Oclock
                {
                  sprintf(str_buf,"//tmp/mmc//morning//%02d_%02d.dat",tm.tm_mon+1,tm.tm_year-100);
                  session=1;
                }
                else
                {
                  sprintf(str_buf,"//tmp/mmc//evening//%02d_%02d.dat",tm.tm_mon+1,tm.tm_year-100);
                  session=2;
                }
            }
            else
            {
                if(session==1) // Before 12 Oclock
                {
                  sprintf(str_buf,"//tmp/mmc//morning//%02d_%02d.dat",tm.tm_mon+1,tm.tm_year-100);
                }
                else
                {
                  sprintf(str_buf,"//tmp/mmc//evening//%02d_%02d.dat",tm.tm_mon+1,tm.tm_year-100);
                }

            }



            fd = open(str_buf,O_WRONLY | O_CREAT, 0666);

            if(lit_mode)lcd_buffer[1][15] = 0;
            else lcd_buffer[1][14] = 0;

            lcd_buffer[2][14] = 0;
            lcd_buffer[3][14] = 0;
            //offset = (mday-1) * (2000*34) + mid*34
            offset = (tm.tm_mday-1)*(2000*43) + (mid*43);
            printf("file_offset=%ld\n",offset);
            lseek(fd,offset,SEEK_SET);

            lit = atof(&lcd_buffer[1][9]);
            fat = atof(&lcd_buffer[2][10]);
            snf = atof(&lcd_buffer[3][10]);




            xfat = fat;
            xsnf = snf;
            if(edit_mode ==0){
            if(fat < 0.5 ) fat = 0.5;
		    if(snf < 5.5 ) snf = 5.5;
            }
	        if(fat > 12.5) fat =12.5;
            if(snf >12) snf = 12;

	    printf("%f:%f\n",fat,snf);

            if(fat >= 0.5) { fi = ( round1((float)(fat - 0.5)*10)); }
            else fi = 0;
	    if(snf >= 5.5) { si = (round1((float)(snf - 5.5)*10));  si++; }
            else si =1;



            sprintf(str_buf,"%02d/%02d/%04d%04d",tm.tm_mday,tm.tm_mon + 1,tm.tm_year + 1900,mid); // printing date
            puts(str_buf);puts("\r\n");
            usleep(200000);
            flag_scan=0;
               

            //tm.tm_min=0;
            tm.tm_sec=0;

            if(lit_dirty) tm.tm_sec = 1;
            if(fat_dirty) tm.tm_sec += 10;

            rate = rate_chart[si][fi];
            fat = xfat; 
            snf = xsnf;
            amount = (double)(lit*rate_chart[si][fi]); // mix
            
            if(dpu_settings[6][8]=='Y' || dpu_settings[6][8]=='S')
            {
               if(mid <1000)
               {
                  amount = (double)(lit*rate_chart[si][fi]); //buf
                  rate = rate_chart[si][fi];
               }
               else
               {
                  amount = (double)(lit*rate_chart2[si][fi]); //cow
                  rate = rate_chart2[si][fi];
               }
            }





            //--#ifdef PROJ_KMD
            if(fat>0 && amount>0)
            {
            //--#endif

                if(entry_delete)
                {
                    lit=0;
                    fat=0;
                    snf=0;
                    rate=0;
                    amount=0;

                }








            printf("fi=%d si=%d Rate = %f Lit=%f Amount= %f\n",fi,si,rate,lit,amount);

            sprintf(str,"%02d:%02d:%02d,%06.2f,%04.1f,%04.1f,%08.2lf,%07.2f\n",tm.tm_hour,tm.tm_min, tm.tm_sec,lit,fat,snf,amount,deduct);


            if(entry_delete==0)
            write(fd,str,strlen(str));
            else
            write(fd,"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",43);

//.channel3>$%%1234B4567089 088 01545609535520000
            close(fd);
            //sprintf(temp_buf,"\nA%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c0",lcd_buffer[1][10],lcd_buffer[1][11],lcd_buffer[1][13],lcd_buffer[2][10],lcd_buffer[2][11],lcd_buffer[2][13],lcd_buffer[3][10],lcd_buffer[3][11],lcd_buffer[3][13],str[27],str[28],str[29],str[30],str[32],str[33]);
            strcpy(temp_buf,last_rdisplay);
            sprintf(str,"%07.2f",rate);
            temp_buf[33] = str[0];
            temp_buf[34] = str[1];
            temp_buf[35] = str[2];
            temp_buf[36] = str[3];
            temp_buf[37] = str[5];
            temp_buf[38] = str[6];
            
            sprintf(str,"%07.1f",amount);
            
            temp_buf[39] = str[0];
            temp_buf[40] = str[1];
            temp_buf[41] = str[2];
            temp_buf[42] = str[3];
            temp_buf[43] = str[4];
            temp_buf[44] = str[6];     
            sprintf(str,"%04.1f",fat);
            temp_buf[22] = str[0];  //fat
            temp_buf[23] = str[1];
            temp_buf[24] = str[3];       
            sprintf(str,"%04.1f",snf);
            temp_buf[26] = str[0];  //snf
            temp_buf[27] = str[1];
            temp_buf[28] = str[3];               
            
            clear_lcd();
            lcd_puts(0,2," Saving Data... ");
            
            entry_delete=0;
            
            update_lcd();
            if(fat != 0 )
            {
             xomc_fat = fat;
             xomc_snf = snf;
            }
             
            puts("Saved to File\r\n");      //00/00/0000aaaa
            //system("sync");
            //system("sync");
            
            while(analyzer_stop==0){usleep(100000);}
               //set_blocking(uart1_fd,1);
                //tcdrain(uart1_fd);
                usleep(100000);
                if(uart1_fd)close(uart1_fd);            
            
            if(dpu_settings[5][10] == 'D'){
              //usleep(100000);tcflush(uart1_fd,TCIOFLUSH);    stty -F /dev/ttyS1 230400 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr
              //----tcflow(uart1_fd,TCOON);
              //---close(uart1_fd);
              
              system("stty -F /dev/ttyS1 19200 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr ");
             
              system("echo -n '\x1B\x40' > /dev/ttyS1");//font size
              
              //--uart1_fd = open ("/dev/ttyS1", O_RDWR | O_NOCTTY | O_SYNC);
	          //--if(uart1_fd<0)puts("uart failed ..!\r\n");
              
              //set_interface_attribs2 (uart1_fd, B19200, 0);
              
            }
            
                   
            

//A5640650892270420
           //02:36:03, 09.5 ,08.4,08.3,00227.05


                
                
            if(edit_mode==0)
            {
              //EN_FAT;
             // sleep(2);
              //--set_interface_attribs (uart2_fd, B2400, 0);
              //usleep(500000);
              write(uart2_fd,temp_buf,strlen(temp_buf));
              puts(temp_buf);
              //usleep(600000);
              write(uart2_fd,temp_buf,strlen(temp_buf));
              //sprintf(temp_buf,"echo %d > /tmp/mmc/ws_mode.txt",ws_mode);
              //system(temp_buf); //save LT/KG mode
            }
            
            
            if(dpu_settings[5][15] == 'Y' && edit_mode ==0)   //tare enabled
            {
                
                
                //EN_WSCALE;
                

                #ifdef PROJ_MAHI
                str[0] = '@';
                write(uart2_fd,str,1);//TARE WEIGHT
                #else
                //--non-wifi str[0] = 0x1b;str[1] = 'T';str[2] = 0x0d;str[3] = 0x0a;
                
                //write(uart2_fd,".channel1>T",11);//TARE WEIGHT
                usleep(800000);
                write(uart2_fd,".channel1>T\r\n",13);//TARE WEIGHT
                write(uart2_fd,".channel1>T\r\n",13);//TARE WEIGHT
                write(uart2_fd,".channel1>T\r\n",13);//TARE WEIGHT
                puts("Tare Weight...\n");
                #endif

            }
          
            
            //edit_mode = 0;
            //print_en=0;
            if(print_en){
            //while(flag_scan)
                
            
		    //EN_PRINT;
     

        
//(091010003070006099900000000000000000B)                
 		    if(dpu_settings[5][10] == 'D')
		    {
               
               puts("Dot matrix...");        
               //set_blocking(uart1_fd,0);
               
        
               
               //usleep(100000); tcflush(uart1_fd,TCIOFLUSH);       
               //i=3;
               //while(i--)
               //{
		         //set_interface_attribs2 (uart1_fd, B19200, 0);
                 //set_blocking2(uart1_fd,1);
               //}
                 
                 //tcflush(uart1_fd,TCIOFLUSH);
                 //set_speed(uart1_fd,B19200);
                 //tcdrain(uart1_fd);
                 //---set_interface_attribs2 (uart1_fd, B19200, 0);
                 //tcflow(uart1_fd,TCOON);
              // set_blocking(uart1_fd,1);
               //sleep(1);
               
               //sleep(5);
               //set_blocking(uart1_fd,1);
               /*
		       temp_buf[0] = 0x1B;temp_buf[1] = 0x40;
		       write(uart1_fd,temp_buf,2);
		      --*/
		       usleep(300000);
               
                       
               if(regional>0)enable_regional(); 
		    }
		    else{
                 PT_ON;
                 puts("Thermal Printer...");   
                 free_ram=0;
                 //system("sysctl -w vm.drop_caches=3");
        
                 //--tcflush(uart1_fd,TCIOFLUSH);       sleep(1);

                //6666 sleep(1);
                
              
              //usleep(100000);tcflush(uart1_fd,TCIOFLUSH);
              //system("stty -F /dev/ttyS1 9600 -raw ");
              //sleep(1);tcflush(uart1_fd,TCIOFLUSH);
               //system("stty  -F /dev/ttyS1 9600 sane");
               //usleep(500000);
              //system("stty -F /dev/ttyS1 9600 sane");
              //usleep(500000);
                for(i=0;i<5;i++)
                {
                    system("stty -F /dev/ttyS1 9600 min 0 time 1 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr");
                    usleep(20000);
                    //system_call("stty -a -F /dev/ttyS1 | grep speed",temp_buf);
                    //puts(temp_buf);
                    
                }
              //system("stty -F /dev/ttyS1 9600 min 0 time 1 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr ");
              //usleep(500000);
              /*(((
              uart1_fd = open ("/dev/ttyS1", O_RDWR | O_NOCTTY | O_SYNC);
              set_blocking(uart1_fd,0);
              for(i=0;i<10;i++)
              {
                  tcflush(uart1_fd,TCIOFLUSH);       usleep(100000);
              }
              */
              usleep(400000);
              
                //tcflush(uart1_fd,TCIOFLUSH);       usleep(100000);
		      //set_interface_attribs(uart1_fd, B9600, 0);
               
               /*
		       temp_buf[0] = 0x1B;temp_buf[1] = 0x21;temp_buf[2] = 0x21;
		       write(uart1_fd,temp_buf,3);
		       usleep(200000);
               */
               system("echo -n '\x1B\x21\x21' > /dev/ttyS1");
               usleep(500000);
               //write(uart1_fd,temp_buf,3);
               //usleep(500000);
		    }
		    //if(uart1_fd)close(uart1_fd);
		    
            tp_write(uart1_fd,"\r\n",2);
		    if(dpu_settings[5][10] == 'D') tp_write(uart1_fd,"      ",6);tp_write(uart1_fd,"*********************\r\n",23);
		    i=0;
		    memcpy(temp_buf,dpu_settings[0],16);while(i<16){if(temp_buf[i++]=='_')break;} temp_buf[i-1]=0;

		    i = strlen(temp_buf); i = (21-i)/2;
            strcpy(temp_buf2,"                     ");
            temp_buf2[i+1]=0;
		    if(dpu_settings[5][10] == 'D') tp_write(uart1_fd,"      ",6);tp_write(uart1_fd,temp_buf2,i+1); // keep label in center

		    tp_write(uart1_fd,temp_buf,strlen(temp_buf));tp_write(uart1_fd,"\r\n",2);

            usleep(300000);
            str_buf[30] = str_buf[10];
		    if(dpu_settings[5][10] == 'D') tp_write(uart1_fd,"      ",6);tp_write(uart1_fd,"*********************\r\n",23);
		    if(dpu_settings[5][10] == 'D') tp_write(uart1_fd,"      ",6);tp_write(uart1_fd,actual_time,5);tp_write(uart1_fd,"  ",2);str_buf[10]=0; tp_write(uart1_fd,str_buf,10);tp_write(uart1_fd,"\r\n",2);
		    if(dpu_settings[5][10] == 'D') tp_write(uart1_fd,"      ",6);
            //usleep(300000);
            str_buf[10] = str_buf[30];  
		    if(regional==0)tp_write(uart1_fd,"M= ",3);
		    else {tp_write(uart1_fd,labels[MEM_NO],4);tp_write(uart1_fd,"= ",1);}
            
		    if((dpu_settings[6][8]=='Y'||dpu_settings[6][8]=='S') && mid >999)  str_buf[10]='0';
             
		    tp_write(uart1_fd,&str_buf[10],4);
            //--sleep(1);
		    if(regional) tp_write(uart1_fd,"  ",2);
            /*^*/if(session==1) {if(regional==0) tp_write(uart1_fd," Mor",4); else tp_write(uart1_fd,labels[MOR],strlen(labels[MOR]));  sc='M';}
		    else              { if(regional==0)tp_write(uart1_fd," Eve",4);else tp_write(uart1_fd,labels[EVE],strlen(labels[EVE]));sc='E';}
		    if(regional) tp_write(uart1_fd,"  ",2);
           
		    if(dpu_settings[6][8]=='Y' || dpu_settings[6][8]=='S')
		    {
		       if(mid <1000){ if(regional==0)tp_write(uart1_fd," Buf",4); else tp_write(uart1_fd,labels[BUF],strlen(labels[BUF]));}
		       else         { if(regional==0)tp_write(uart1_fd," Cow",4); else tp_write(uart1_fd,labels[COW],strlen(labels[COW]));}
		    }
		    
		    tp_write(uart1_fd,"\r\n",2);
            usleep(300000);
            }

            /*^*/if(session==1) { sc='M';}
            else              { sc='E';}
            memset(temp_buf,0,16); // clear buffer
            fd = open("/tmp/mmc/member.dat",O_RDONLY);  //
	    lseek(fd,mid*32,SEEK_SET);
            read(fd,temp_buf,16);
	    i=0;while(i<16){if(temp_buf[i++]=='_')break;} temp_buf[i-1]=0;
            strcpy(str,temp_buf);

            read(fd,temp_buf,16);
	    i=0;while(i<11){if(temp_buf[i++]=='_')break;} temp_buf[i-1]=0;
            strcpy(&str[30],temp_buf);//mobile no


            //------close(fd);
            
//--------FUNCTION:PAYMENT CYCLE -> calculate total_lit and total_amount as per payment cycle
            if(pcycle!=0)
            {
                //if(mid <1000) uid = mid;
                //else          uid = mid-1000;
                uid = mid;
                pc_amount=0;
                pc_liter =0;
                if(tm.tm_mday%pcycle>0)
                {
                    i = tm.tm_mday-(tm.tm_mday%pcycle)+1;
                }
                else // is zero so 10 days..
                {
                    i = (tm.tm_mday - pcycle)+1;
                }
                if(tm.tm_mday >=28 && pcycle == 10) i  = 21;
                if(tm.tm_mday >=28 && pcycle == 5)  i  = 26;
                if(pcycle == 31) i =1;
                
                    
                sprintf(str_buf,"/tmp/mmc/morning/%02d_%02d.dat",tm.tm_mon+1,tm.tm_year-100);
                fd_s1 = fopen(str_buf,"rb");
                
                sprintf(str_buf,"/tmp/mmc/evening/%02d_%02d.dat",tm.tm_mon+1,tm.tm_year-100);
                fd_s2 = fopen(str_buf,"rb"); 
                    
                while(i<=tm.tm_mday && i>0)   
                {
 
                
                
                    if(fd_s1) // morning
                    {
                        offset = (i-1)*(2000*43) + (uid*43);    
                        fseek(fd_s1,offset,SEEK_SET);               
                        memset(str_buf,0,50);
                        fread(str_buf, 43,1,fd_s1); str_buf[43]=0;
                        str_buf[15] = str_buf[20] = str_buf[25] = str_buf[34] = 0;
                        if((str_buf[0] >='0' && str_buf[0] <='9'))
                        {
                            pc_amount += atof(&str_buf[26]);
                            pc_liter  += atof(&str_buf[9]);
                        }
                        
                        /*
                        offset = (i-1)*(2000*43) + ((uid+1000)*43);    // COW
                        fseek(fd_s1,offset,SEEK_SET);
                        memset(str_buf,0,50);
                        fread(str_buf, 43,1,fd_s1); str_buf[43]=0;
                        str_buf[15] = str_buf[20] = str_buf[25] = str_buf[34] = 0;
                        if((str_buf[0] >='0' && str_buf[0] <='9'))
                        {
                            pc_amount += atof(&str_buf[26]);
                            pc_liter  += atof(&str_buf[9]);
                        }                   */     
                        
                        
                    }
                    if(fd_s2) // evening
                    {
                        offset = (i-1)*(2000*43) + (uid*43);    
                        fseek(fd_s2,offset,SEEK_SET);                
                        memset(str_buf,0,50);
                        fread(str_buf, 43,1,fd_s2); str_buf[43]=0;
                        str_buf[15] = str_buf[20] = str_buf[25] = str_buf[34] = 0;
                        if((str_buf[0] >='0' && str_buf[0] <='9'))
                        {
                            pc_amount += atof(&str_buf[26]);
                            pc_liter  += atof(&str_buf[9]);                         
                        }                        
                        
                        
                        /*offset = (i-1)*(2000*43) + ((uid+1000)*43);    // COW
                        fseek(fd_s2,offset,SEEK_SET);   
                        memset(str_buf,0,50);
                        fread(str_buf, 43,1,fd_s2); str_buf[43]=0;
                        str_buf[15] = str_buf[20] = str_buf[25] = str_buf[34] = 0;
                        if((str_buf[0] >='0' && str_buf[0] <='9'))
                        {
                            pc_amount += atof(&str_buf[26]);
                            pc_liter  += atof(&str_buf[9]);                          
                        }*/
                        
                    }
                    
                    
                    
                    
                    i++;//next day
                }
                if(fd_s1)fclose(fd_s1);
                if(fd_s2)fclose(fd_s2);          
                          
            }
//-------FUCNTION: PAYMENT CYCLE ENDS
            if(print_en){

if(rate_disable == 0)
{
                
		    if(dpu_settings[5][10] == 'D') tp_write(uart1_fd,"      ",6);tp_write(uart1_fd,str,strlen(str));tp_write(uart1_fd,"\r\n",2); //member name
                   if(fat_only==0){
			    if(dpu_settings[5][10] == 'T') 
			    {
			        if(ws_mode==0)
			        {
			          if(lit_mode==0) sprintf(str_buf,"L= %05.1f %c F= %04.1f %c\r\nS= %04.1f\r\nRate/Lt=Rs.%5.2f\r\nAmount=Rs.%7.2lf\r\n",lit,dflag[lit_dirty],fat,dflag[fat_dirty],snf,rate,amount);
			          else            sprintf(str_buf,"L= %06.2f %c F= %04.1f %c\r\nS= %04.1f\r\nRate/Lt=Rs.%5.2f\r\nAmount=Rs.%7.2lf\r\n",lit,dflag[lit_dirty],fat,dflag[fat_dirty],snf,rate,amount);
                                }
                                else
                                {
			          if(lit_mode==0) sprintf(str_buf,"K= %05.1f %c F= %04.1f %c\r\nS= %04.1f\r\nRate/Kg=Rs.%5.2f\r\nAmount=Rs.%7.2lf\r\n",lit,dflag[lit_dirty],fat,dflag[fat_dirty],snf,rate,amount);
			          else            sprintf(str_buf,"K= %06.2f %c F= %04.1f %c\r\nS= %04.1f\r\nRate/Kg=Rs.%5.2f\r\nAmount=Rs.%7.2lf\r\n",lit,dflag[lit_dirty],fat,dflag[fat_dirty],snf,rate,amount);
                                
                                }
			    }
			    else if(regional==0)           sprintf(str_buf,"      L= %06.2f %c F= %04.1f %c\r\n      S= %04.1f\r\n      Rate/Lt= Rs.%5.2f\r\n      Amount= Rs.%7.2lf\r\n",lit,dflag[lit_dirty],fat,dflag[fat_dirty],snf,rate,amount);
                            else {
                                  sprintf(str_buf,"      %s= %06.2f %c %s= %04.1f %c\r\n      %s= %04.1f\r\n      %s= Rs.%5.2f\r\n      %s= Rs.%7.2lf\r\n",labels[LI],lit,dflag[lit_dirty],labels[FAT1],fat,dflag[fat_dirty],labels[SNF],snf,labels[RATE_LI],rate,labels[AMOUNT],amount);       
                            }
                    }
                    else
                    {
			    if(dpu_settings[5][10] == 'T'){
			        if(ws_mode==0)
			        {
			          if(lit_mode==0)  sprintf(str_buf,"L= %05.1f %c F= %04.1f %c\r\nRate/Lt=Rs.%5.2f\r\nAmount=Rs.%7.2lf\r\n",lit,dflag[lit_dirty],fat,dflag[fat_dirty],rate,amount);
			          else             sprintf(str_buf,"L= %06.2f %c F= %04.1f %c\r\nRate/Lt=Rs.%5.2f\r\nAmount=Rs.%7.2lf\r\n",lit,dflag[lit_dirty],fat,dflag[fat_dirty],rate,amount);        
			         }
			         else
			         {
			          if(lit_mode==0)  sprintf(str_buf,"K= %05.1f %c F= %04.1f %c\r\nRate/Kg=Rs.%5.2f\r\nAmount=Rs.%7.2lf\r\n",lit,dflag[lit_dirty],fat,dflag[fat_dirty],rate,amount);
			          else             sprintf(str_buf,"K= %06.2f %c F= %04.1f %c\r\nRate/Kg=Rs.%5.2f\r\nAmount=Rs.%7.2lf\r\n",lit,dflag[lit_dirty],fat,dflag[fat_dirty],rate,amount);        
			         
			         
			         }
			     }
			    else if(regional==0)  sprintf(str_buf,"      L= %06.2f %c F= %04.1f %c\r\n      Rate/Lt= Rs.%5.2f\r\n      Amount= Rs.%7.2lf\r\n",lit,dflag[lit_dirty],fat,dflag[fat_dirty],rate,amount);
                            else {
                                  sprintf(str_buf,"      %s= %06.2f %c %s= %04.1f %c\r\n      %s= Rs.%5.2f\r\n      %s= Rs.%7.2lf\r\n",labels[LI],lit,dflag[lit_dirty],labels[FAT1],fat,dflag[fat_dirty],labels[RATE_LI],rate,labels[AMOUNT],amount);       
                            }

                    }
                    
                    
                    
}   
else // do not print rate/lit
{
		    if(dpu_settings[5][10] == 'D') tp_write(uart1_fd,"      ",6);tp_write(uart1_fd,str,strlen(str));tp_write(uart1_fd,"\r\n",2); //member name
                   if(fat_only==0){
			    if(dpu_settings[5][10] == 'T') 
			    {
			      if(lit_mode==0) sprintf(str_buf,"%c= %05.1f %c F= %04.1f %c\r\nS= %04.1f\r\nAmount=Rs.%7.2lf\r\n",ws_text[ws_mode][0],lit,dflag[lit_dirty],fat,dflag[fat_dirty],snf,amount);
			      else            sprintf(str_buf,"%c= %06.2f %c F= %04.1f %c\r\nS= %04.1f\r\nAmount=Rs.%7.2lf\r\n",ws_text[ws_mode][0],lit,dflag[lit_dirty],fat,dflag[fat_dirty],snf,amount);
                  
			    }
			    else if(regional==0)           sprintf(str_buf,"      %s= %06.2f %c F= %04.1f %c\r\n      S= %04.1f\r\n",ws_text[ws_mode][0],lit,dflag[lit_dirty],fat,dflag[fat_dirty],snf);
                            else {
                                  sprintf(str_buf,"      %s= %06.2f %c %s= %04.1f %c\r\n      %s= %04.1f\r\n",labels[LI],lit,dflag[lit_dirty],labels[FAT1],fat,dflag[fat_dirty],labels[SNF],snf);       
                            }
                    }
                    else
                    {
			    if(dpu_settings[5][10] == 'T'){
			      if(lit_mode==0)  sprintf(str_buf,"%c= %05.1f %c F= %04.1f %c\r\nAmount=Rs.%7.2lf\r\n",ws_text[ws_mode][0],lit,dflag[lit_dirty],fat,dflag[fat_dirty],amount);
			      else             sprintf(str_buf,"%c= %06.2f %c F= %04.1f %c\r\nAmount=Rs.%7.2lf\r\n",ws_text[ws_mode][0],lit,dflag[lit_dirty],fat,dflag[fat_dirty],amount);      
                  //usleep(400000);
			     }
			    else if(regional==0)  sprintf(str_buf,"      %c= %06.2f %c F= %04.1f %c\r\n",ws_text[ws_mode][0],lit,dflag[lit_dirty],fat,dflag[fat_dirty]);
                            else {
                                  sprintf(str_buf,"      %s= %06.2f %c %s= %04.1f %c\r\n",labels[LI],lit,dflag[lit_dirty],labels[FAT1],fat,dflag[fat_dirty]);       
                            }

                    }
    
}
                    
                    
                    
           
           // puts(str_buf);
           //usleep(400000); 
            i = strlen(str_buf);///2;
		    tp_write(uart1_fd,str_buf,i);
            if(pcycle>0)
            {
              if(dpu_settings[5][10] == 'T')
              {
                 if(ws_mode==0)sprintf(str_buf,"Tot.Liter=%05.1f\r\nTot.Amount=Rs.%7.2f\r\n",pc_liter,pc_amount);
                 if(ws_mode==1)sprintf(str_buf,"Tot.Kg   =%05.1f\r\nTot.Amount=Rs.%7.2f\r\n",pc_liter,pc_amount);
              }
              if(dpu_settings[5][10] == 'D')
              {
                 if(ws_mode==0)sprintf(str_buf,"      Tot.Liter=%05.1f\r\n      Tot.Amount=Rs.%7.2f\r\n",pc_liter,pc_amount);
                 if(ws_mode==1)sprintf(str_buf,"      Tot.Kg   =%05.1f\r\n      Tot.Amount=Rs.%7.2f\r\n",pc_liter,pc_amount);
              }
              tp_write(uart1_fd,str_buf,strlen(str_buf));
            }
            usleep(300000);
            //tp_write(uart1_fd,&str_buf[i],strlen(str_buf)-i);
            //usleep(400000);
		    if(dpu_settings[5][10] == 'D') tp_write(uart1_fd,"      ",6);tp_write(uart1_fd,"*********************\r\n",23);
            usleep(300000);
            if(strlen(company_name)>3){
            if(dpu_settings[5][10] == 'D') tp_write(uart1_fd,"      ",6);tp_write(uart1_fd,company_name,strlen(company_name)); tp_write(uart1_fd,"\r\n",2);
            }
            if(dpu_settings[5][10] == 'D') tp_write(uart1_fd,"      ",6); tp_write(uart1_fd," A k a s h g a n g a \r\n",23);
            usleep(300000);


		    if(dpu_settings[5][10] == 'D') tp_write(uart1_fd,"      ",6);tp_write(uart1_fd,"*********************\r\n",23);
		    tp_write(uart1_fd,"\r\n\r\n\r\n",6);
		    
		    if(dpu_settings[5][10] == 'D') tp_write(uart1_fd,"\r\n\r\n\r\n",6);
            
		    usleep(300000);
            

            }
            sleep(1);//3
            //sleep(2);
#ifdef PCB_V1
            PT_OFF;     
#endif
            //close(uart1_fd);
              

              
              
              
            if(regional>0)exit_regional();

            memcpy(str_buf,&dpu_settings[2][4],3);str_buf[3]=0;      // project code
            memcpy(&str_buf[6],&dpu_settings[2][12],4);str_buf[10]=0; // dist code
            memcpy(&str_buf[11],&dpu_settings[1][5],4);str_buf[15]=0;// collect point code

            usleep(100000);
            str[60] = 'M';  //default mix milk
            if(dpu_settings[6][8]=='Y' || dpu_settings[6][8]=='S')
            {
              str[60] = 'B';      //BUF
              if(mid>999) str[60] = 'C'; //COW
            }

            //send to GPRS  : %AMU/M/270715/1539/0767/0001/M-NAME/B/L23.41/F07.81/S09.6 /A1901.48/13:35/$
            if((dpu_settings[6][8]=='Y'||dpu_settings[6][8]=='S') && mid >999)  mid = mid-1000;

            

            if(fat_only){snf=0;}
            sprintf(temp_buf,"%%%s/%c/%02d%02d%02d/%s/%s/%04d/%s/%c/L%05.2f%d/F%04.1f%d/S%04.1f%d/A%07.2lf/%02d:%02d/R%5.2f/I%s$",str_buf,sc,tm.tm_mday,tm.tm_mon+1,tm.tm_year-100,&str_buf[6],&str_buf[11],mid,str,str[60],lit,lit_dirty,fat,fat_dirty,snf,fat_dirty,amount,tm.tm_hour, tm.tm_min,rate,IMEI);
            //else sprintf(temp_buf,"%%%s/%c/%02d%02d%02d/%s/%s/%04d/%s/%c/L%05.2f%d/F%04.1f%d/S%04.1f%d/A%07.2lf/%02d:%02d/$",str_buf,sc,tm.tm_mday,tm.tm_mon+1,tm.tm_year-100,&str_buf[6],&str_buf[11],mid,str,str[60],lit,lit_dirty,fat,fat_dirty,0,0,amount,tm.tm_hour, tm.tm_min);
            
            flag_scan=0;
            puts("SMS...");
            if(uart0_fd<=0) uart0_fd = open ("/dev/ttyS0", O_RDWR | O_NOCTTY | O_SYNC);
            set_interface_attribs (uart0_fd, B9600, 0);
           
            
            EN_GPRS;
            usleep(300000);//sleep(1);
            //puts(dpu_settings[4]);
            if(strcmp("000.000.000.000 ",dpu_settings[4])!=0   && dpu_settings[6][15]=='N')
            {
              ws_write(uart0_fd,temp_buf,strlen(temp_buf));
              puts(temp_buf);puts("\n");
              
            }
            //usleep(500000);//wait for grps frame to be sent
            sleep(1);
            close(fd); // 2022
            if(strlen(&str[30])==10 && strcmp(&str[30],"0000000000")!=0 && dpu_settings[6][15]=='Y') // valid mobile no and sms is enabled
            {
             
                 
		    //--sleep(6);
 
		i=0;  memcpy(str_buf,dpu_settings[0],16);while(i<16){if(str_buf[i++]=='_')break;} str_buf[i-1]=0; // center name
		if(sc == 'M') strcpy(&str_buf[20],"Mor");
		else if(sc == 'E') strcpy(&str_buf[20],"Eve");

		if(str[60] == 'M') strcpy(&str_buf[30],"Mix");
		else if(str[60] == 'B') strcpy(&str_buf[30],"Buf");
		else if(str[60] == 'C') strcpy(&str_buf[30],"Cow");
           
        if(uart0_fd>0)close(uart0_fd);
        
        system("stty -F /dev/ttyS0 9600 raw -echo");// min 0 time 1 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost");
        uart0_fd = open ("/dev/ttyS0", O_RDWR | O_NOCTTY | O_SYNC);
		
        if(rate_disable ==0)
        {
            
        if(fat_only==0)sprintf(temp_buf,"%s\r\nMem:%04d\r\n%s\r\n%02d/%02d/%02d %s %s\r\nL=%05.2f %c\r\nF=%04.1f %c\r\nS=%04.1f\r\nAmt: %07.2lf\r\n\r\n***Akashganga***\r\n",str_buf,mid,str,tm.tm_mday,tm.tm_mon+1,tm.tm_year-100,&str_buf[20],&str_buf[30],lit,dflag[lit_dirty],fat,dflag[fat_dirty],snf,amount);
                else sprintf(temp_buf,"%s\r\nMem:%04d\r\n%s\r\n%02d/%02d/%02d %s %s\r\nL=%05.2f %c\015\012F=%04.1f %c\r\nAmt: %07.2lf\r\n***Akashganga***\r\n",str_buf,mid,str,tm.tm_mday,tm.tm_mon+1,tm.tm_year-100,&str_buf[20],&str_buf[30],lit,dflag[lit_dirty],fat,dflag[fat_dirty],amount); 
		   //---write(uart0_fd,temp_buf,strlen(temp_buf));
                send_sms(&str[30],temp_buf);
                
                
        }
        else
        {

            if(fat_only==0)sprintf(temp_buf,"%s\r\nMem:%04d\r\n%s\r\n%02d/%02d/%02d %s %s\r\nL=%05.2f %c\r\nF=%04.1f %c\r\nS=%04.1f\r\nAmt: %07.2lf\r\n\r\n***Akashganga***\r\n",str_buf,mid,str,tm.tm_mday,tm.tm_mon+1,tm.tm_year-100,&str_buf[20],&str_buf[30],lit,dflag[lit_dirty],fat,dflag[fat_dirty],snf,amount);
                    else sprintf(temp_buf,"%s\r\nMem:%04d\r\n%s\r\n%02d/%02d/%02d %s %s\r\nL=%05.2f %c\r\nF=%04.1f %c\r\nAmt: %07.2lf\r\n\r\n***Akashganga***\r\n",str_buf,mid,str,tm.tm_mday,tm.tm_mon+1,tm.tm_year-100,&str_buf[20],&str_buf[30],lit,dflag[lit_dirty],fat,dflag[fat_dirty],amount); 
            //--write(uart0_fd,temp_buf,strlen(temp_buf));
                //puts("sms in");
             //puts(&str[30]);
                    send_sms(&str[30],temp_buf);
            
        }
      
		puts(temp_buf);puts("\n");
        
        
            }

            system("sync");

            //edit_mode=0;
            usleep(100000);

            //--#ifdef PROJ_KMD
            }
            else
            {
               con=0;
               cursor_off();
               lcd_notify("[Invalid  Entry]",1);
               sleep(5);

            }

            //--#endif
            lit_dirty=0;fat_dirty=0;
              
              if(dpu_settings[5][10] == 'T') system("stty -F /dev/ttyS1 9600 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr ");
              if(dpu_settings[5][10] == 'D') system("stty -F /dev/ttyS1 19200 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr ");
              //usleep(10000);tcflush(uart1_fd,TCIOFLUSH);
              
              //uart1_fd = open ("/dev/ttyS1", O_RDWR | O_NOCTTY | O_SYNC);
	          //if(uart1_fd<0)puts("uart failed ..!\r\n");
              //if(dpu_settings[5][10] == 'T') set_interface_attribs2(uart1_fd, B9600, 0);
              //else                           set_interface_attribs2(uart1_fd, B19200, 0);
              
            //--session=0;

            key = 1; // simulate key press
            fstate = GET_ID;
            //---if(edit_mode) fstate = EDIT;

         }

        }
        else
        {
           key = 0;
        }



}
void system_cmd(char * p1,char * p2,char *p3,char * p4,char * p5 )
{
   //cp /tmp/usb/backup0016 /tmp/mmc/
   char cmd[100];
   sprintf(cmd,"%s%s%s%s%s",p1,p2,p3,p4,p5);
   puts(cmd);
   system(cmd);
}

void lcd_page()
{
   unsigned char c;
   int d,m,y;
   int fd,i,n;

   FILE * fd_mm;

   unsigned long offset;

   switch(fstate)
   {
       case GET_ID:
		con = 0;
                mblink = 0;edit_pass =0;
		clear_lcd();
                lcd_puts(0,0,"Mem. No : ____  ");
                
                
                if(ws_mode==0)
                {
		if(lit_mode)lcd_puts(0,1,"Liters  :___.__ ");
                else        lcd_puts(0,1,"Liters  :___._  ");  
                }
                if(ws_mode==1)
                {
		if(lit_mode)lcd_puts(0,1,"Kgs     :___.__ ");
                else        lcd_puts(0,1,"Kgs     :___._  ");  
                }
                
		lcd_puts(0,2,"Fat     : __._  ");
		if(fat_only==0)lcd_puts(0,3,"SNF     : __._  ");
		cx = 10;  cy = 0; cmax = 14;
                key_mode=0;
		update_lcd();
		con = 1;
                lit_dirty =0;
                fat_dirty =0;
                clit_dirty =0;
                cfat_dirty =0;

		fstate++;
                key=0;
        break;
        case SET_DPU:
		mblink = 0;edit_pass =0;
                load_settings();
		clear_lcd();
		cx = 0;
		cy = 1;
		lcd_puts(0,0, "Name:           ");
                puts(dpu_settings[0]);puts("\n");puts(dpu_settings[1]);puts("\n");puts(dpu_settings[2]);puts("\n");
		if(dpu_settings[0][0] == 0)   lcd_puts(0,1, "_______________ ");
                else                          lcd_puts(0,1, dpu_settings[0]);

		if(dpu_settings[1][0] == 0)   lcd_puts(0,2, "Code:____       ");
                else                          lcd_puts(0,2, dpu_settings[1]);

		if(dpu_settings[2][0] == 0)   lcd_puts(0,3, "Pro:___ Dis:____");
                else                          lcd_puts(0,3, dpu_settings[2]);

		//lcd_puts(0,2, "Colle.Code:----");

		//lcd_puts(0,3, "Project   :---");
		update_lcd();
		fstate++;
		//sstate=0;
		con=1;
                //cmax=16;
                key_mode =1;
		key=0;
        break;
        case MASTER:
		mblink = 0;edit_pass =0;
		clear_lcd();
		cx = 8;
		cy = 0;
                if(key==1) id++;
                else id=1;
                lcd_puts(0,0, "Mem. No:___     ");
                sprintf(temp_buf,"%d",id);
                lcd_puts(8,0,temp_buf);

		lcd_puts(0,1, "MEMBER NAME:    ");
		lcd_puts(0,2, "_______________ ");
		lcd_puts(0,3, "MOB:_________   ");
		update_lcd();
		fstate++;
		//sstate=0;
		con=1;
                //cmax=16;
                key_mode =0;
                kwait_feed=0;
		key=0;
        break;
        case SET_RTC:
		mblink = 0;edit_pass =0;
		clear_lcd();
		cx = 7;
		cy = 2;

                t = time(NULL);
                tm = *localtime(&t); //tm.tm_mday,tm.tm_mon + 1,tm.tm_year + 1900,tm.tm_hour, tm.tm_min
                sprintf(temp_buf," DATE: %02d/%02d/%02d ",tm.tm_mday,tm.tm_mon + 1,tm.tm_year-100);
                lcd_puts(0,0, " [SYSTEM CLOCK] ");
		lcd_puts(0,2, temp_buf);
                sprintf(temp_buf," TIME: %02d:%02d:%02d ",tm.tm_hour,tm.tm_min,tm.tm_sec);
		lcd_puts(0,3, temp_buf);
		update_lcd();
		fstate++;
		con=1;
                key_mode =0;
                kwait_feed=0;
		key=0;
        break;

        case SES_REP:
		mblink = 0;edit_pass =0;
		clear_lcd();
		cx = 7;
		cy = 2;

                t = time(NULL);
                tm = *localtime(&t); //tm.tm_mday,tm.tm_mon + 1,tm.tm_year + 1900,tm.tm_hour, tm.tm_min
                sprintf(temp_buf," DATE: %02d/%02d/%02d ",tm.tm_mday,tm.tm_mon + 1,tm.tm_year-100);

                lcd_puts(0,0, "[SESSION REPORT]");
		//lcd_puts(0,2, " DATE: --/--/-- ");
                lcd_puts(0,2, temp_buf);
		lcd_puts(0,3, " Mor[1]  Eve[2] ");
		update_lcd();
		fstate++;
		con=1;
                key_mode =0;
                kwait_feed=0;
		key=0;
        break;

        case PAY_REP:
		mblink = 0;edit_pass =0;
		clear_lcd();
		cx = 15;
		cy = 3;
                special_report = 0;
                //lcd_puts(0,0, "[PRINT  REPORTS]");
		lcd_puts(0,0, "Payment Reg.[1] ");
		lcd_puts(0,1, "Bonus Report[2] ");
                lcd_puts(0,2, "Passbook    [3] ");
                lcd_puts(0,3, "Special Rep.[4] ");
		update_lcd();
		fstate++;
		con=1;
                key_mode =0;
                kwait_feed=0;
		key=0;
        break;
        case EDIT:
		mblink = 0;edit_pass =0;
		clear_lcd();
		cx = 7;
		cy = 2;
                t = time(NULL);
                tm = *localtime(&t); //tm.tm_mday,tm.tm_mon + 1,tm.tm_year + 1900,tm.tm_hour, tm.tm_min
                sprintf(temp_buf," DATE: %02d/%02d/%02d ",tm.tm_mday,tm.tm_mon + 1,tm.tm_year-100);
                lcd_puts(0,0, "  [EDIT  DATA]  ");
                lcd_puts(0,2, temp_buf);
		lcd_puts(0,3, " Mor[1]  Eve[2] ");
		update_lcd();
		fstate++;
		con=1;
                key_mode =0;
                kwait_feed=0;
		key=0;
        break;

        case LEDGER:
		mblink = 0;edit_pass =0;
		clear_lcd();
		//special_report = 0;

                t = time(NULL);
                tm = *localtime(&t); //tm.tm_mday,tm.tm_mon + 1,tm.tm_year + 1900,tm.tm_hour, tm.tm_min
                //sprintf(temp_buf," DATE: %02d/%02d/%02d ",tm.tm_mday,tm.tm_mon + 1,tm.tm_year-100);
                if(special_report == 1){
			lcd_puts(0,0, "[SPECIAL REPORT]");
			cy = 2;cx = 6;
			fstate++;
		}
		else{
			if(deduct_report)  lcd_puts(0,0, "[PRINT  DEDUCT.]");
		        else   lcd_puts(0,0, "   [PASSBOOK]   ");

		        lcd_puts(0,1, "Mem.:____,____  ");//MID:0001 to 0005
			cy = 1; cx = 5;
                }
                lcd_puts(0,2, "From: __/__/__  ");
		lcd_puts(0,3, "To  : __/__/__  ");
		update_lcd();
		fstate++;
		con=1;
                key_mode =0;
                kwait_feed=0;
		key=0;
        break;
        case PASSWORD:
  		mblink = 0;
		clear_lcd();
		cx = 5;
		cy = 2;
                t = time(NULL);
                tm = *localtime(&t); //tm.tm_mday,tm.tm_mon + 1,tm.tm_year + 1900,tm.tm_hour, tm.tm_min

                if(edit_pass == 0)  lcd_puts(0,1, "   [PASSWORD]   ");
                else                lcd_puts(0,1, " [NEW PASSWORD] ");


                lcd_puts(0,2, "     ______     ");
		update_lcd();
		fstate++;

		con=1;
                key_mode =0;
                kwait_feed=0;
		key=0;
        break;

        case USBMENU:
		mblink = 0;edit_pass =0;
		clear_lcd();
		cx = 15;
		cy = 3;
        
		lcd_puts(0,0, "UPLOAD RATE [1] ");
		lcd_puts(0,1, "BACKUP      [2] ");
        lcd_puts(0,2, "RESTORE     [3] ");
        lcd_puts(0,3, "SSN TO USB  [4] ");

		update_lcd();
		fstate++;
		con=1;
                key_mode =0;
                kwait_feed=0;
		key=0;
        break;
        case PRINT_OK:
            mblink = 0;edit_pass =0;
            clear_lcd();
            cx = 15;
            cy = 3;
            lcd_puts(0,0, " PRINTING  DONE ");
            lcd_puts(0,2, "   PRESS  KEY   ");
            
            update_lcd();
            //kbhit_wait();
            fstate++;
            con=1;
            key_mode =0;
            kwait_feed=0;
            key=0;
        break;
        case MEMBER:
		mblink = 0;edit_pass =0;
		clear_lcd();
		cx = 15;
		cy = 3;
                lcd_puts(0,0, "[MEMBER OPTIONS]");
		lcd_puts(0,2, "  EDIT      [1] ");
		lcd_puts(0,3, "  PRINT     [2] ");

		update_lcd();
		fstate++;
		con=1;
                key_mode =0;
                kwait_feed=0;
		key=0;
        break;//COLLECTION

        case COLLECTION:
		mblink = 0;edit_pass =0;
		clear_lcd();
		cx = 15;
		cy = 3;
                lcd_puts(0,0, "    [OPTIONS]   ");
		lcd_puts(0,1, "Milk Col.    [1]");
#ifdef PROJ_KMD 
		lcd_puts(0,2, "Edit  Deduct.[2]");
        lcd_puts(0,3, "Print Deduct.[3]");//Print Deduct.[3]
#endif
        id=1;
		update_lcd();
		fstate++;
		con=1;
                key_mode =0;
                kwait_feed=0;
		key=0;
        break;

        case SAVE_SESSION:
		cx = 15;
		cy = 3;
		edit_pass =0;
		clear_lcd();
		mblink = 0;
        /*t = time(NULL);
        tm = *localtime(&t); //tm.tm_mday,tm.tm_mon + 1,tm.tm_year + 1900,tm.tm_hour, tm.tm_min
        sprintf(temp_buf,"SDATE: %02d/%02d/%02d ",tm.tm_mday,tm.tm_mon + 1,tm.tm_year-100);
        lcd_puts(0,1, temp_buf);
        sprintf(temp_buf,"EDATE: %02d/%02d/%02d ",tm.tm_mday,tm.tm_mon + 1,tm.tm_year-100);
        lcd_puts(0,2, temp_buf);
        */
        lcd_puts(0,1,"SINGLE   SSN [1]");
        lcd_puts(0,2,"MULTIPLE SSN [2]");

        update_lcd();
        con=1;
        key=0;

        kwait_feed=0;
        fstate++;
        break;
        case INFO:
            mblink=0;
            cx=15;cy=3;
            clear_lcd();
            

            lcd_puts(0,0,"    DPU  INFO   ");
            lcd_puts(0,1, IMEI);
            
            //update_lcd();
            lcd_puts(0,3, "Checking Network");
            update_lcd();
            c = modem_status();
            sprintf(str_temp,"NETWORK=%02d %c    ",c&0x7F,nstate[c>>7]); lcd_puts(0,3, str_temp);//NETWORK=09 C    
            update_lcd();
            con=0;
            key=0;
            fstate=0;        
            kbhit_wait();
            break;


        default:
            if(fstate==(PRINT_OK+1))
            {
                 fstate = 0;
                 key =1;
                 puts("KBHIT->MAIN SCREEN");
                 return;
            }

            if(fstate==(GET_ID+1))
            {
                cursor_off();
                if((cx == 10||cx == 15) && cy !=1 && key == 'q' && dis_rate!=2) {fstate=0; flag_scan=0;  home_counter=0;return;}
                if(cx == 9 && cy ==1 && key == 'q' && dis_rate!=2) {fstate=0; flag_scan=0;  home_counter=0;return;}
                get_data();

            }
            else if(fstate==(SET_DPU+1))
            {
                cursor_off();
                if(get_text(16,0))         //Collection POint
                {
                  //lcd_buffer[1][cx] = 0;
                  //puts(lcd_buffer[1]);puts("\n");

                  fd = open("/tmp/mmc/dpu_settings.dat",O_WRONLY | O_CREAT, 0666);
                  lseek(fd,0,SEEK_SET);  // Collection Point Name
                  write(fd,lcd_buffer[1],16);
                  close(fd);system("sync");

                  key_mode=0;  cursor_off();cx=5; cy=2;
                  key =0;
                  update_lcd();con=1;
                  fstate++;
                }
                //--key =0;
            }
            else if(fstate==(SET_DPU+2))    // Collection Code
            {
                cursor_off();
                if(get_text(9,5))
                {
                  //lcd_buffer[2][cx] = 0;
                  //puts(lcd_buffer[2]);puts("\n");

                  fd = open("/tmp/mmc/dpu_settings.dat",O_WRONLY | O_CREAT, 0666);
                  lseek(fd,16,SEEK_SET);
                  write(fd,lcd_buffer[2],16);
                  close(fd);system("sync");

                  key_mode=1; cursor_off();cx=4; cy=3;
                  update_lcd();con=1;
                  key =0;
                  fstate++;
                }
                //--key =0;
            }
            else if(fstate==(SET_DPU+3))           //Project Code
            {
                cursor_off();
                if(get_text(8,4))
                {

                  fd = open("/tmp/mmc/dpu_settings.dat",O_WRONLY | O_CREAT, 0666);
                  lseek(fd,32,SEEK_SET);
                  write(fd,lcd_buffer[3],16);
                  close(fd);system("sync");

                  key_mode=0; cursor_off();cx=12; cy=3;
                  update_lcd();
                  con=1;
                  key =0;
                  fstate++;
                }
                //--key =0;
            }

            else if(fstate==(SET_DPU+4))    // Dist Code
            {
                cursor_off();
                if(get_text(16,12))
                {
                  fd = open("/tmp/mmc/dpu_settings.dat",O_WRONLY | O_CREAT, 0666);  //
                  lseek(fd,32,SEEK_SET);  // Project & Dist
                  write(fd,lcd_buffer[3],16);
                  close(fd);
                  system("sync");

                  load_settings();
                  cursor_off();
                  mblink =0;
                  clear_lcd();


                lcd_puts(0,0, "Server IP:      ");
		if(dpu_settings[4][0] == 0)   lcd_puts(0,1, "___.___.___.___");
                else                          lcd_puts(0,1, dpu_settings[4]);

		if(dpu_settings[5][0] == 0)   lcd_puts(0,2, "BSNL PRNT:T TR:Y");//lcd_puts(0,2, "NETWORK:_ TARE:Y");
                else                          lcd_puts(0,2, dpu_settings[5]);


		if(dpu_settings[6][0] == 0)   lcd_puts(0,3, "COW/BUF:Y  SMS:N");
                else                          lcd_puts(0,3, dpu_settings[6]);
                key =0;

                  key_mode=0; cursor_off();cx=0; cy=1;
                  update_lcd();
                  con=1;
                  fstate++;
                }
                //--key =0;
            }

            else if(fstate==(SET_DPU+5))    // IP
            {
                cursor_off();
                if(get_text(15,0))
                {

                  fd = open("/tmp/mmc/dpu_settings.dat",O_WRONLY | O_CREAT, 0666);
                  lseek(fd,64,SEEK_SET);  //
                  write(fd,lcd_buffer[1],16);
                  close(fd);system("sync");


                  key_mode=0; cursor_off();cx=4; cy=2;id=0;
                  if(lcd_buffer[2][0] == 'B' ) id=0;if(lcd_buffer[2][0] == 'V' ) id=1;if(lcd_buffer[2][0] == 'I' ) id=2;if(lcd_buffer[2][3] == 'T' ) id=3;if(lcd_buffer[2][0] == 'D' ) id=4;if(lcd_buffer[2][0] == 'R' ) id=5;
                  id++;//if(id > 5)id=0;
                  update_lcd();
                  con=1;
                  fstate++;
                }
                key =0;
            }
            else if(fstate==(SET_DPU+6))    // OPERATOR
            {
                if(key == 'q') {fstate=0;home_counter=0;return;}
                cursor_off();
                if(key=='0' )
                {
                  if(id > 5)id=0;
                  lcd_puts(0,2,network[id++]);



                }
		else if(key == 0x0a)
		{

            memcpy(str_buf,lcd_buffer[1],15); str_buf[15]=0;
            strcpy(str_buf,"dpu.agdisk.com");
            //strcpy(str_buf," 81.30.148.92");
		    usleep(200000);
			EN_GPRS;

            set_interface_attribs (uart0_fd, B9600, 0);
            usleep(200000);
			//sprintf(temp_buf,"-DEVICE_CFG\n\n$5,00000206,%s,4001,%s,,8866487120,10,1,1,1,3,8,n,1,300,",str_buf,apn[id-1]);
            //if(modem_type==0)
			//sprintf(temp_buf,"-DEVICE_CFG\n\n$5,00000206,%s,80,%s,G,9737961259,10,1,1,1,3,8,n,1,300,",str_buf,apn[id-1]);
            //else
            sprintf(temp_buf,"-DEVICE_CFG\n\n$5,00000206,%s,80,%s,,9737961259,x,y,z,0,0,1,1,1,3,8,Y,0,300,",str_buf,apn[id-1]);
			//sprintf(temp_buf,"-DEVICE_CFG\n\n$9,00000206,%s,4001,%s,G,9737961259,10,1,1,1,3,8,n,1,300,",str_buf,apn[id-1]);
			//sprintf(temp_buf,"-DEVICE_CFG\n\n$5,00000206,%s,4001,%s,,9925366841,10,1,1,1,3,8,n,1,300,",str_buf,apn[id-1]);
			i=strlen(temp_buf);
			temp_buf[0]=0x01; write(uart0_fd,temp_buf,i);
			puts(temp_buf);
			usleep(200000);
            //set_interface_attribs (uart1_fd, B2400, 0);

		    fd = open("/tmp/mmc/dpu_settings.dat",O_WRONLY | O_CREAT, 0666);
		    lseek(fd,80,SEEK_SET);  //
		    write(fd,lcd_buffer[2],16);
		    close(fd);system("sync");

		    key_mode=0; cursor_off();cx=10; cy=2;
		    fstate++;
		}
                 update_lcd();
                 con =1;
                 key =0;
            }

            else if(fstate==(SET_DPU+7))    // PRINTER
            {
                 if(key == 'q') {fstate=0;home_counter=0;return;}
                 con =0;
                 cursor_off();
                 if(key == '0' && lcd_buffer[2][10] == 'T' ){c ='D';lcd_putc(10,2,c);puts("D\n");}
                 else if(key == '0' && lcd_buffer[2][10] == 'D' ){c ='T';lcd_putc(10,2,c);puts("T\n");}
                 else if(key == 0x0a)
                 {
		    fd = open("/tmp/mmc/dpu_settings.dat",O_WRONLY | O_CREAT, 0666);
		    lseek(fd,80,SEEK_SET);  //
		    write(fd,lcd_buffer[2],16);
		    close(fd);system("sync");

	            key_mode=0; cursor_off();cx=15; cy=2;
	            fstate++;
                 }
                 update_lcd();
                 con =1;
                 key =0;
            }


            else if(fstate==(SET_DPU+8))    // TARE
            {
                 if(key == 'q') {fstate=0;home_counter=0;return;}
                 con =0;
                 cursor_off();
                 if(key == '0' && lcd_buffer[2][15] == 'Y' ){c ='N';lcd_putc(15,2,c);puts("N\n");}
                 else if(key == '0' && lcd_buffer[2][15] == 'N' ){c ='Y';lcd_putc(15,2,c);puts("Y\n");}
                 
                 
                 
                 else if(key == 0x0a)
                 {
		    fd = open("/tmp/mmc/dpu_settings.dat",O_WRONLY | O_CREAT, 0666);
		    lseek(fd,80,SEEK_SET);  //
		    write(fd,lcd_buffer[2],16);
		    close(fd);system("sync");

	            key_mode=0; cursor_off();cx=8; cy=3;
	            id=0;
	            if(lcd_buffer[3][8] == 'N' ) id=0;
	            if(lcd_buffer[3][8] == 'Y' ) id=1;
	            if(lcd_buffer[3][8] == 'S' ) id=2;
	            fstate++;
                 }
                 update_lcd();
                 con =1;
                 key =0;
                 
            }


            else if(fstate==(SET_DPU+9))    // cow-buf
            {
                 if(key == 'q') {fstate=0;home_counter=0;return;}
                 con =0;
                 cursor_off();
                 if(key == '0' && id ==0){c ='N';lcd_putc(8,3,c);puts("N\n");}
                 if(key == '0' && id ==1){c ='Y';lcd_putc(8,3,c);puts("N\n");}
                 if(key == '0' && id ==2){c ='S';lcd_putc(8,3,c);puts("N\n");}
                 
                 
                 //else if(key == '0' && lcd_buffer[3][8] == 'N' ){c ='Y';lcd_putc(8,3,c);puts("Y\n");}
                 id++;
                 if(id>2)id=0;
                 
                 else if(key == 0x0a)
                 {
		    fd = open("/tmp/mmc/dpu_settings.dat",O_WRONLY | O_CREAT, 0666);
		    lseek(fd,96,SEEK_SET);  //
		    write(fd,lcd_buffer[3],16);
		    close(fd);system("sync");

	            key_mode=0; cursor_off();cx=15; cy=3;
	            fstate++;
                 }
                 update_lcd();
                 con =1;
                 key =0;
            }
            else if(fstate==(SET_DPU+10))    // SMS
            {
                 if(key == 'q') {fstate=0;home_counter=0;return;}
                 con =0;
                 cursor_off();
                 if(key == '0' && lcd_buffer[3][15] == 'Y' ){c ='N';lcd_putc(15,3,c);puts("N\n");}
                 else if(key == '0' && lcd_buffer[3][15] == 'N' ){c ='Y';lcd_putc(15,3,c);puts("Y\n");}
                 else if(key == 0x0a)
                 {
		    fd = open("/tmp/mmc/dpu_settings.dat",O_WRONLY | O_CREAT, 0666);  //
	            lseek(fd,96,SEEK_SET);  // cow/buf AND sms
		    write(fd,lcd_buffer[3],16);
	            close(fd);system("sync");
	            
	            system("echo 0 > /tmp/mmc/ws_mode.txt;sync"); //save LT mode

                    load_settings();
	            key_mode=0; cursor_off();cx=16; cy=0;
                    edit_pass =1;
	            fstate=PASSWORD;  //New Password
                    key=1;return;
                 }
                 else if(key == '8')  // KG mode 
                 {
		    fd = open("/tmp/mmc/dpu_settings.dat",O_WRONLY | O_CREAT, 0666);  //
	            lseek(fd,96,SEEK_SET);  // cow/buf AND sms
		    write(fd,lcd_buffer[3],16);
	            close(fd);system("sync");
	            
	           
                    system("echo 1 > /tmp/mmc/ws_mode.txt;sync"); //save KG mode

                    load_settings();
	            key_mode=0; cursor_off();cx=16; cy=0;
                    edit_pass =1;
	            fstate=PASSWORD;  //New Password
                    key=1;return;                  
                 }
                 
                 update_lcd();
                 con =1;
                 key =0;
            }

			else if(fstate==(MASTER+1))    // MID
			{
				cursor_off();
				
				if(get_text(13,8))
				{
					
					
					i=0;memcpy(temp_buf,&lcd_buffer[0][8],4); while(i<5){if(temp_buf[i++]=='_')break;} temp_buf[i-1]=0;
					id = atoi(temp_buf);

					sprintf(temp_buf,"%04d",id);
					lcd_puts(8,0,temp_buf);

					fd = open("/tmp/mmc/member.dat",O_RDONLY);  //
					lseek(fd,id*32,SEEK_SET);
					read(fd,lcd_buffer[2],16);
					for(i=0;i<15;i++) { if( isalnum(lcd_buffer[2][i]) == 0 && lcd_buffer[2][i] != ' ') lcd_buffer[2][i] = '_';}

					read(fd,&lcd_buffer[3][4],10);
					for(i=4;i<13;i++) { if( isdigit(lcd_buffer[3][i]) == 0) lcd_buffer[3][i] = '_';}

					close(fd);system("sync");
					memcpy(lcd_buffer[3],"MOB:",4);
					lcd_puts(0,2,lcd_buffer[2]);
					lcd_puts(0,3,lcd_buffer[3]);


					key_mode=1; cursor_off();cx=0; cy=2;
					update_lcd();con=1;
					fstate++;
					key =0;
				}
				//--key =0;
			}
			else if(fstate==(MASTER+2))    // MEMBER NAME
			{

				cursor_off();
				if(get_text(16,0))
				{
					//lcd_buffer[2][cx] = 0;
					//puts(lcd_buffer[2]);puts("\n");
					key_mode=0; cursor_off();cx=4; cy=3;
					update_lcd();con=1;
					fstate++;
				}
				key =0;
			}
			else if(fstate==(MASTER+3))    // MEMBER PHONE
			{
				cursor_off();
				if(get_text(15,1))
				{
					key_mode=0; cursor_off();cx=16; cy=0;
					fstate++;  //again to master entry
					cx = 0;
					cy = 2;
		
					if(id<2000)
					{
						fd = open("/tmp/mmc/member.dat",O_WRONLY | O_CREAT, 0666);
						lseek(fd,id*32,SEEK_SET);
						write(fd,lcd_buffer[2],16);      //member name
						lcd_buffer[3][14]=0;//10DIGIT ONLY
						write(fd,&lcd_buffer[3][4],16);  //member mobile
						close(fd);
						printf("member id=%d\n",id);
                        
                        memcpy(temp_buf,lcd_buffer[2],16);
						for(i=0;i<16;i++){if(isalpha(lcd_buffer[2][i])<=0 && lcd_buffer[2][i] != ' '  ){temp_buf[i]=0;break;}}temp_buf[16]=0;
						puts(temp_buf);

						for(i=0;i<15;i++){if(isdigit(lcd_buffer[3][4+i])<=0){memcpy(&temp_buf[20],&lcd_buffer[3][4],10);temp_buf[20+i]=0;break;}}
						
						puts(&temp_buf[20]);

						system("sync");
                        /* 
						memcpy(str_buf,&dpu_settings[2][4],3);str_buf[3]=0;      // project code
						memcpy(&str_buf[6],&dpu_settings[2][12],4);str_buf[10]=0; // dist code
						memcpy(&str_buf[11],&dpu_settings[1][5],4);str_buf[15]=0;// collect point code

						t = time(NULL);
						tm = *localtime(&t); //tm.tm_mday,tm.tm_mon + 1,tm.tm_year + 1900,tm.tm_hour, tm.tm_min

						//%VIZ/R/010104//123/4/1005/0009/NAME/SIRNAME/FATHERNAME/02-05-1987/8745847578/18092019/00:29/F/I867793038116143$
						sprintf(str_temp,"%%%s/R/%02d%02d%02d/%s/%s/%04d/%.*s/NA/NA/01-01-1980/%.*s/%02d%02d20%02d/%02d:%02d/F/I%s$",str_buf,tm.tm_mday,tm.tm_mon + 1,tm.tm_year-100,&str_buf[6],&str_buf[11],id,15,temp_buf,10,&temp_buf[20],tm.tm_mday,tm.tm_mon + 1,tm.tm_year-100,tm.tm_hour,tm.tm_min,IMEI);
						//puts(str_temp);
						set_interface_attribs (uart0_fd, B9600, 0);

						EN_GPRS;
						sleep(1);

						if(strcmp("000.000.000.000 ",dpu_settings[4])!=0  && dpu_settings[6][15]=='N')
						{
							ws_write(uart0_fd,str_temp,strlen(str_temp));
							puts(str_temp);
						}*/
						lcd_puts(0,1, "ACCOUNT #:      ");
						lcd_puts(0,2, "_______________ ");
						lcd_puts(0,3, "IFSC:__________ ");
						//fill account# and IFSC
						fd = open("/tmp/mmc/member.dat",O_RDONLY);  
						lseek(fd,128000+(id*32),SEEK_SET);
						read(fd,lcd_buffer[2],16);
						for(i=0;i<15;i++) { if( isdigit(lcd_buffer[2][i]) == 0 && lcd_buffer[2][i] != ' ') lcd_buffer[2][i] = '_';}
						read(fd,&lcd_buffer[3][5],11);
						for(i=5;i<16;i++) { if( isalnum(lcd_buffer[3][i]) == 0 && lcd_buffer[2][i] != ' ') lcd_buffer[3][i] = '_';}

						close(fd);
					}
				    



					update_lcd();		
					con=1;						
                   
					key=0;//key = 1; return;
				}
			}
			else if(fstate == MASTER+4)//acount#
			{
				cursor_off();
				if(key == 'q')
				{
					lcd_puts(0,2, "_______________ ");
					update_lcd();
					cx = 0;
					cy = 2;	
					key=0;				
				}				
				if(get_text(16,0))
				{
					key_mode=1; cursor_off();cx=5; cy=3;
					fstate++;  //again to master entry
					cx = 5;
					cy = 3;

				}

                key = 0;
			} 
			else if(fstate == MASTER+5)//IFSC
			{
				cursor_off();
				if(key == 'q')
				{
					lcd_puts(0,3, "IFSC:__________ ");
					update_lcd();
					cx = 5;
					cy = 3;	
					key=0;				
				}					
				if(get_text(16,5))
				{
					key_mode=0; cursor_off();cx=5; cy=3;
					fstate = MASTER;  //again to master entry
						
					fd = open("/tmp/mmc/member.dat",O_WRONLY | O_CREAT, 0666);
					lseek(fd,128000+(id*32),SEEK_SET);
					write(fd,lcd_buffer[2],16);      //account#
					lcd_buffer[3][16]=0;//10DIGIT ONLY
					write(fd,&lcd_buffer[3][5],12);  //IFSC code
					close(fd);
          
					for(i=0;i<16;i++){if(isdigit(lcd_buffer[2][i])<=0){memcpy(&temp_buf[50],lcd_buffer[2],16);temp_buf[50+i]=0;break;}}
					for(i=0;i<16;i++){if(isalnum(lcd_buffer[3][5+i])<=0){memcpy(&temp_buf[70],&lcd_buffer[3][5],15);temp_buf[70+i]=0;break;}}

					/**/
          for(i=50;i<86;i++)//account# and ifsc
					{
						if(isalnum(temp_buf[i])<=0) temp_buf[i]=0;
					}
					temp_buf[50+16] =0;
          temp_buf[70+16] =0;

					puts("name:");
					puts(temp_buf);

					memcpy(str_buf,&dpu_settings[2][4],3);str_buf[3]=0;      // project code
					memcpy(&str_buf[6],&dpu_settings[2][12],4);str_buf[10]=0; // dist code
					memcpy(&str_buf[11],&dpu_settings[1][5],4);str_buf[15]=0;// collect point code

					t = time(NULL);
					tm = *localtime(&t); //tm.tm_mday,tm.tm_mon + 1,tm.tm_year + 1900,tm.tm_hour, tm.tm_min

					//%VIZ/R/010104//123/4/1005/0009/NAME/SIRNAME/FATHERNAME/02-05-1987/8745847578/18092019/00:29/F/I867793038116143$
					sprintf(str_temp,"%%%s/K/%02d%02d%02d/%s/%s/%04d/%.*s/NA/NA/01-01-1980/%.*s/%s/%s/%02d%02d20%02d/%02d:%02d/F/I%s$",str_buf,tm.tm_mday,tm.tm_mon + 1,tm.tm_year-100,&str_buf[6],&str_buf[11],id,16,temp_buf,10,&temp_buf[20],&temp_buf[50],&temp_buf[70],tm.tm_mday,tm.tm_mon + 1,tm.tm_year-100,tm.tm_hour,tm.tm_min,IMEI);
					puts(str_temp);
					set_interface_attribs (uart0_fd, B9600, 0);

					EN_GPRS;
					sleep(1);

					if(strcmp("000.000.000.000 ",dpu_settings[4])!=0  && dpu_settings[6][15]=='N')
					{
						ws_write(uart0_fd,str_temp,strlen(str_temp));
						puts(str_temp);
					}





					con =1;
					key=1;
					return;
				}
                key = 0;
			} 

            else if(fstate==(SET_RTC+1))    // RTC-DATE
            {
                cursor_off();
                if(get_text(15,7))
                {
		  key_mode=0; cursor_off();cx=7; cy=3;
		  fstate++;  //to main menu
                  key =0;
                }
                //--key =0;
            }
            else if(fstate==(SET_RTC+2))    // RTC-TIME
            {
                cursor_off();
                if(get_text(15,7))
                {
		  key_mode=0; cursor_off();cx=16; cy=0;
		  fstate=0;  //to main menu

                  memcpy(temp_buf,&lcd_buffer[2][7],8); temp_buf[2]=temp_buf[5]=temp_buf[8]=0;
		  sprintf(str,"i2cset -y 1 0x51 0x05 0x%s",&temp_buf[0]); system(str); puts(str);//Day
		  sprintf(str,"i2cset -y 1 0x51 0x07 0x%s",&temp_buf[3]); system(str); puts(str);//Month
		  sprintf(str,"i2cset -y 1 0x51 0x08 0x%s",&temp_buf[6]); system(str); puts(str);//Year
                  puts(str);
                  memcpy(temp_buf,&lcd_buffer[3][7],8); temp_buf[2]=temp_buf[5]=temp_buf[8]=0;
		  sprintf(str,"i2cset -y 1 0x51 0x04 0x%s",&temp_buf[0]); system(str); puts(str);//Hour
		  sprintf(str,"i2cset -y 1 0x51 0x03 0x%s",&temp_buf[3]); system(str); puts(str);//Min
		  sprintf(str,"i2cset -y 1 0x51 0x02 0x%s",&temp_buf[6]); system(str); puts(str);//Sec
                  load_rtc();
                  key = 1; return;
                }
                //--key =0;
            }
            else if(fstate==(SES_REP+1))    // SR-DATE
            {
                cursor_off();
                if(get_text(15,7))
                {
		  key_mode=0; cursor_off();cx=15; cy=3;
		  fstate++;  //to main menu
                }
                //--key =0;
            }
            else if(fstate==(SES_REP+2))    //  Morning or Evening ?
            {
                if(key == 'q') {fstate=0;home_counter=0;return;}
                cursor_off();
                memcpy(str_buf,&lcd_buffer[2][7],8); str_buf[8]=0;
                session=0;
                if(key == '1') //morning
                {
                  puts("print morning");session=1;
                }
                else if(key == '2')        //evening
                {
                  puts("print evening");session=2;
                }

                if(session)
                {
		        clear_lcd();
		        lcd_puts(0,0, "   [PRINT  ?]   ");

		        lcd_puts(0,1, " REPORT     [1] ");
		        lcd_puts(0,2, " SUMMARY    [2] ");
                        lcd_puts(0,3, " DAILY REP. [3] ");

		        update_lcd();con=1;
			key_mode=0; cursor_off();cx=15; cy=3;
                        union_index =0;
                        //key =;
			fstate++;
                }
                key =0;
            }
            else if(fstate==(SES_REP+3))    //  Report  or Summary..?
            {
               if(key == 'q') {fstate=0;home_counter=0;return;}
               if(key == '1')  // report
               {
                 print_options();clear_lcd();  
                 print_session_report(1,session,0);
                 if(dpu_settings[6][8] == 'Y' || dpu_settings[6][8] == 'S')print_session_report(1,session,1);

               }
               else if(key == '2') // summery
               {
                 //---print_where();
                 //---print_session_report(2,session,0); // BUF/MIX
                 //---if(dpu_settings[6][8] == 'Y')print_session_report(2,session,1); //COW
                 clear_lcd();con = 0;cursor_off();
                 summery_buf_can=0;
		         summery_cow_can=0;
                 lcd_puts(0,1, "No. Of CAN: __   ");
                 if(dpu_settings[6][8] == 'Y')
                 {
                    lcd_puts(0,1, "  Buf  CAN: __   ");
                    lcd_puts(0,2, "  Cow  CAN: __   ");
                 }
                 update_lcd();
                 fstate = SES_REP+10;
                 key_mode=0;con =1;cx=12; cy=1;
                 key=0;
                 return;
               }
               else if(key == '3') // DAIRY REPORT
               {
		        clear_lcd();
                        con = 0;cursor_off();

                        if(dpu_settings[6][8] == 'Y' && union_index==0)
                        lcd_puts(0,0, " [BUFFALO MILK] ");
                        else if(dpu_settings[6][8] == 'Y' && union_index==1)
                        lcd_puts(0,0, "   [COW MILK]   ");

                        if(dpu_settings[6][8] == 'N')
                        lcd_puts(0,0, "   [MIX MILK]   ");


		                lcd_puts(0,2, "Local:000.00 Ltr");
		                lcd_puts(0,3, "Amount:00000.00 ");
                        update_lcd();
                        key_mode=0;con =1;cx=6; cy=2;fstate++;
                        key =0;
               }

               if(key == '1' || key == '2'||display_en)
               {
	         key_mode=0; cursor_off();cx=16; cy=0;
                 if(display_en==0) fstate=PRINT_OK;   
                 else              fstate=0;
                 display_en = 0;
                 return;
               }
               key =0;

            }

		else if(fstate==(SES_REP+4))    //  Local sale Liter
		{
			cursor_off();
			if(get_text(12,6))
			{
                                memcpy(temp_buf,&lcd_buffer[2][6],6); temp_buf[6]=0;
                                uinfo[union_index].local_sale = atof(temp_buf);

				key_mode=0; cursor_off();cx=7; cy=3;
			  	update_lcd();
			  	con=1;
			  	fstate++;
			}
			key =0;
		}
		else if(fstate==(SES_REP+5))    //  Local Sale amount
		{
			cursor_off();
			if(get_text(15,7))
			{
                                memcpy(temp_buf,&lcd_buffer[3][7],8); temp_buf[8]=0;
                                uinfo[union_index].lamount = atof(temp_buf);
				clear_lcd();
		                con = 0;cursor_off();

				key_mode=0; cursor_off();cx=6; cy=0;
				if(ws_mode==0) 
				lcd_puts(0,0, "Union:____.__ Lt");
				else
				lcd_puts(0,0, "Union:____.__ Kg");
				
				lcd_puts(0,1, "FAT  :__._      ");
                if(fat_only==0)
				lcd_puts(0,2, "SNF  :__._      ");
				lcd_puts(0,3, "Amount:_____.__ ");

			  	update_lcd();
			  	con=1;
			  	fstate++;
			}
			key =0;
		}
		else if(fstate==(SES_REP+6))    //  Union Liter
		{
			cursor_off();
			if(get_text(13,6))
			{
                                memcpy(temp_buf,&lcd_buffer[0][6],7); temp_buf[7]=0;
                                uinfo[union_index].union_receipt = atof(temp_buf);
				key_mode=0; cursor_off();cx=6; cy=1;
			  	update_lcd();
			  	con=1;
			  	fstate++;
			}
			key =0;
		}
		else if(fstate==(SES_REP+7))    //  Milk FAT
		{
			cursor_off();
			if(get_text(10,6))
			{
				memcpy(temp_buf,&lcd_buffer[1][6],4); temp_buf[4]=0;
                                uinfo[union_index].milk_fat = atof(temp_buf);
                key_mode=0; cursor_off();
                if(fat_only){fstate++;cx=7; cy=3;}
                else {cx=6; cy=2;}
			  	update_lcd();
			  	con=1;
			  	fstate++;

			}
			key =0;
		}
		else if(fstate==(SES_REP+8))    //  Milk SNF
		{
			cursor_off();
			if(get_text(10,6))
			{
 				memcpy(temp_buf,&lcd_buffer[2][6],4); temp_buf[4]=0;
                                uinfo[union_index].milk_snf = atof(temp_buf);
				key_mode=0; cursor_off();cx=7; cy=3;
			  	update_lcd();
			  	con=1;
			  	fstate++;
			}
			key =0;
		}

		else if(fstate==(SES_REP+9))    //  Union Amount
		{
			cursor_off();
			if(get_text(15,7))
			{
 				memcpy(temp_buf,&lcd_buffer[3][7],8); temp_buf[8]=0;
                                uinfo[union_index].uamount = atof(temp_buf);
				key_mode=0; cursor_off();cx=6; cy=1;
			  	update_lcd();
			  	con=1;
                                union_index++;
                                if(dpu_settings[6][8] == 'Y' && union_index <=1) {fstate = (SES_REP+3);  key = '3'; return;}
                                else
                                {
				  print_session_report(2,session,0); // BUF/MIX
				  if(dpu_settings[6][8] == 'Y' || dpu_settings[6][8] == 'S')print_session_report(2,session,1); //COW
                                  fstate=0;
	                          key_mode=0; cursor_off();cx=16; cy=0;
	                          fstate=PRINT_OK;   return;
                                }
			}
			key =0;
		}
		else if(fstate==(SES_REP+10)) // BUF/MIX CAN INPUT
		{
		    cursor_off();

			if(get_text(14,12))
			{
			    lcd_buffer[1][14]=0;
			    summery_buf_can = atoi(&lcd_buffer[1][12]);
			    cy=2;cx=12;
			  	con=1;
			  	fstate++;
                key=0;
                if(dpu_settings[6][8] == 'N')  key = 0x0a;
			}
		}
		else if(fstate==(SES_REP+11)) // COW CAN INPUT
		{
		    cursor_off();
			if(get_text(14,12))
			{

			    lcd_buffer[2][14]=0;
			    summery_cow_can = atoi(&lcd_buffer[2][12]);
			  	con=1;
                key=0;

                printf("buf_can=%d,cow_can=%d\r\n",summery_buf_can,summery_cow_can);

                print_where();
                print_session_report(2,session,0); // BUF/MIX
                if(dpu_settings[6][8] == 'Y' || dpu_settings[6][8] == 'S' )print_session_report(2,session,1); //COW

                 key_mode=0;con =1;
                 fstate=0;
                 key=1;
                 return;
			}

		    
		}


            else if(fstate==(PAY_REP+1))
            {
               if(key == 'q') {fstate=0;home_counter=0;return;}
               cursor_off();
               if(key == '1')  // PAYMENT REGISTER
               {
                 lcd_puts(0,0, " [PAYMENT REG.] ");
                 lcd_puts(0,1, "                ");
                 fstate =(PAY_REP+3);
                 key_mode=0; cursor_off();cx=6; cy=2;
               }
               else if(key == '2')           // BONUS REGISTER
               {
                 lcd_puts(0,0, "[BONUS REGISTER]");
                 lcd_puts(0,1, "Bonus(%):__.__  ");
                 key_mode=0; cursor_off();cx=9; cy=1;
                 fstate++;
               }
               else if(key == '3' || key == '4')           // PASSBOOK or SPECIAL
               {
                 fstate = LEDGER;
                 if(key == '4') special_report = 1;
                 key = 1; return;
               }
               if(key == '1' || key == '2')
               {

                lcd_puts(0,2, "From: __/__/__  ");
		lcd_puts(0,3, "To  : __/__/__  ");
                update_lcd();
		con=1;
               }
               key =0;

            }
            /*
            else if(fstate==(PAY_REP+2))    // MID
            {
                cursor_off();
                if(get_text(8,4))
                {
                  memcpy(temp_buf,&lcd_buffer[0][4],4);temp_buf[4] =0;
                  id = atoi(temp_buf); // member id

		  key_mode=0; cursor_off();cx=9; cy=1;
		  fstate++;  //to main menu
                }
                //--key =0;
            }
            */
            else if(fstate==(PAY_REP+2))    // BONUS %
            {
                cursor_off();
                if(get_text(14,9))
                {
                  memcpy(temp_buf,&lcd_buffer[1][9],5); temp_buf[5]=0;
                  bonus = atof(temp_buf);
		  key_mode=0; cursor_off();cx=6; cy=2;
		  fstate++;  //to main menu
                }
                //--key =0;
            }

            else if(fstate==(PAY_REP+3))    // FROM-DATE
            {
                cursor_off();
                if(get_text(14,6))
                {
		  key_mode=0; cursor_off();cx=6; cy=3;
		  fstate++;  //to main menu
                  //key =0;
                }
                //--key =0;
            }

            else if(fstate==(PAY_REP+4))    // TO-DATE
            {
                cursor_off();
                if(get_text(14,6))
                {
		  key_mode=0; cursor_off();cx=15; cy=3;
                  //puts(lcd_buffer[0]);puts("\n");
                  if(lcd_buffer[0][2] == 'P')  //PAYMENT REPORT
                  {
                      
                     puts("Print Payment Register\n");
                     print_payment_report(&lcd_buffer[2][6],&lcd_buffer[3][6]);
                  }
                  else if(lcd_buffer[0][2] == 'O')  //BONUS REPORT
                  {
                     puts("Print Bonus Register\n");
                     print_bonus_report(id,&lcd_buffer[2][6],&lcd_buffer[3][6]);

                  }
          
                  if(display_en==0){fstate=PRINT_OK;}  //to main menu
                  else             fstate=0;
                  display_en = 0;
                }
                //key =0;
            }


            else if(fstate==(EDIT+1))    // SR-DATE
            {
                cursor_off();
                if(get_text(15,7))
                {
		  key_mode=0; cursor_off();cx=15; cy=3;
		  fstate++;  //to main menu
                  key =0;
                }
                //key =0;
            }
            else if(fstate==(EDIT+2))    //  Morning or Evening ?
            {
                if(key == 'q') {fstate=0;home_counter=0;return;}
                cursor_off();
                memcpy(manual_date,&lcd_buffer[2][7],8); manual_date[8]=0;
                session=0;
                if(key == '1') //morning
                {
                  puts("edit morning");session=1;
                }
                else if(key == '2')        //evening
                {
                  puts("edit evening");session=2;
                }
                if(session)
                {
			key_mode=0; cursor_off();
			fstate = GET_ID;
		        edit_mode = 1;//manual edit mode with specific date and session
                        key =1;return;
                }
                key = 0;

            }
            else if(fstate==(LEDGER+1))    // MID.FROM - TO
            {
                cursor_off();
                if(get_text(14,5))
                {
                  memcpy(temp_buf,&lcd_buffer[0][5],4);temp_buf[4] =0;
                  id = atoi(temp_buf); // member from id

                  memcpy(temp_buf,&lcd_buffer[0][5],4);temp_buf[4] =0;
                  id = atoi(temp_buf); // member to id

		  key_mode=0; cursor_off();cx=6; cy=2;
		  fstate++;
                }
                //--key =0;
            }
            else if(fstate==(LEDGER+2))    // From-DATE
            {
                cursor_off();
                if(get_text(14,6))
                {
		  key_mode=0; cursor_off();cx=6; cy=3;
		  fstate++;
                }
                key =0;
            }

            else if(fstate==(LEDGER+3))    // To-DATE
            {
                cursor_off();
                if(get_text(14,6))
                {
                  puts("printing passbook");
                  print_passbook();

		  key_mode=0; cursor_off();cx=16; cy=0;
		  if(display_en==0)fstate=PRINT_OK;
                  else             fstate=0;
                  display_en=0;
                }
                //--key =0;
            }

            else if(fstate==(PASSWORD+1))    // PASSWORD
            {
                cursor_off();


                if(get_password(11,5))
                {
                  puts(str_buf);puts("\r\n");
                  key_mode=0; cursor_off();cx=4; cy=3;
                  update_lcd();con=0;
                  //if(!usb_inserted)
                  {

		          if(edit_pass)
		          {
		            fstate=0;
		            sprintf(temp_buf,"echo \"%s\" > /tmp/mmc/pwd.dat",str_buf);
		            system(temp_buf); // write new password
		            edit_pass=0;
		          }
		          else
		          {

		            system_call("cat /tmp/mmc/pwd.dat",temp_buf);
		            temp_buf[6] =0;
		            if(strcmp(temp_buf,str_buf)==0) // password match
                            {
                              if(usb_inserted==1) fstate=USBMENU;
                              else if(usb_inserted ==5)
                              {
				                lcd_notify(" [Restoring...] ",1);
				                system("mkdir /tmp/mmc/evening");
				                system("mkdir /tmp/mmc/morning");
				                puts("Restore\n");

				                system_cmd("cp /tmp/usb/backup",scode,"/morning/* ","/tmp/mmc/morning/","");
				                system_cmd("cp /tmp/usb/backup",scode,"/evening/* ","/tmp/mmc/evening/","");
				                system_cmd("cp /tmp/usb/backup",scode,"/member.dat ","/tmp/mmc/","");
				                system_cmd("cp /tmp/usb/backup",scode,"/dpu_settings.dat ","/tmp/mmc/","");
				                system_cmd("cp /tmp/usb/backup",scode,"/msg.txt ","/tmp/mmc/","");
				                system_cmd("cp /tmp/usb/backup",scode,"/dpu.cfg ","/tmp/mmc/","");

				                /*
				                system("cp /tmp/usb/backup/morning/*  /tmp/mmc/morning/");
				                system("cp /tmp/usb/backup/evening/*  /tmp/mmc/evening/");
				                system("cp /tmp/usb/backup/member.dat /tmp/mmc/");
				                system("cp /tmp/usb/backup/dpu_settings.dat /tmp/mmc/");
                                system("cp /tmp/usb/backup/print.txt /tmp/mmc/");
                                system("cp /tmp/usb/backup/msg.txt /tmp/mmc/"); //regional message file
                                system("cp /tmp/usb/backup/dpu.cfg /tmp/mmc/"); //factory fuese configuration
                                */
		                        system("sync");
                                lcd_notify(" [Restore Done] ",1);
                                sleep(5);
                                usb_inserted =0;fstate=0;key=1;return;

                              }

                              else if(edit_rtc==1)
                              {
                               fstate=SET_RTC;
                               edit_rtc = 0;
                              }
                              else if(edit_record==1)
                              {
                                fstate=EDIT;
                                edit_record=0;
                              }
		                      else  fstate=SET_DPU;
                            }
		                else
                            {

		              //fstate=PASSWORD;
			      t = time(NULL);
			      tm = *localtime(&t);
		              sprintf(temp_buf,"%02d%02d%02d",tm.tm_mday,tm.tm_mon+1,tm.tm_year-100);
                              if(strcmp(temp_buf,str_buf)==0) // compare with current date
                              {

                                 reset_password++;
                                 if(reset_password>2)//repeated 3 times
                                 {
                                    system("echo \"000000\" > /tmp/mmc/pwd.dat");  //default password
                                    puts("password reset...\n");reset_password=0;
                                    clear_lcd();
                                    lcd_puts(0,0," Password Reset ");
                                    lcd_puts(0,1,"   Successful   ");
                                    lcd_puts(0,3,"  Press  Enter  ");
                                    update_lcd();
                                    usleep(3000000);
                                    key =0;
                                    reset_password=0;
                                    fstate++;
                                    return;
                                 }
                              }

                              lcd_notify("Invalid Password",1);
                              usleep(2000000);
                              fstate=PASSWORD;
                            }
		          }
                  }
                }

            }
	    else if(fstate==(PASSWORD+2))
	    {
	      if(key==0x0a){fstate=0;return;}
              key=0;
	    }

            else if(fstate==(USBMENU+1))
            {
               cursor_off();
               con=0;
               if(key == '1') // upload rate
               {
                        //temp_buf[0]=0;
                        //printf("USB FILE SCAN = %d\r\n",system("ls /tmp/usb/config/nr*.csv"));

                
                if(access( "/tmp/usb/mmlist.txt", F_OK ) != -1)
                {
                  system("cp /tmp/usb/mmlist.txt /tmp/mmc/"); 
                  system("rm /tmp/mmc/member.dat");
                }

                system("sync");// active member list
                if(access( "/tmp/usb/config/rate1.csv", F_OK ) != -1 || access( "/tmp/usb/config/rate2.csv", F_OK ) != -1 || system("ls /tmp/usb/config/nr*.csv")==0)
          		{
			     puts("Updating Rate...\n");
                             lcd_notify("[Uploading Rate]",1);

			     system("cp /tmp/usb/config/rate*.csv /tmp/mmc/");
                             sleep(1);
                             system("cp /tmp/usb/config/nr*.csv /tmp/mmc/");

                             sleep(1);
                             system("sync");
			     load_rate_chart("/tmp/mmc/rate1.csv",0);
                             load_rate_chart("/tmp/mmc/rate2.csv",1);
			     puts("Done...\n");

                             system("sync");
                             sleep(3);
			   }
                        else
                        {
                             lcd_notify(" [NO RATE FILE] ",1);
                             sleep(5);
                        }
		           load_rate_chart("/tmp/mmc/rate1.csv",0);
		           if(dpu_settings[6][8] == 'Y')
		           load_rate_chart("/tmp/mmc/rate2.csv",1);

               /*system("cp /tmp/mmc/*.csv  /tmp/mmc/recovery/");
               system("cp /tmp/mmc/mmlist.txt /tmp/mmc/recovery/");
               system("sync");*/
               }
               if(key == '2')//  backup
               {
                        lcd_notify("  [Saving....]  ",1);
                       // sprintf(temp_buf,"/tmp/usb/backup_%s",scode);system("mkdir /tmp/usb/backup");
                        system_cmd("mkdir /tmp/usb/backup",scode,"","","");

                        system_cmd("mkdir /tmp/usb/backup",scode,"/evening","","");
                        system_cmd("mkdir /tmp/usb/backup",scode,"/morning","","");

                        //system("mkdir /tmp/usb/backup/evening");
                        //system("mkdir /tmp/usb/backup/morning");
                        puts("Backup\n");

                        system_cmd("cp /tmp/mmc/morning/* ","/tmp/usb/backup",scode,"/morning/","");
                        system_cmd("cp /tmp/mmc/evening/* ","/tmp/usb/backup",scode,"/evening/","");

                        //system("cp /tmp/mmc/morning/*  /tmp/usb/backup/morning/");
                        //system("cp /tmp/mmc/evening/*  /tmp/usb/backup/evening/");

                        system_cmd("cp /tmp/mmc/rate1.csv ","/tmp/usb/backup",scode,"/","");
                        system_cmd("cp /tmp/mmc/rate2.csv ","/tmp/usb/backup",scode,"/","");
                        system_cmd("cp /tmp/mmc/nr*.csv ","/tmp/usb/backup",scode,"/","");
                        system_cmd("cp /tmp/mmc/msg.txt ","/tmp/usb/backup",scode,"/","");
                        system_cmd("cp /tmp/mmc/dpu.cfg ","/tmp/usb/backup",scode,"/","");
                        system_cmd("cp /tmp/mmc/mmlist.txt ","/tmp/usb/backup",scode,"/","");
                        system_cmd("cp /tmp/mmc/dpu_settings.dat ","/tmp/usb/backup",scode,"/","");
                        system_cmd("cp /tmp/mmc/member.dat ","/tmp/usb/backup",scode,"/","");

                        /*
                        system("cp /tmp/mmc/rate1.csv /tmp/usb/backup/");
                        system("cp /tmp/mmc/rate2.csv /tmp/usb/backup/");
                        system("cp /tmp/mmc/nr*.csv /tmp/usb/backup/");
                        system("cp /tmp/mmc/dpu.cfg /tmp/usb/backup/");//factory config
                        system("cp /tmp/mmc/msg.txt /tmp/usb/backup/");   
                        system("cp /tmp/mmc/print.txt /tmp/usb/backup/");
                        system("cp /tmp/mmc/mmlist.txt /tmp/usb/backup/");//acive member list
                        system("cp /tmp/mmc/member.dat /tmp/usb/backup/");
                        system("cp /tmp/mmc/dpu_settings.dat /tmp/usb/backup/");
                        */

                        //extra backup to mmc-card
                        /*
                        system("cp /tmp/mmc/rate1.csv /tmp/mmc/recovery/");
                        system("cp /tmp/mmc/rate2.csv /tmp/mmc/recovery/");
                        system("cp /tmp/mmc/nr*.csv /tmp/mmc/recovery/");
                        system("cp /tmp/mmc/dpu.cfg /tmp/mmc/recovery/");//factory config
                        system("cp /tmp/mmc/msg.txt /tmp/mmc/recovery/");   
                        system("cp /tmp/mmc/print.txt /tmp/mmc/recovery/");
                        system("cp /tmp/mmc/mmlist.txt /tmp/mmc/recovery/");//acive member list
                        system("cp /tmp/mmc/member.dat /tmp/mmc/recovery/");
                        system("cp /tmp/mmc/dpu_settings.dat /tmp/mmc/recovery/");
                        */
                        system("sync");
                        lcd_notify(" [Backup  Done] ",1);
                        sleep(5);
               }
               if(key == '3')//  restore
               {

		        clear_lcd();
		        lcd_puts(0,0, "   [RESTORE  ?]   ");
		        lcd_puts(0,2, "   YES   [ENTER]  ");
		        lcd_puts(0,3, "   NO     [ESC]   ");
		        update_lcd();con=1;
			    key_mode=0; cursor_off();cx=15; cy=3;
			    fstate++;
                        return;
               }
               if(key == '4')  // save session: date entry
               {
                  //clear_lcd();
                  //lcd_puts(0,0, "   [ DATE  ?]   ");
                  //lcd_puts(0,1, "FROM:    TO:    ");
                  //cx=4; cy=1;
                  //update_lcd();con=0; 
                  //cursor_off();       
                  //key_mode=0;
                  flag_scan=0;edit_rtc=0;edit_record=0;
                  fstate=SAVE_SESSION;  
                  key =1;  
                  return;     
               }

	       fstate=0;
	       usb_inserted=0;
	       key = 0;
            }
            else if(fstate==(USBMENU+2))
            {
               if(key==0x0a) {fstate=PASSWORD;usb_inserted=5;key=1;return;}
               else if(key =='q'){usb_inserted=0; fstate=0;return;}
               key =0;
            }
            else if(fstate==(MEMBER+1))
            {
               if(key == 'q') {fstate=0;home_counter=0;return;}

               cursor_off();
               con=0;
               if(key == '1') // jump to meber master EDIT
               {
                    fstate = MASTER;
               }
				   else if(key == '2')  // print Member Master
				   {
					   
					   
					   puts("Print Member Master\r\n");
					   fd_mm = fopen("/tmp/mmc/member.dat","rb");  //member data base
										       //usleep(600000);
					   i =0;

					    sleep(2);tcflush(uart1_fd,TCIOFLUSH); PT_ON;usleep(500000);
						close(uart1_fd);
                        uart1_fd = open ("/dev/ttyS0", O_RDWR | O_NOCTTY | O_SYNC);    
						set_interface_attribs2 (uart1_fd,B9600,0);
						set_blocking(uart1_fd,0);
						usleep(500000);
				        tcflush(uart1_fd,TCIOFLUSH);						
					   //clear buffer.
					   
						
					   //stty_off  if(dpu_settings[5][10] == 'D'){ system("stty -F /dev/ttyS0 19200 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr "); }
					   //stty_off  else                          { system("stty -F /dev/ttyS0 9600 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr "); }
					   //---uart1_fd = open ("/dev/ttyS0", O_RDWR | O_NOCTTY | O_SYNC);     



					   //EN_PRINT;
					   if(dpu_settings[5][10] == 'T')
					   {
						   str_buf[0] = 0x1B;str_buf[1] = 0x21;str_buf[2] = 0x21;
						   write(uart1_fd,str_buf,3);
					   }

					   if(dpu_settings[5][10] == 'D') write(uart1_fd,"        ",8);
					   write(uart1_fd,"    MEMBER MASTER    \r\n",23);

					   t = time(NULL);
					   tm = *localtime(&t);

					   sprintf(str_buf,"     %02d/%02d/%02d   \r\n",tm.tm_mday,tm.tm_mon+1,tm.tm_year-100);
					   if(dpu_settings[5][10] == 'D') write(uart1_fd,"        ",8);
					   write(uart1_fd,str_buf,strlen(str_buf));

					   if(dpu_settings[5][10] == 'D'){
						   write(uart1_fd,"        ",8);
						   write(uart1_fd,"---------------------------------------\r\n",41);
						   write(uart1_fd,"        ",8);
						   write(uart1_fd," NO. |       NAME       |    PHONE    |\r\n",41);
						   write(uart1_fd,"        ",8);
						   write(uart1_fd,"---------------------------------------\r\n",41);
					   }


					   while(i <= 2000)
					   {
						   memset(temp_buf,0,64);
						   fseek(fd_mm,i*32,SEEK_SET);
						   fread(temp_buf,16,1,fd_mm);
						   fread(&temp_buf[20],16,1,fd_mm);

						   fseek(fd_mm,128000+(i*32),SEEK_SET);
						   fread(&temp_buf[50],16,1,fd_mm);
						   fread(&temp_buf[70],16,1,fd_mm);


						   n=0;while(n<49){if( (isalnum(temp_buf[n])==0 || temp_buf[n] == '_') &&  temp_buf[n] != ' ' ) {temp_buf[n]=0;} n++; }  temp_buf[n]=0;

						   n=50;while(n<90){if(temp_buf[n] == '_' || temp_buf[n] == ' ')temp_buf[n]=0;n++;}
						   

						   temp_buf[16]=0;
						   temp_buf[31]=0;


						   if(isalpha(temp_buf[0])  || isdigit(temp_buf[20])) // valid name
						   {
							   printf("MID=%04d: %-16s | %11s\n",i,temp_buf,&temp_buf[20]);
							   if(dpu_settings[5][10] == 'D'){
								   write(uart1_fd,"        ",8);
								   sprintf(str_buf,"%04d | %-16s | %11s |\r\n",i,temp_buf,&temp_buf[20]);
								   write(uart1_fd,str_buf,strlen(str_buf));
								   usleep(800000); 
							   }
							   else
							   {
								   sprintf(str_buf,"%04d %s\r\n",i,temp_buf);
								   write(uart1_fd,str_buf,strlen(str_buf));
								   sprintf(str_buf,"MOB:%s\r\n",&temp_buf[20]);
								   write(uart1_fd,str_buf,strlen(str_buf));
								   usleep(500000); 
							       sprintf(str_buf,"ACCOUNT#:%s\r\n",&temp_buf[50]);
								   write(uart1_fd,str_buf,strlen(str_buf));		
							       sprintf(str_buf,"IFSC    :%s\r\n\r\n",&temp_buf[70]);
								   write(uart1_fd,str_buf,strlen(str_buf));									   						   
								   usleep(800000);
							   }
                               // sync each member string to server
                               memcpy(str_buf,&dpu_settings[2][4],3);str_buf[3]=0;      // project code
                               memcpy(&str_buf[6],&dpu_settings[2][12],4);str_buf[10]=0; // dist code
                               memcpy(&str_buf[11],&dpu_settings[1][5],4);str_buf[15]=0;// collect point code
                               t = time(NULL);
                               tm = *localtime(&t);
                               sprintf(str_temp,"%%%s/K/%02d%02d%02d/%s/%s/%04d/%.*s/NA/NA/01-01-1980/%.*s/%s/%s/%02d%02d20%02d/%02d:%02d/F/I%s$",str_buf,tm.tm_mday,tm.tm_mon + 1,tm.tm_year-100,&str_buf[6],&str_buf[11],i,16,temp_buf,10,&temp_buf[20],&temp_buf[50],&temp_buf[70],tm.tm_mday,tm.tm_mon + 1,tm.tm_year-100,tm.tm_hour,tm.tm_min,IMEI);

                               set_interface_attribs (uart0_fd, B9600, 0);
                               EN_GPRS;
                               sleep(1);
                               if(strcmp("000.000.000.000 ",dpu_settings[4])!=0  && dpu_settings[6][15]=='N')
                               {
                                   ws_write(uart0_fd,str_temp,strlen(str_temp));
                                   puts(str_temp);
                               }


						   }
						   i++;

					   }
					   write(uart1_fd,"\r\n\r\n\r\n\r\n",8);
					   usleep(800000);
					   fclose(fd_mm);
					   key =0;
					   fstate = 0;
					   sleep(3);
				   }
				   else
				   {
					   key = 0;
					   fstate=0;
				   }
				  
				   set_interface_attribs (uart1_fd, B2400, 0);
#ifdef PCB_V1
PT_OFF;
#endif
            }

            else if(fstate==(COLLECTION+1))
            {
               cursor_off();
               con=0;
               if(key == 'q') {fstate=0;home_counter=0;return;}

               if(key == '1') // jump to meber master Milk Collection
               {
                    fstate = GET_ID;
                    #ifdef PROJ_MAHI
               	    t = time(NULL);
		            tm = *localtime(&t);
		            if(tm.tm_hour <= 12)
		            {
		              sprintf(temp_buf,"/tmp/mmc/M%d.mloc",tm.tm_mday);     
		            }
		            else
		            {
		              sprintf(temp_buf,"/tmp/mmc/E%d.eloc",tm.tm_mday);     
		            }

                    if(access( temp_buf, F_OK ) == -1) // session report not printed
                    {
                       fstate = GET_ID;
                    }

                    else
                    {
                       fstate = 0;//main screen
                    }
                    #endif

               }
               
               #ifdef PROJ_KMD
               else if(key == '2')  // Get Deduction Amount
               {

                    con = 0;
                    mblink = 0;edit_pass =0;
                    clear_lcd();
                    lcd_puts(0,0,"  [DEDUCTION]   ");
                    sprintf(temp_buf,"%d",id);
                    lcd_puts(0,1,"Mem. No:___     ");
                    lcd_puts(8,1,temp_buf);
                    lcd_puts(0,2,"Amount :____.__ ");
                    cx = 8;  cy = 1; cmax = 12;
                    key_mode=0;
                    update_lcd();
                    con = 1;
                    fstate++;
                    key = 0;
               }
               else if(key == '3')
               {
                    deduct_report = 1;
                    fstate = LEDGER;
                    key = 1;
               }
             #endif

           }
           else if(fstate==(COLLECTION+2))  //get member id
           {
               cursor_off();
               if(get_text(13,8)) //MID
               {
                  memcpy(temp_buf,&lcd_buffer[1][8],4); temp_buf[4]=0;
                  i=0;while(i<5){if(temp_buf[i]=='_')temp_buf[i]=0; i++;}
                  id = atoi(temp_buf);
                  //get deduction amount for current date and session


		  t = time(NULL);
		  tm = *localtime(&t);
	          if(tm.tm_hour <= 12)sprintf(temp_buf,"/tmp/mmc/morning/%02d_%02d.dat",tm.tm_mon+1,tm.tm_year-100);
                  else              sprintf(temp_buf,"/tmp/mmc/evening/%02d_%02d.dat",tm.tm_mon+1,tm.tm_year-100);
                  printf("PATH:%s\n",temp_buf);
	          fd_mm = fopen(temp_buf,"rb");
                  if(fd_mm)
                  {       memset(str_buf,0,43);
		          offset = (tm.tm_mday-1)*(2000*43) + (id*43);
	  		  fseek(fd_mm,offset,SEEK_SET);
			  fread(str_buf, 43,1,fd_mm); str_buf[43]=0;str_buf[42]=0;
			  puts(str_buf);puts("\r\n");
		          fclose(fd_mm);  //lcd_puts(0,2,"Amount  :___.__ ");
                          if(strlen(str_buf)>30){
                          sprintf(temp_buf,"Amount :%s",&str_buf[35]);
                          lcd_puts(0,2,temp_buf);
                          key =0;
                          }

                  }

                  sprintf(temp_buf,"%04d   ",id);
		  lcd_puts(8,1,temp_buf);

                  puts(temp_buf);
                  cx = 8;  cy = 2; cmax = 14;
                  fstate++;
		  update_lcd();
		  con = 1;
               }
               else
               key =0;

           }
           else if(fstate==(COLLECTION+3))  //get deduction amount
           {
               cursor_off();
               if(get_text(15,8)) //amount
               {

			memcpy(temp_buf,&lcd_buffer[2][8],7); temp_buf[7]=0;
			bonus = atof(temp_buf); //deduction amount
			puts(temp_buf);

			t = time(NULL);
			tm = *localtime(&t);
			sprintf(actual_time,"%02d:%02d",tm.tm_hour,tm.tm_min);
			printf("now: %d-%d-%d %d:%d:%d\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);

			if(tm.tm_hour <= 12) // Before 12 Oclock
			{
			sprintf(str_buf,"//tmp/mmc//morning//%02d_%02d.dat",tm.tm_mon+1,tm.tm_year-100);
			}
			else
			{
			sprintf(str_buf,"//tmp/mmc//evening//%02d_%02d.dat",tm.tm_mon+1,tm.tm_year-100);
			}
			fd = open(str_buf,O_WRONLY | O_CREAT, 0666);//open current session file
                        offset = (tm.tm_mday-1)*(2000*43) + (id*43);
			printf("file_offset=%ld\n",offset);
			lseek(fd,offset+35,SEEK_SET);//move file pointer to 'Deduction' field
                        //11:21:11,005.60,09.4,08.4,00143.08,  0.00
                        write(fd,temp_buf,7);
                        close(fd);
			fstate=COLLECTION+1;key='2';//fstate=0;
                        id++;
			update_lcd();
			con = 1;
               }

           }

           else if(fstate==(SAVE_SESSION+1)) // single or multiple
           {
              if(key == 'q') {fstate=0;home_counter=0;usb_inserted=0;key='q';return;}
              if(key=='1')//single
              {
                con=0;
                usb_session=0;
                cursor_off();
                cx=7;cy=1;
                clear_lcd();
		        t = time(NULL);
		        tm = *localtime(&t); //tm.tm_mday,tm.tm_mon + 1,tm.tm_year + 1900,tm.tm_hour, tm.tm_min
		        if(tm.tm_hour > 12)usb_session=1;
		        sprintf(temp_buf," DATE: %02d/%02d/%02d ",tm.tm_mday,tm.tm_mon + 1,tm.tm_year-100);
		        lcd_puts(0,1, temp_buf);
		        if(usb_session==0)  lcd_puts(0,3, "    Morning     ");
		        else                lcd_puts(0,3, "    Evening     ");
		        con=1;
		        update_lcd();
		        key=0;
		        fstate++;
		        return;
              }
              if(key=='2')//multiple
              {
                con=0;cursor_off();

                clear_lcd();
                cx=7;cy=1;
		        lcd_puts(0,1, "SDATE: __/__/__ ");
		        lcd_puts(0,2, "EDATE: __/__/__ ");
		        update_lcd();
		        key=0;
		        con=1;
                fstate =SAVE_SESSION+4;
              }


           }

           else if(fstate==(SAVE_SESSION+2)) //default session or user selected
           {
              cursor_off();
              if(key >='0' && key <= '9') lcd_puts(0,3,"                ");
              if(get_text(15,7))
              {

                 memcpy(str_buf,&lcd_buffer[1][7],8); str_buf[2]=str_buf[5]=str_buf[8]=0;

                 if(cx==7) //print current session
                 {

                   fstate++;
                   key = '1';
                   if(usb_session) key= '2';
                   return;
                 }
                 else
                 {
                   clear_lcd();
                   con=0;
                   cursor_off();
                   cx =15;cy=3;
                   lcd_puts(0,1," Morning    [1] ");
                   lcd_puts(0,2," Evening    [2] ");
                   update_lcd();
                   con=1;
                   key=0;
                   fstate++;
                   return;
                 }
                 
              }

           }
           else if(fstate==(SAVE_SESSION+3))
           {
               if(key == 'q') {fstate=0;home_counter=0;usb_inserted=0;key='q';return;}
              if(key=='1' || key=='2')
              {

                 d = atoi(str_buf);
                 m = atoi(&str_buf[3]);
                 y = atoi(&str_buf[6]);

				 sprintf(str_buf,"%02d/%02d/%02d",d,m,y);
				 puts(str_buf);puts("\r\n");
				 print_en=0;
				 if(key=='1'){
				 puts("Morning\r\n");
				 print_session_report(2,1,0); // BUF/MIX
				 if(dpu_settings[6][8] == 'Y'|| dpu_settings[6][8] == 'S')print_session_report(2,1,1); //COW
				 }
				 if(key=='2'){
				 puts("Evening\r\n");
				 print_session_report(2,2,0); // BUF/MIX
				 if(dpu_settings[6][8] == 'Y' || dpu_settings[6][8] == 'S')print_session_report(2,2,1); //COW
				 }
                 print_en=1;

                 lcd_notify("[SESSION  SAVED]",1); system("sync");sleep(3);
                        
                 usb_inserted=0;
                 fstate=0;key='q';return;
                 return;
              }

           }

           else if(fstate==(SAVE_SESSION+4))  //from day
           {
              cursor_off();
              if(get_text(15,7))
              {
                 update_lcd();
                 cx=7,cy=2;
                 con=1;
                 fstate++;
                 key=0;
               }

           }
           else if(fstate==(SAVE_SESSION+5))  //To day
           {
              
              cursor_off();
              if(get_text(15,7))
              {
                 update_lcd();
                 cx=7,cy=2;
                 con=1;


                 memcpy(str_buf,&lcd_buffer[1][7],8); str_buf[2]=str_buf[5]=str_buf[8]=0;
                 d = atoi(str_buf);
                 m = atoi(&str_buf[3]);
                 y = atoi(&str_buf[6]);
                 memcpy(str_buf,&lcd_buffer[2][7],8); str_buf[2]=str_buf[5]=str_buf[8]=0;
                 n = atoi(str_buf);
                 print_en=0;

                 // call session report print function for with print disable
                 for(i=d;i<=n;i++)// scan each day
                 {
                     sprintf(str_buf,"%02d/%02d/%02d",i,m,y);
                     puts(str_buf);puts("\r\n");

                     //morning
                     print_session_report(2,1,0); // BUF/MIX
				     if(dpu_settings[6][8] == 'Y' || dpu_settings[6][8] == 'S')print_session_report(2,1,1); //COW

				     //evening
                     print_session_report(2,2,0); // BUF/MIX
				     if(dpu_settings[6][8] == 'Y' || dpu_settings[6][8] == 'S')print_session_report(2,2,1); //COW

                 }
                  print_en=1;
                  key=0;

                  lcd_notify("[SESSION  SAVED]",1); system("sync");sleep(3);
                  usb_inserted=0;
                  fstate=0;key='q';return;
              }
             
           }
          

            else if(fstate == 0 && usb_inserted==0)  // ESC go to main menu
            {
                //--if(thread_analyzer && flag_scan)pthread_cancel(thread_analyzer);
             	con =0;
                usb_inserted=0;
                edit_mode=0;
                edit_pass=0;
                edit_rtc=0;
                entry_delete=0;
                session=0;
                special_report =0;
                deduct_report=0;
                flag_scan=0;
                reset_password=0;
                t = time(NULL);
	            tm = *localtime(&t);
	            if(key== 'q') {puts("Eject USB\r\n");system("umount /tmp/usb &");}//unmount usb
                EN_FAT;
                sprintf(temp_buf,"\nC%02d%02d%02d0000000000",tm.tm_hour,tm.tm_min,tm.tm_sec);
                write(uart2_fd,".channel3>$X",12);
                write(uart2_fd,".channel3>$X",12);
                usleep(150000);
             	clear_lcd();
            	cursor_off();
             	//update_lcd();

             	if(enable_wifi)lcd_puts(0,0,  "   AKASHGANGA(*)");
                else           lcd_puts(0,0,  "   AKASHGANGA   "); 
                sprintf(temp_buf,"%02d:%02d:%02d %02d:%02d:%02d",tm.tm_mday,tm.tm_mon+1,tm.tm_year-100,tm.tm_hour,tm.tm_min,tm.tm_sec);
                temp_buf[8]=0;
                lcd_puts(4,2,temp_buf);
                lcd_puts(4,3,&temp_buf[9]);
                update_lcd();

                //set_interface_attribs (uart1_fd, B2400, 0);
                usleep(50000);
                

               // tcflush(uart1_fd,TCIOFLUSH);
                memset(frame1,0,512);
                //EN_PRINT;
                flag_scan=0;
                key = 0;
            }



            else
            {
               key = 0;
            }
            break;
   }
}


void * blink_text(void * arg)
{
    unsigned char toggle=0;
    unsigned char usb_ok=0;
    int scan_speed=4;
    
    int i,n;
    char auto_lit,auto_fat;
    char buf[50];
    char serial_buf[50];
    float rate;
    
    system("mkdir /tmp/usb");
    while(1)
    {
        if(check_update){usleep(500000);continue;}
        if(flag_scan==0) free_ram++;
        if(free_ram >120)
        {
           free_ram=0;
           puts("free memory...");
           //if(enable_wifi==0)system("sync");
           //---system("sysctl -w vm.drop_caches=3 &");
           puts("[done]\r\n");
           system_call("nmcli | grep 'connected to dpu'",buf);
           if(strstr(buf,"connected to dpu")==0)
           {
             puts("reconnect wifi AP dpu...");
             system("nmcli device wifi connect dpu password 9427610356");
           }
        }
        if(con>0 && kwait_feed==0)
        {
          cursor_blink();
          update_lcd();
        }
        #ifdef AUTO_RESET
        auto_reboot++;
        if(auto_reboot>240)//reset after 2 min
        {
          system("sync");
          system("reboot");
        }
        #endif
        if(mblink)
        {
          if(toggle)
          lcd_puts(0,mblink-1,message);
          else
          lcd_puts(0,mblink-1,"                ");
          toggle =~toggle;
          update_lcd();
        }
        /*
        if(access( "/dev/sda", F_OK ) != -1 && usb_ok ==0)
        {
          usb_ok = 1;
          system("mount /dev/sda1 /tmp/usb");
          //con=0;lcd_notify("[Inserted Drive]",1);
          //sleep(1);
          //update_lcd();
	  //usb_inserted =1;
	  //key = 5;
	  //fstate=PASSWORD;
        }
        else*/
        if(access( "/dev/sda", F_OK ) == -1)
        {
          usb_ok = 0;
          usb_inserted=0;
        }
        if(access("/dev/input/event0",F_OK)==-1 && keyboard_ok)
        {
            keyboard_ok=0;
            puts("Keyboard Unpluged!");
        }
        else if(keyboard_ok == 0 && access("/dev/input/event0",F_OK) != -1)
        {
            keyboard_ok=1;
            close(kb_fd);
            kb_fd = open(pDevice, O_RDONLY | O_NONBLOCK);
            puts("Keyboard Pluged!");
            
        }           
        
        if(fstate==0 && usb_inserted==0 )
        {
          if(home_counter>0)home_counter--;
          if(home_counter==0)
          {
            key = 1;
            home_counter = 2;
          }
        }
//03140263000000280043000600504C)(050007803140263000000280043000600504C)(
//#ifdef EN_SCAN
        if(flag_scan)
        {
               
               switch(device)
               {
                   case 0:
                        //usleep(10000);tcflush(uart1_fd,TCIOFLUSH);
                        //omc_fat=9.4;omc_snf=8.4;
                        usleep(100000);//wifi to serial
                        //read(uart1_fd,frame2,400);
                        puts("read analyzer");
                        puts(frame2);
                        for(i=0;i<400;i++){frame2[i] = frame2[i]&0x7F; if(frame2[i]==0x0A) frame2[i]=0;}
                        if(fat_only==0)
                        {
                                
                        //i=0;while(i<200){ if(frame2[i]==')' /*&& isdigit(frame1[i-37]) && isdigit(frame1[i+2]) && isdigit(frame1[i+8] )*/ && i>=38) {break;} i++; }
                          
                        //non-wifi   i=0;while(i<400){ if(frame2[i]=='('  && frame2[i+38]==')') {frame2[i+38]=0;break;} i++; }
                        i=0;while(i<400){ if(frame2[i]=='('  && frame2[i+9]==')') {frame2[i+10]=0;break;} i++; }
                            
                        
                        //if(strlen(&frame2[i])>=37 &&  i<400) non-wifi
                        if(strlen(&frame2[i])>=8 &&  i<400 &&   frame2[i]=='(' &&   frame2[i+9]==')')
		                //if(i>=31 &&  i<200)
		                {  auto_fat=3;
                           frame2[i+38]=0;//i=i-38;
		                   frame2[i+9]=0; frame2[i+4]=0; frame2[i+8]=0; printf("FAT   :%s\n",&frame2[i+1]); omc_fat = atof(&frame2[i+1])/10; omc_snf = atof(&frame2[i+5])/10;
		                   if(omc_fat != xomc_fat || omc_snf != xomc_snf || ws_type==0)
		                   {
		                     sprintf(buf,"%04.1f",omc_fat); lcd_puts(10,2,buf);if(cy==2)  key=0x0A; strcpy(&buf[30],buf);
		                     sprintf(buf,"%04.1f",omc_snf); lcd_puts(10,3,buf);if(cy==3)cx = 15;
                             
		                   }
		                   else//make fat and snf 0
		                   {
		                     omc_fat=0;omc_snf = 0;
		                     key=0x0A;
		                     sprintf(buf,"%04.1f",0); lcd_puts(10,2,buf);if(cy==2)key=0x0A; strcpy(&buf[30],buf);
		                     sprintf(buf,"%04.1f",0); lcd_puts(10,3,buf);if(cy==3){key=0x0A;cx = 15;}
		                     

		                   }

		                }
						}//(051008601
                        else
                        {  
                             //puts(frame1);
                             i=0;while(i<200){ if(frame2[i]=='+' && isdigit(frame2[i+1]) && isdigit(frame2[i+2]) && isdigit(frame2[i+3] ) && frame2[i+7]=='F' && frame2[i+8]=='S') {frame2[i+7]=0;break;} i++; }
                             if(i<200){ 
                               
                               puts(frame2);
                               omc_fat = atof(&frame2[i+1]);
                               if(omc_fat >0){
                               auto_fat=3;
                               omc_snf=0;
		                       sprintf(buf,"%04.1f",omc_fat); lcd_puts(10,2,buf); //if(cy==2)key=0x0A; strcpy(&buf[30],buf);
		                       //sprintf(buf,"%04.1f",omc_snf); lcd_puts(10,3,buf)
                               if(cy==3)cx = 15;
                               } 
                               else if(cy==1)
                               {
                                  lcd_puts(10,2,"__._");//
                               }

                             }
                              
                        }//+123.45FS \r\n
                         
                        memset(frame1,0,200);
                        if(auto_lit==0)strcpy(&buf[40],"    ");
                        if(auto_fat==0){strcpy(&buf[30],"    ");strcpy(&buf[0],"    ");if(cy==3 && cx==15){memset(frame3,0,400);lcd_puts(10,3,"__._");lcd_puts(10,2,"__._");cx=10;cy=2;}}
                        if(edit_mode==0 && flag_scan  ){
                        //--sprintf(serial_buf,"\nD%c%c%c%c%c%c%c...%c%c%c%c%c%c",lcd_buffer[0][10],lcd_buffer[0][11],lcd_buffer[0][12],lcd_buffer[0][13],buf[41],buf[42],buf[44],buf[30],buf[31],buf[33],buf[0],buf[1],buf[3]);
                         //<4 member><1c/b><4Liter><3Fat><3Snf><3water><6rate><6amount>
                          //sprintf(serial_buf,"\nD%c%c%c%c%c%c%c...%c%c%c%c%c%c",lcd_buffer[0][10],lcd_buffer[0][11],lcd_buffer[0][12],lcd_buffer[0][13],buf[41],buf[42],buf[44],buf[30],buf[31],buf[33],buf[0],buf[1],buf[3]);
                          if(mid < 1000)
                          {
                                sprintf(serial_buf,".channel3>$%%%%%c%c%c%cB%c%c%c%c%c%c%c %c%c%c                ",lcd_buffer[0][10],lcd_buffer[0][11],lcd_buffer[0][12],lcd_buffer[0][13],buf[40],buf[41],buf[42],buf[44],buf[30],buf[31],buf[33],buf[0],buf[1],buf[3]);
                          }
                          else
                          {
                                sprintf(serial_buf,".channel3>$%%%%%c%c%c%cC%c%c%c%c%c%c%c %c%c%c                ",lcd_buffer[0][10],lcd_buffer[0][11],lcd_buffer[0][12],lcd_buffer[0][13],buf[40],buf[41],buf[42],buf[44],buf[30],buf[31],buf[33],buf[0],buf[1],buf[3]);                         
                          }
                          
                          puts(serial_buf);
                          strcpy(last_rdisplay,serial_buf);
                          write(uart2_fd,serial_buf,strlen(serial_buf));
                          write(uart2_fd,serial_buf,strlen(serial_buf));
                          
                          usleep(90000);
                        }
                        
                        //EN_WSCALE;
                        if(auto_lit>0)auto_lit--;
                        //set_interface_attribs(uart1_fd,B19200,0);
                        usleep(10000);
                        //-------tcflush(uart2_fd,TCIOFLUSH);
                        usleep(10000);
                        rx3_bytes=0;
                        
                        //usleep(80000);
                        //tcflush(uart1_fd,TCIOFLUSH);
                        //usleep(80000);
                        device++;
                   break;
                   case 1:
                        //EN_FAT;rx1_bytes=0;auto_fat=0;
                        //usleep(10000);
                        //--tcflush(uart1_fd,TCIOFLUSH);
                        //read(uart2_fd,frame3,300);
                        puts("read weight");
                        puts(frame3);
                        switch(ws_type)
                        {
                           
                          case 0:
                            
                            for(i=0;i<200;i++){frame3[i] = frame3[i]&0x7F; if(frame3[i]=='L' || frame3[i]=='K') {frame3[i]=0; /*remove rounding*/ if(lit_mode==0 && i > 3)frame3[i-3]='0'; /**/ }}
                            i=0;while(i<200){ if((frame3[i]==' '|| frame3[i]== '-') && strlen(&frame3[i])==11) {break;} i++; }
                            //puts(&frame3[i]);
                            if(i<200)
                            {
                               for(n=0;n<strlen(&frame3[i]);n++){if(frame3[n+i] != ' ' && frame3[n+i] != '-'  && !isdigit(frame3[n+i]) && frame3[n+i] != '.'){i=200;break;} }
                            }
                            if(i<200) {auto_lit=3;frame3[i+10]=0;  if(atof(&frame3[i])>=0)omc_lit = atof(&frame3[i]);printf("WSCALE:%04.1f\n",omc_lit);if(lit_mode==0)sprintf(buf,"%05.1f",omc_lit); else sprintf(buf,"%06.2f",omc_lit);  strcpy(&buf[40],buf); lcd_puts(9,1,buf);if(cy==1)key=0x0A;} //    00.500 Lt    >___125.750_KG_CRLF
                          break;

                          case 1:
                            
                            for(i=0;i<200;i++){frame3[i] = frame3[i]&0x7F; if(frame3[i]==0x0d) frame3[i]=0;}

                            i=0;while(i<200){ if(frame3[i]=='$' && strlen(&frame3[i])==8) {break;} i++; }
                            if(i<200) {auto_lit=3;frame3[i+7]=0; if(atof(&frame3[i+2])>=0)omc_lit = atof(&frame3[i+2]);printf("WSCALE:%04.1f\n",omc_lit);  if(lit_mode==0)sprintf(buf,"%05.1f",omc_lit);else sprintf(buf,"%06.2f",omc_lit);    strcpy(&buf[40],buf); lcd_puts(9,1,buf);if(cy==1)key=0x0A;} //$L000.00CR
                          break;
                        }
                        if(dis_rate==2){
                          if(ws_mode==0) sprintf(buf,"LITER : %6.2f     ",omc_lit);
                          else           sprintf(buf,"KG    : %6.2f     ",omc_lit);
                          lcd_notify2(buf,1);
                          }
                          memset(frame3,0,200);
                        memset(frame2,0,200);
                        //usleep(100000);
                         //----wifi-analyzer (uart1_fd,TCIFLUSH);
                        //EN_FAT;
                        if(auto_fat>0)auto_fat--;
                        //(((
                        //usleep(130000);
                        //--set_interface_attribs2(uart1_fd,B2400,0);
                        
                        //set_blocking(uart1_fd,1);
                        //usleep(230000);
                        rx2_bytes=0;

                        device=0;
                   break;
               }

              if(dis_rate!=2){update_lcd();}
              //puts(".");
             //-- analyzer_stop = 0;
        }
        else 
        {
            //set_interface_attribs2 (uart1_fd,B19200,0);
            analyzer_stop = 1;
        }
//#endif
        usleep(500000);
        //if(flag_scan==0)
        //--if(device==0) usleep(400000);
    }
}
void print_options()
{
   int xkey;
   clear_lcd();
   lcd_puts(0,1,"Print & Sync [1]");
   lcd_puts(0,2,"Sync Only    [2]");
   update_lcd();
   xkey = key;
   while(1)
   {
     //key_mode=0;   
     key=0;
    kbhit_wait();
    display_en =0;
    if(key == '1') {print_opt=1;break;}//  print and sync
    if(key == '2') {print_opt=2;break;}//  only sync
    
   }
   key = xkey;
}
int read_keyboard()
{
     int  bytes;
      struct input_event data;

      //const char *pDevice = "/dev/input/event0";

      // Open Keyboard
      //kb_fd = open(pDevice, O_RDONLY | O_NONBLOCK);
      /*if(kb_fd == -1)
      {
          printf("ERROR Opening %s\n", pDevice);
          return -1;
      }*/

      while(1)
      {
          // Read Keyboard Data
          bytes = read(kb_fd, &data, sizeof(data));
          if(bytes > 0 && data.type ==1 && data.value ==1)
          {
              printf("Keypress value=%x, type=%x, code=%x\n", data.value, data.type, data.code);
              //close(kb_fd);
              return (data.code);
          }
          else
          {
              // Nothing read
              usleep(80000);//500ms
          } 
      }    
}


unsigned char modem_status()
{
        unsigned char line[32];
        char *pos;
        unsigned char value = 0;
        set_interface_attribs (uart0_fd, B9600, 0);
       
        EN_GPRS;
        sleep(1);
       
        line[0]=0x03;line[1]=0x06;line[2]=0x09;
        write(uart0_fd,line,3); sleep(2);  //activate AT only mode
        write(uart0_fd,"AT\r\n",4); sleep(1);//RSSI
        write(uart0_fd,"AT\r\n",4); sleep(1);//RSSI
        rx1_bytes=0;
        write(uart0_fd,"AT+CSQ\r\n",8); //RSSI
        sleep(1);
        pos = strstr(frame1,"+CSQ:");
        if(pos)
        {
        value = atoi(&pos[6]);
        if(value ==0) value  = atoi(&pos[5]);
        
        write(uart0_fd,"AT+CIPSTATUS\r\n",14); //SERVER CONNECTION
        sleep(1);
        puts(frame1);
        if(strstr(frame1,"CONNECT OK")) value |=0x80;
        
        memset(frame1,0,100);
        write(uart0_fd,"AT+CCHOPEN?\r\n",13); //SERVER CONNECTION
        sleep(1);
        puts(frame1);
        if(strstr(frame1,"+CCHOPEN: 0,\"\",")==0 && strstr(frame1,"ERROR")==0)   value |=0x80;        
        
        }
        
        
        
        line[0]=0x05;line[1]=0x06;line[2]=0x07;
        write(uart0_fd,line,3); sleep(3);   
        printf("MODEM STATUS = %02X\r\n",value);
        return value;
    
}
void * wifi_client(void *arg)
{
        int offset;
        int nbyte;
        int nblock=0;
        int received_block=0;
        char sbuf[50];
        time_t t1;
        struct tm tm1;
   
   
        int  numbytes,result,error,len,readval,read_size,i;  
        //unsigned int optval,nreg,addr,val;
        //char buf[8];
        //unsigned long coil_status,mask32;
        //unsigned char client_message[FSIZE];
        //unsigned char send_buffer[20];

        struct hostent *he;
        struct sockaddr_in their_addr; /* connector's address information */
        struct timeval tv;
        while(1)
        {
            
       // struct linger1 struct_linger;
        if ((he=gethostbyname("dpu.agdisk.com")) == NULL) 
        //if ((he=gethostbyname("103.116.86.158")) == NULL) 
        {  /* get the host info */
            herror("gethostbyname1:modbus cllient");
            sleep(3);
            continue;
        }
       

        if ((sockfd_wifi = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
            perror("socket1:modbus cllient");
            sleep(3);
            continue;
        }

        their_addr.sin_family = AF_INET;      /* host byte order */
        their_addr.sin_port = htons(80);    /* short, network byte order */
        their_addr.sin_addr = *((struct in_addr *)he->h_addr);
        bzero(&(their_addr.sin_zero), 8);     /* zero the rest of the struct */
        
    if (connect(sockfd_wifi, (struct sockaddr *)&their_addr,sizeof(struct sockaddr)) == -1) {
        perror("modbus cllient1:connect error");
        sockfd_wifi=0;
        sleep(3);
        continue;
    }
        
    tv.tv_sec = CLIENT_TIMEOUT;//close if no activity for 10 min
    tv.tv_usec = 0;  // Not init'ing this can cause strange errors
    setsockopt(sockfd_wifi, SOL_SOCKET, SO_RCVTIMEO, (char *)&tv,sizeof(struct timeval));    
    //sleep(1);
    write(sockfd_wifi, wsrequest, strlen(wsrequest));
    sleep(1);
    
    GREEN; printf("Client Connected:%d\r\n",sockfd_wifi); CLEAR;
    while( (read_size = recv(sockfd_wifi , frame1 , FSIZE , 0)) > 0 )
    {
            
            //sleep(5);
            
            len = sizeof(error);
            result=getsockopt (sockfd_wifi, SOL_SOCKET, SO_ERROR, &error, &len);
            
            GREEN; printf("Recevied:%d\r\n",read_size); CLEAR;
            client_abort=0;

            if(read_size>0) // receive modbus command
            {
              client_abort=0; 
              rx1_bytes = read_size;
                //while(hd_busy);hd_busy=1;
                //puts(frame1);
                enable_wifi=3;
              if(flag_scan ==0 )
                {
                if(frame1[1] == 126)offset = 4;
                else   offset =2;
                memcpy(xframe1,&frame1[offset],rx1_bytes-offset);
                memcpy(frame1,xframe1,rx1_bytes-offset);
                rx1_bytes -=offset; 
                frame1[rx1_bytes] =0;
                puts(frame1);
                }
            
                if(frame1[0] == '#' && frame1[1] == '#' && frame1[2] == '#' ) //###wpage=0,rpage=2048$$
                {
                    //--puts(frame1);
                }
            
                if(frame1[0] == '$' && frame1[1] == '$' && frame1[2] == '$' ) // file upload
                {
                   puts("receiving file....");//$$$CMD,0,1,ASLKDFJ
                   if(nblock >= 0)
                   {
                       sprintf(sbuf,"Received:%d-%d",received_block,nblock); lcd_puts(0,3,sbuf);  update_lcd();
                   
                       client_abort=0; 
                  }
                   gprs_lock=0;//clear server-command feed
                   switch(frame1[9])
                   {
                       case '9': // no. of file block 
                         nblock = atoi(&frame1[11]);
                         download_started=1;
                         received_block=0;
                         lcd_puts(0,0,"[Receiving File]");  update_lcd();
                         lcd_puts(0,2,"                ");  update_lcd();
                         //sprintf(xframe1,"I%s\r\n",IMEI);puts(xframe1);
                         //ws_write(sockfd_wifi,xframe1,strlen(xframe1));//ACK       
                         sprintf(xframe1,"#FACK I%s %s  G$$$CMD,GET_RATE%%%d\r\n",IMEI,IMEI,received_block);
                         strcpy(xack,xframe1);
                         ws_write(sockfd_wifi,xframe1,strlen(xframe1));
                         usleep(50000);
                         tcflush(uart0_fd,TCIOFLUSH);
                       break;
                       case '1': //first block
                           
                       case '5': // first & last blcok
                         if(frame1[9] == '1')received_block=0;
                         received_block++; 
                         //if(frame1[7]=='1'){system("rm /tmp/r1.zip");wfd = fopen("/tmp/r1.zip","wb");}
                         //else             
                         system("rm /tmp/r2.zip");wfd = fopen("/tmp/r2.zip","wb");
                         
                         //printf("DATA@0x153= %X\r\n",frame1[0x153]);
                         fwrite(&frame1[11],1,rx1_bytes-11,wfd);
                         printf("FIRST BLOCK %d\r\n",rx1_bytes-11);
                         
                         if(frame1[9] == '1'){sprintf(xframe1,"#FACK I%s %s  G$$$CMD,GET_RATE%%%d\r\n",IMEI,IMEI,received_block);puts(xframe1);}
                         else if(frame1[9]=='5'){sprintf(xframe1,"#FACK I%s %s G$$$CMD,GET_RATE\r\nDONE",IMEI,IMEI);puts(xframe1);nblock=0;}
                         usleep(100000);
                         strcpy(xack,xframe1);
                         ws_write(sockfd_wifi,xframe1,strlen(xframe1));//ACK
                         usleep(400000);
                         if(frame1[9]=='5')
                         {
                                        lcd_puts(0,1,"  [File Saved]  ");  update_lcd();
                                        nblock=0;
                                        fclose(wfd);
                                        printf("LAST BLOCK %d\r\n",rx1_bytes-11); 
                                        system_call2("unzip -t /tmp/r2.zip",output);
                                        if(strstr(output,"No errors detected in compressed data of /tmp/r2.zip")>0)
                                        {
                                            system("sync");
                                            system_call2("unzip -o /tmp/r2.zip -d /tmp/mmc",output);system("sync");  
                                            //system_call2("cp /tmp/dpu/test  /tmp/mmc/test",output);
                                            system("sync");
                                            //system_call2("rm /tmp/dpu/test",output);
                                            //system("sync");
                                            //get_server_cfg(1);//update server.cfg
                                            load_settings();
                                            //--load_rate_chart("/tmp/mmc/rate1.csv",0);   
                                            gprs_lock=100;
                                            flag_filedone=123;
                                            clear_lcd();lcd_puts(0,1,"DPU Rebooting...");update_lcd();
                                        }
                                       else
                                        {
                                            clear_lcd();lcd_puts(0,1,"DPU Rebooting...");lcd_puts(0,2,"Update Fail  ...");update_lcd(); 
                                        }
                                        system("reboot");
                                        //No errors detected in compressed data of /tmp/r2.zip.
                         }
                       break;
                       case '2': //n...data block
                       t1 = time(NULL);
		               tm1 = *localtime(&t1);
                       
                           received_block++;
                           if(wfd) fwrite(&frame1[11],1,rx1_bytes-11,wfd);
                           
                         printf("N BLOCK %d\r\n",rx1_bytes-11);
                         sprintf(xframe1,"#FACK I%s %s  G$$$CMD,GET_RATE%%%d\r\n",IMEI,IMEI,received_block);
                         tcflush(uart0_fd,TCIOFLUSH);
                         strcpy(xack,xframe1);
                         //usleep(100000);
                         ws_write(sockfd_wifi,xframe1,strlen(xframe1));  
                         printf("%02d:%02d:%02d\r\n",tm1.tm_hour, tm1.tm_min,tm1.tm_sec);
                         puts(xframe1);                       
                         //ws_write(sockfd_wifi,IMEI,strlen(IMEI));//ACK
                       break;
                       case '0': //last data block
                         received_block++;  
                         nblock=0;
                         lcd_puts(0,1,"  [File Saved]  "); update_lcd();  
                         if(wfd)fwrite(&frame1[11],1,rx1_bytes-11,wfd);
                         if(wfd)fclose(wfd);
                         printf("LAST BLOCK %d\r\n",rx1_bytes-11); 
                         /*
                         if(frame1[7] == '1') { system("sync");system_call2("unzip -o /tmp/r1.zip -d /tmp/dpu",output);system("sync");                        
                          
                          }
                         else if(frame1[7] == '2')
                         {
                             system("sync"); system_call2("unzip -o /tmp/r2.zip -d /tmp/dpu",output);system("sync");

                         }*/
                         //system("sync"); 
                         system_call2("unzip -t /tmp/r2.zip",output);
                         if(strstr(output,"No errors detected in compressed data of /tmp/r2.zip")>0)
                         {
                            system_call2("unzip -o /tmp/r2.zip -d /tmp/mmc",output);system("sync");
                            //system_call2("cp /tmp/dpu/test  /tmp/mmc/test",output);system("sync");
                            //write(uart0_fd,output,100);                            
                            //if(strlen(frame1)>0) write(uart0_fd,"Invalid File\r\n",14); 
                                
                            //write(uart0_fd,dpu_settings[2],strlen(dpu_settings[2]));//ACK
                            sprintf(xframe1,"#FACK I%s %s G$$$CMD,GET_RATE\r\nDONE",IMEI,IMEI);puts(xframe1);
                            //write(uart0_fd,IMEI,strlen(IMEI));
                            //write(uart0_fd,"\r\nDONE",6);
                            ws_write(sockfd_wifi,xframe1,strlen(xframe1));
                            usleep(400000);
                            system("sync");
                           // system_call2("cp /tmp/dpu/test  /tmp/mmc/test",output);
                            ///system("sync");
                            //system_call2("rm /tmp/dpu/test",output);
                            //system("sync");
                            
                            //get_server_cfg(1);//update server.cfg
                            load_settings();
                            //--load_rate_chart("/tmp/mmc/rate1.csv",0);
                            flag_filedone=123;
                            clear_lcd();lcd_puts(0,1,"DPU Rebooting...");update_lcd();
                            //if(dpu_settings[6][8] == 'Y')
                            // load_rate_chart("/tmp/dpu/rate2.csv",1);
                         }
                         else
                         {
                              clear_lcd();lcd_puts(0,1,"DPU Rebooting...");lcd_puts(0,2,"Update Fail  ...");update_lcd(); 
                         }
                         gprs_lock=100;
                         system("reboot");
                       break;
                   }
                   update_lcd();
                   
                   memset(frame1,0,611);
                }
                
               // hd_busy=0;
                CLEAR;
            }
            
            if(result !=0 || error !=0  || sockfd_wifi<=0)
            {
                 if(enable_wifi>1) enable_wifi--;//enable_wifi=0;
                printf("result=%d,error=%d,sockfd_wifi=%d\r\n",result,error,sockfd_wifi);
                puts("modbus-client:re-connected!\r\n");
                //connect(sockfd_wifi, (struct sockaddr *)&their_addr,sizeof(struct sockaddr));

                if ((sockfd_wifi = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
                    perror("socket2:modbus cllient");
                    sockfd_wifi=0;
                }     
                their_addr.sin_family = AF_INET;      /* host byte order */
                their_addr.sin_port = htons(8888);    /* short, network byte order */
                their_addr.sin_addr = *((struct in_addr *)he->h_addr);
                bzero(&(their_addr.sin_zero), 8);     /* zero the rest of the struct */         
                
                if (connect(sockfd_wifi, (struct sockaddr *)&their_addr,sizeof(struct sockaddr)) == -1) {
                    perror("modbus cllient2:connect error");
                    sockfd_wifi=0;
                    //--exit(1);
                }

                
                if(sockfd_wifi){write(sockfd_wifi, wsrequest, strlen(wsrequest));  sleep(5);}
            }
          
           
            
        }
           printf("close wifi ....read_size=%d \r\n",read_size);
           if(read_size>0) close(sockfd_wifi);
           sleep(3);
        }
       
        client_abort=1;
        RED; printf("TCP Client Abort:%d\r\n",read_size); CLEAR;
        pthread_exit(&retval);
    
}

void main(int argc,char *argv[])
{
    unsigned char b;
    char * pos;
    pthread_t thread_modem,thread_wscale,thread_wifi;
    unsigned char c[3];
    unsigned char cp[3];
    char sbuf[32];
    char str[128];
    char line[100];
    unsigned int i=0;
    unsigned int n,j;
    unsigned long sd_serial;
    int bytes;
    struct input_event data;
    //unsigned long current_time,next_rate;
    char boot=1;
    FILE *file;
    reg_id[0] = 5;
    reg_id[1] = 15;
    reg_id[2] = 25;
    reg_id[3] = 35;
    system("nmcli device wifi connect dpu password 9427610356");
    system("echo 6 > /sys/class/gpio/export");  
    system("echo out > /sys/class/gpio/gpio6/direction");
        
    system("echo 3 > /sys/class/gpio/export");  // KEY CLOCK EN
    system("echo out > /sys/class/gpio/gpio3/direction");
#ifndef SPI_HW
#ifdef PCB_V1
        system("echo 14 > /sys/class/gpio/export");  //lcd clk
        system("echo 15 > /sys/class/gpio/export"); //lcd data
        system("echo out > /sys/class/gpio/gpio14/direction");
        system("echo out > /sys/class/gpio/gpio15/direction");    
        fmosi = open("/sys/class/gpio/gpio15/value",O_WRONLY);   //MUX1 GPIO
        fclk = open("/sys/class/gpio/gpio14/value",O_WRONLY);   //MUX1 GPIO
        print_ctrl = open("/sys/class/gpio/gpio6/value",O_WRONLY);
        PT_OFF;
        init_lcd();
        clear_lcd();
        //update_lcd();
        lcd_puts(0,1," MILK-PROCESSOR ");
        lcd_puts(0,2,"   VER:OP.A03t  ");//s47
        update_lcd();     
         
#else
        system("echo 10 > /sys/class/gpio/export"); //system("echo 6 > /sys/class/gpio/export"); // KEY CLOCK EN
        system("echo out > /sys/class/gpio/gpio10/direction");//system("echo out > /sys/class/gpio/gpio6/direction");
        system("echo 11 > /sys/class/gpio/export");  
        system("echo out > /sys/class/gpio/gpio11/direction");     
        fmosi = open("/sys/class/gpio/gpio11/value",O_WRONLY);   //MUX1 GPIO
        fclk = open("/sys/class/gpio/gpio6/value",O_WRONLY);   //MUX1 GPIO  
        print_ctrl = open("/sys/class/gpio/gpio10/value",O_WRONLY);
        PT_ON;

        init_lcd();
        clear_lcd();
        //update_lcd();
        lcd_puts(0,1," MILK-PROCESSOR ");
        lcd_puts(0,2,"   VER:OP.S03v7 ");//s47
        update_lcd();     
        
#endif       
#endif
        
        
    fmux1 = open("/sys/class/gpio/gpio3/value",O_WRONLY);   //MUX1 GPIO
    
    system_call("udevadm info -a -n /dev/mmcblk0 | grep {serial}",temp_buf);
    
    pos = strstr(temp_buf,"==\"");
    
    if(pos)
    {
        pos[13]=0;
        puts(&pos[5]);
        sd_serial = strtoul(&pos[5],NULL,16);
        printf("sd_serial=%u\n",sd_serial);
        sprintf(sbuf,"%015u",sd_serial);
        puts("SD_IMEI");puts(sbuf);
       
    }
    system_call2("cat /tmp/mmc/ws_mode.txt",temp_buf);
    ws_mode = temp_buf[0]-0x30;
    if(ws_mode >2 || ws_mode<0)  ws_mode=0;
    
    
   if(access( "/tmp/usb/record.del", F_OK ) != -1) // remove  previous month files
   {
     memset(line,0,100); // clear buffer
     system_call("cat /tmp/usb/record.del",line); // read line ex. 06_22 
     i = atoi(&line[0]); // month-1
     n = atoi(&line[3]);//year
     while(n)
     {
          for(j=i;j>0;j--)
          {
              sprintf(str,"rm /tmp/mmc/morning/%02d_%02d.dat",j,n);
              system(str);
              sprintf(str,"rm /tmp/mmc/evening/%02d_%02d.dat",j,n);
              system(str);
          }
          i=12;
          n--;
          if(n<16)break;
          
     }
   }
//88 #ifdef EN4

/*    system("insmod /tmp/mmc/input-core.ko");
    system("insmod /tmp/mmc/hid.ko");
    system("insmod /tmp/mmc/hid-generic.ko");
    system("insmod /tmp/mmc/evdev.ko");
    system("insmod /tmp/mmc/usbhid.ko");
    
    system("insmod spi-gpio-custom bus0=2,21,19,22,0,1000000");
    system("insmod i2c-gpio-custom bus0=0,20,18");

    system("mkdir /tmp/mmc");
    system("echo 3 > /sys/class/gpio/export");  // KEY CLOCK EN
    system("echo out > /sys/class/gpio/gpio3/direction");

    system("echo 1 > /sys/class/gpio/export");  // KEY CLOCK EN
    system("echo out > /sys/class/gpio/gpio1/direction");

    system("echo 26 > /sys/class/gpio/export");
    system("echo 27 > /sys/class/gpio/export");

    system("echo out > /sys/class/gpio/gpio26/direction");
    system("echo out > /sys/class/gpio/gpio27/direction");

    //system("echo in > /sys/class/gpio/gpio27/direction");
    */
    // Open Keyboard
    kb_fd = open(pDevice, O_RDONLY | O_NONBLOCK);



    system("systemctl stop --now systemd-timesyncd.service");
    system("systemctl disable systemd-timesyncd.service");        
        
        
    //88 fmux1 = open("/sys/class/gpio/gpio3/value",O_WRONLY);   //MUX1 GPIO
    //88 fmux2 = open("/sys/class/gpio/gpio26/value",O_WRONLY);   //MUX2 GPIO
//mount: mounting /dev/mmcblk0p1 on /tmp/mmc failed: Device or resource busy 
//mount: mounting /dev/mmcblk0p1 on /tmp/mmc failed: Invalid argument
    //88 write(fmux1,&value_off,1);
    //88 write(fmux2,&value_off,1);

    //fkey = open("/sys/class/gpio/gpio0/value",O_WRONLY);   //keyboard clock enable 0 for new pcb 
    load_rtc();

    file = fopen("/tmp/mmc/msg.txt", "r"); // open rate chart csv
    if(file) {
        i=0;
        while(fgets(line,30,file))
        {
           strcpy(labels[i],line);  
           n = strlen(labels[i]); 
           labels[i][n-2]=0; 
           i++;
        }
        fclose(file);
    }
    

    
    lit_mode=0; //default LiterMod NNN.D
    fat_only=0;
    session_format=0;
    session_single_dp=0;
    rate_disable=0;
    modem_enable = 0;
    memset(line,0,100); // clear buffer
    system_call("cat /tmp/mmc/dpu.cfg",line);
    if(strstr("cat",line)<=0)
    {  
       printf("DPU CFG:%s\r\n",line);
       if(line[0] == '1'){lit_mode=1; puts("WWW.DD ENABLED\r\n");}//enable WWW.DD
       if(line[1] == '1'){fat_only =1; puts("FAT ONLY SYSTEM\r\n");}
       if(line[2] >= '0' &&  line[2] <= '9'){regional= line[2]-0x30;}
       if(line[3] == '1') en_disp_rate=1; //enable rate display after online data
       if(line[4] == '1') session_format=1;
       if(line[5] == '1') session_single_dp = 1;//enable single dp
       if(line[6] == '1') rate_disable = 1;
       if(line[7] == '1') modem_enable = 1;
       pcycle = 0;
       if(line[8] == '1') pcycle = 5;
       if(line[8] == '2') pcycle = 10;
       if(line[8] == '3') pcycle = 31;
       
       
       //fat_only=0;
       strcpy(company_name,&line[8]);
       puts(company_name);
       if(regional==1)puts("HINDI PRINT\r\n");
    }
    modem_enable = 1;
    system("mkdir /tmp/dpu");


    if(access( "/tmp/mmc/pwd.dat", F_OK ) == -1)
    {
      system("echo \"000000\" > /tmp/mmc/pwd.dat");  //default password
    }

    if(access( "/tmp/mmc/mdm.txt", F_OK ) == -1)
    {
      system("echo \"0\" > /tmp/mmc/mdm.txt");  //default modem error counter
    }
       if(dpu_settings[5][10] == 'D'){ system("stty -F /dev/ttyS1 19200 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr "); }
       else                          { system("stty -F /dev/ttyS1 9600 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr "); }
        
        
        uart0_fd = open ("/dev/ttyS0", O_RDWR | O_NOCTTY | O_SYNC);
	    if(uart0_fd<0)puts("uart failed ..!\r\n");
 
        
        //system("stty -F /dev/ttyS1  ispeed 2400");
       // system("stty -F /dev/ttyS1 19200 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr ");
        
        //system_call("echo -n 'asdfsadf\r\nasdffadfad\r\n424243\r\n      44444\r\n' > /dev/ttyS1",temp_buf);
        
        //sleep(5);
        //exit(1);
        
        
        
        uart1_fd = open ("/dev/ttyS1", O_RDWR | O_NOCTTY | O_SYNC);
	    if(uart1_fd<0)puts("uart failed ..!\r\n");
        

        
        uart2_fd = open ("/dev/ttyS2", O_RDWR | O_NOCTTY | O_SYNC);
	    if(uart2_fd<0)puts("uart failed ..!\r\n");
        set_interface_attribs (uart2_fd, B9600, 0);
        //tcflush(uart1_fd,TCIOFLUSH);usleep(200000);
        
        //strcpy(temp_buf,"\nA5640650492270420");
        //write(uart2_fd,temp_buf,strlen(temp_buf));
        
        //exit(1);
        load_settings();
        memcpy(sbuf,scode,4);
        ORANGE;puts(sbuf);CLEAR;
       /* puts("test");
        
        while(1)
        {
             //system("stty -F /dev/ttyS1  speed 2400");
             //tcflush(uart1_fd,TCIFLUSH);usleep(200000);
            set_interface_attribs2 (uart1_fd, B2400, 0);
            //set_blocking2(uart1_fd,1);
            //strcpy(temp_buf,"Analyzer\r\n");
            //write(uart1_fd,temp_buf,strlen(temp_buf));
            sleep(1);
            
            tcflush(uart1_fd,TCIOFLUSH);usleep(200000);
            set_interface_attribs2 (uart1_fd, B19200, 0);
           // set_blocking2(uart1_fd,1);
            //system("stty -F /dev/ttyS1  speed 19200");
            strcpy(temp_buf,"PRINTER\r\n");
            write(uart1_fd,temp_buf,strlen(temp_buf)); 
            sleep(1);
        }*/
        

	    //init_lcd();



		/*
	    system("umount /tmp/mmc");
	    i=system("mount /dev/mmcblk0p1 /tmp/mmc");
	    printf("Memory Status:%d\n",i);

		if(if(access("/tmp/mmc/",F_OK)==-1)) // memory error 65280
		{
	          lcd_puts(0,1,"  MEMORY ERROR  ");
	          update_lcd();
	          while(1)sleep(5);
		}
		*/

        
        
        system("mkdir /tmp/mmc/morning");
        system("mkdir /tmp/mmc/evening");
        
        if(dpu_settings[5][10] == 'D')
        {
          puts("DotMatix Selected\r\n");
           
           //system("stty -F /dev/ttyS1 19200 -raw");//set_interface_attribs (uart1_fd, B19200, 0);
          //EN_PRINT;
          usleep(100000);

          //write(uart1_fd,EJECT,1);
          //usleep(500000);

          exit_regional();
          usleep(200000);
        }
        else
        {
             //system("stty -F /dev/ttyS1 19200 -raw");//set_interface_attribs (uart1_fd, B9600, 0);
            set_blocking(uart0_fd,0);
            
            
        }
        
        if(dpu_settings[6][15]=='N')
        {
            puts("Connecting to wifi..");
            pthread_create( &thread_wifi , NULL , wifi_client , NULL); // receive sensor data
            sleep(5);
        }
        //--while(1){sleep(2);}
        
        
        tcflush(uart1_fd,TCIOFLUSH);
        //set_interface_attribs (uart1_fd, B2400, 1);
 
        //sleep(1);

        
        set_interface_attribs (uart0_fd, B9600, 0);EN_GPRS;
        
        /*close(uart0_fd);
        system("stty -F /dev/ttyS0 9600  raw -echo -echoe -echok");
        uart0_fd = open ("/dev/ttyS0", O_RDWR | O_NOCTTY | O_SYNC);
        */
        
        set_blocking(uart0_fd,0);
        //send_sms("9737961259","test\r\nadsfasd\r\n");
        str[0]=0x03;str[1]=0x06;str[2]=0x09;write(uart0_fd,str,3);sleep(1);
        
                
                
        write(uart0_fd,"ATE0\r\n",6);
        usleep(300000);
        write(uart0_fd,"AT&K0\r\n",7);
        usleep(300000);
        write(uart0_fd,"AT+CMGF=1\r\n",11);
        usleep(300000);
        write(uart0_fd,"AT+CMGF=1\r\n",11);
        usleep(300000);
        write(uart0_fd,"AT&W0\r\n",7);
        usleep(500000);
        str[0]=0x05;str[1]=0x06;str[2]=0x07;write(uart0_fd,str,3);sleep(1);
        
        //strcpy(temp_buf,"Hello World");
//IMEI:864424041931236/TXB/$$200721,122050-A*#    
        strcpy(IMEI,sbuf);
        tcflush(uart0_fd,TCIOFLUSH);sleep(2);
        if(dpu_settings[6][15]=='N') 
        {
          pthread_create( &thread_modem , NULL , thread_uart0 , NULL); // receive sensor data
          
            
        }
        else 
        {
           strcpy(IMEI,sbuf);
           gprs_lock=0;
        }
        

        
        //modem_status();
        //modem_enable=0;
       
        //modem_enable=0;
        if(modem_enable==1 && dpu_settings[6][15]=='N')
        {
        //sleep(1);
            i = 1;
            while(i >0)
            {
               puts("Reading IMEI..");   
                str[0]=0x05;str[1]=0x06;str[2]=0x07;str[3]=0x07;
                write(uart0_fd,str,3);
                sleep(2); 
                strcpy(str,cmd_buf);
                //strcpy(IMEI,"0000000000000000");
                gprs_lock=100;
                pos = strstr(str,"IMEI:");
                if(pos && strlen(str)>=21) //IMEI:866710031929695/TXB
                {
                    if(strstr(str,"/TXB")){
                        modem_type =1;
                        puts("MODEM_TYPE: SIM800C");
                    }
                    //str[20]=0;
                    pos[20]=0;
                    strcpy(IMEI,&pos[5]);
                    puts(IMEI);
                    
                    gprs_lock=0;
                    break;
                }
                i--;
            }
        }
        //if(i==0){modem_enable=0;}
        modem_status();
         
        //sprintf(temp_buf,"~++1,+9197379",&str[30],str_buf,mid,str,tm.tm_mday,tm.tm_mon+1,tm.tm_year-100,&str_buf[20],&str_buf[30],lit,dflag[lit_dirty],fat,dflag[fat_dirty]); 
        //strcpy(temp_buf,"~++1,+919737961259,DPU POWERON\r\n");
        //write(uart0_fd,temp_buf,strlen(temp_buf));
        //sleep(5); 
        //set_blocking(uart1_fd,1);

        /*
        str[0]=0x05;str[1]=0x06;str[2]=0x07;
        write(uart1_fd,str,3);
        sleep(2);
        read(uart1_fd,str,16);
        puts("IMEI:");puts(str);
        */
        //set_interface_attribs (uart1_fd, B19200, 0);
        //temp_buf[0]=0x1b;temp_buf[1]=0x40;
        //write(uart1_fd,temp_buf,2);

        //puts("Power ON...V1.a!!\r\n");

//88#endif


	    #ifdef AUTO_RESET
	    lcd_puts(0,2,"  <AUTO RESET>  ");
	    #endif 

        system_call("date -R --rfc-2822",line);
	    //lcd_puts(0,3,line);
        





        //--load_rate_chart("/tmp/mmc/rate1.csv",0);
        //--if(dpu_settings[6][8] == 'Y')
        //--load_rate_chart("/tmp/mmc/rate2.csv",1);

	    update_lcd();
        //exit(1);
        sleep(2);
        //sprintf(str_buf,"DEVICE UP:%s\r\n",IMEI);
        tcflush(uart0_fd,TCIOFLUSH);usleep(1);
        
        if(modem_enable==1 && dpu_settings[6][15]=='N'){
        //sprintf(str_buf,"$$$CMD,GET_RATE,%s\r\n",IMEI);
            //sprintf(str_buf,"ITC/3942784/234234/23423/23424/%s\r\n",IMEI);
            //sprintf(str_buf,"G$$$CMD,GET_RATE,I%s HTTP/1.1 Rate:01.0   Firmware: 1.SU60i$\r\n",IMEI);
            #ifdef PCB_V1
            sprintf(str_buf,"G$$$CMD,GET_RATE,I%s HTTP/1.1 Rate:01.0   Firmware: OP.A03s$\r\n",IMEI);
            #else
            sprintf(str_buf,"G$$$CMD,GET_RATE,I%s HTTP/1.1 Rate:01.0   Firmware: OP.S03s$\r\n",IMEI);
            #endif
            
            
            ws_write(uart0_fd,str_buf,strlen(str_buf));
            puts(str_buf);
        }
        //set_interface_attribs (uart1_fd, B2400, 0);
        
         // receive analyzer data
        pthread_create( &thread_wscale , NULL , thread_uart2 , NULL); // receive wscale data
        
        //while(1);
        //--tcflush(uart0_fd,TCIOFLUSH);usleep(100000);
if(modem_enable==1 && dpu_settings[6][15]=='N')
{
        if(gprs_lock==0)//check only if modem is connected
        {
            memset(frame1,0,500);
	        clear_lcd();
	        lcd_puts(0,2,"Checking  Update");
	        update_lcd();
            
		    while(gprs_lock <90 /*&& (strstr(frame1,"$$$CMD,0,5") ==0||strstr(frame1,"$$$CMD,0,0") ==0)*/)  // wait for server replay
		    {
		       sleep(1);
               
               printf("*");
		       gprs_lock++;
               if(gprs_lock%11==0 && download_started==1) {ws_write(uart0_fd,xack,strlen(xack));puts(xack);}
               if(strstr(frame1,"INVALID_FRAME")||strstr(frame1,"Switching Protocols") && gprs_lock < 10)break;
		    }
	    }

}
        
        clear_lcd();

        /*
        lcd_puts(0,0," Enable Printer ");
        lcd_puts(0,2,"Yes: Press Enter");
        lcd_puts(0,3,"No : Press Esc  ");
        update_lcd();
        */
        


        //set_interface_attribs (uart1_fd, B9600, 0);EN_GPRS;
        //sleep(1);
        //str[0]=0x05;str[1]=0x06;str[2]=0x07;
        //write(uart1_fd,str,3);

	KEY_HIGH;
	key_mode =0; //alpha numeric
    key = 1;
  
    while(1)
    {


       if(key)
       {
         printf("KEY=%X\r\n",key);
         if(boot)  // only on startup
         {
           //if(key == 0x0a) print_en =1;
           //else            print_en =0;
           print_en =1;
           set_interface_attribs (uart2_fd, B9600, 0);
           
           
           pthread_create( &thread1, NULL , blink_text , NULL);

           load_rate_chart("/tmp/mmc/rate1.csv",0);
           if(dpu_settings[6][8] == 'Y' || dpu_settings[6][8] == 'S')
           load_rate_chart("/tmp/mmc/rate2.csv",1);
           
           key = 0;
           boot =0;
             
          
         }

         if(key == 'a') {fstate = COLLECTION;session=0;edit_mode=0;flag_scan=0;edit_rtc=0;edit_record=0;}
         if(key == 'b') {fstate = PASSWORD;flag_scan=0;edit_pass=0;edit_record=0;edit_rtc=1;}
         if(key == 'c') {fstate = MEMBER;flag_scan=0;edit_record=0;edit_rtc=0;}

         if(key == 'f') {fstate = PASSWORD;flag_scan=0;edit_pass=0;edit_record=0;edit_rtc=0;}//SET_DPU;

         if(key == 'h') {fstate = SES_REP;flag_scan=0;edit_rtc=0;edit_record=0;}
         if(key == 'd') {fstate = PAY_REP;flag_scan=0;edit_rtc=0;edit_record=0;}

         #ifdef  PROJ_MAHI
         if(key == 'e') {fstate = EDIT;flag_scan=0;edit_rtc=0;edit_record=0;}//->EDIT 
         #endif

         #ifdef PROJ_KMD
         //if(key == 'e') {fstate = PASSWORD;flag_scan=0;edit_rtc=0;edit_record=1;}//PASSWORD->EDIT
         if(key == 'e') {fstate = EDIT;flag_scan=0;edit_rtc=0;edit_record=0;}//->EDIT
         #endif

         if(key == 'z') {fstate = INFO;flag_scan=0;edit_rtc=0;edit_record=0;}//dpu info.


         if(key == 'g')
         {
             if(access( "/dev/sda", F_OK ) != -1)
             {
                  flag_scan=0;
                  system("mount /dev/sda1 /tmp/usb");
	          usb_inserted =1;
	          key = 5;
	          fstate=PASSWORD;
             }
             else
             {
                 usb_inserted =0;
                 fstate=0;
             }
             edit_rtc=0;
         }


         lcd_page();
         lcd_busy=0;

       }
       
        
       usleep(60000);  //100ms wait
       if(kwait_feed>0)   kwait_feed--;
       if(kwait_feed==1 )
       {
         key_pos=0;
         kwait_feed=0;
         cx++;
         update_lcd();
       }
       
       bytes=0;
       if(keyboard_ok ){bytes = read(kb_fd, &data, sizeof(data));}
       //printf("key_status=%d\r\n",kb_fd);
       if(bytes > 0 && data.type ==1 && data.value ==1)
       {
              //printf("Keypress value=%x, type=%x, code=%x\n", data.value, data.type, data.code);
              get_key(data.code);
              
       }   
        if(key == '*')
         {
             
               
                if(modem_enable==1 && dpu_settings[6][15]=='N'){
                //sprintf(str_buf,"$$$CMD,GET_RATE,%s\r\n",IMEI);
                    //G$$$CMD,GET_RATE,867793038116143 HTTP/1.1 Rate:1.1,Firmware:2.K84
                    check_update=1;
                    memset(frame1,0,500);
                    set_interface_attribs (uart0_fd, B9600, 0);EN_GPRS;
                    tcflush(uart0_fd,TCIOFLUSH);
                    //free_ram=0;
                    usleep(500000);
                    free_ram=0;
                    set_blocking(uart0_fd,0);                    
                    gprs_lock = 0;
                    sprintf(str_buf,"G$$$CMD,GET_RATE,I%s HTTP/1.1 Rate:01.0   Firmware: OP.X02x$\r\n",IMEI);
                    puts(str_buf);
                    
                    ws_write(uart0_fd,str_buf,strlen(str_buf));
                    clear_lcd();
                    lcd_puts(0,2,"Checking  Update");
                    
                    update_lcd();
                    sleep(2);
                }
                if(modem_enable==1)
                {
                        //--if(gprs_lock==0)//check only if modem is connected
                        {

                            while(gprs_lock <90  )  // wait for server replay
                            {
                            sleep(1);
                            //free_ram=0;
                            printf("*");
                            gprs_lock++;
                            if(gprs_lock%11==0) {ws_write(uart0_fd,xack,strlen(xack));puts(xack);}
                            if(strstr(frame1,"INVALID_FRAME")||strstr(frame1,"Switching Protocols") && gprs_lock < 10)break;
                            }
                            //kbhit_wait();
                        }
                        check_update=0;
                }
                key=0;
             
         }

       /*
       usleep(80000);  //100ms wait
       KEY_LOW;
       c[0]=c[1]= c[2] = 0xff;

       transfer(lcd_fd,c,c,3);

       if(kwait_feed>0)   kwait_feed--;

       if(kwait_feed==1 )
       {
         key_pos=0;
         kwait_feed=0;
         cx++;
         update_lcd();
       }

       if(c[0] !=0x00 || c[1] != 0x00 || c[2] !=0x00)
       {

          key_code = c[0]; key_code <<=8;
          key_code |= c[1];key_code <<=8;
          key_code |= c[2];
          key_code = 0XFFFFFF - key_code;
          key_code &= ~0xE00001;
          get_key(key_code);

       }
       KEY_HIGH;
       */
    }

}

void enable_regional()
{
   unsigned char cmd[10];
   //return;
   cmd[0] = 0x1b;cmd[1] = 0x28;cmd[2] = 0x49;cmd[3] = 0x02;cmd[4] = 0x00;cmd[5] = 0x31;cmd[6] = 0x42;cmd[7] = 0x0d;
   write(uart1_fd,cmd,8); 
   usleep(300000);
   cmd[0] = 0x1b;cmd[1] = 0x28;cmd[2] = 0x4A;cmd[3] = 0x02;cmd[4] = 0x00;cmd[5] = 0x30;cmd[6] = 0x31;cmd[7] = 0x0d; 
   write(uart1_fd,cmd,8);
   usleep(300000);
   cmd[0] = 0x1b;cmd[1] = 0x28;cmd[2] = 0x70;cmd[3] = 0x01;cmd[4] = 0x00;cmd[5] = 0x30;cmd[6] = 0x0D;
   write(uart1_fd,cmd,7);
   usleep(300000);
}
void exit_regional()
{
   unsigned char cmd[10];
   //return; 
   cmd[0] = 0x1b;cmd[1] = 0x28;cmd[2] = 0x49;cmd[3] = 0x01;cmd[4] = 0x00;cmd[5] = 0x30;cmd[6] = 0x0d;
   write(uart1_fd,cmd,7); 
   usleep(300000);
}
void kbhit_wait()
{
    
       get_key(read_keyboard());
       /*
       key =0;
       while(!key){
       usleep(80000);
       KEY_LOW;
       c[0]=c[1]= c[2] = 0xff;
       transfer(lcd_fd,c,c,3);
       if(kwait_feed>0)   kwait_feed--;
       if(kwait_feed==1 )
       {
         key_pos=0;
         kwait_feed=0;
       }
       if(c[0] !=0x00 || c[1] != 0x00 || c[2] !=0x00)
       {

          key_code = c[0]; key_code <<=8;
          key_code |= c[1];key_code <<=8;
          key_code |= c[2];
          key_code = 0XFFFFFF - key_code;
          key_code &= ~0xE00001;
          get_key(key_code);
       }
       KEY_HIGH;
    }*/

}
void print_where()
{
   clear_lcd();
   lcd_puts(0,1," PRINT    - [1] ");
   lcd_puts(0,2," DISPLAY  - [2] ");
   update_lcd();
   kbhit_wait();
   display_en =0;
   if(key == '1') display_en=0;
   if(key == '2') display_en=1;
   
}

void ask_mtype()
{
   //--clear_lcd();
   lcd_notify("COW-[1]  BUF-[2]",2);
   //lcd_puts(0,2," BUF    - [2] ");
   
   
   while(1)
   {
    kbhit_wait();
    //display_en =0;
    if(key == '1') { milk_type=0;break;}
    if(key == '2') { milk_type=1;break;}
   }
   key=0;
   update_lcd();
}

const char keymap[] = {30,48,46,32,18,33,34,35,23,36,37,38,50,49,24,25,16,19,31,20,22,47,17,45,21,44};
int get_char(unsigned long key_code)
{
    int i=0;
    for(i=0;i<26;i++)
    {
        if(key_code == keymap[i]){return(65+i);}
    }
    if(key_code == 57) return(' ');
    return 0;
}
void get_key(unsigned long key_code)
{
  int p;
  p = get_char(key_code);
  if(p>0)
  {
      if(key_mode){
          key = p;
          //key_pos++;
      }
  }
  if(key_code== 0x4f || key_code== 0x02)
  {
     key = '1';
     //if(key_mode) key = k1[key_pos++];

  }
  if(key_code == 0x50 || key_code== 0x03)
  {
     key = '2';
     //if(key_mode) key = k2[key_pos++];
  }
  if(key_code == 0x51 ||key_code== 0x04)
  {
     key = '3';
     //if(key_mode) key = k3[key_pos++];
  }
  if(key_code == 0x4b ||key_code== 0x05)
  {
     key = '4';
    // if(key_mode) key = k4[key_pos++];
  }
  if(key_code == 0x4c ||key_code== 0x06)
  {
     key = '5';
     //if(key_mode) key = k5[key_pos++];
  }
  if(key_code == 0x4d ||key_code== 0x07)
  {
     key = '6';
     //if(key_mode) key = k6[key_pos++];
  }
  if(key_code == 0x47||key_code== 0x08)
  {
     key = '7';
     //if(key_mode) key = k7[key_pos++];
  }
  if(key_code == 0x48||key_code== 0x09)
  {
     key = '8';
     //if(key_mode) key = k8[key_pos++];
  }
  if(key_code== 0x49||key_code== 0x0a)
  {
     key = '9';
     //if(key_mode) key = k9[key_pos++];
  }
  if(key_code== 0x60 || key_code== 0x1c) //ENTER
  {
     key = 0x0a; //key = 'q';
  }
  if(key_code == 0x52 ||key_code== 0x0b)
  {
     key = '0';

  }
  if(key_code == 0x01 || key_code == 0x0e) //ESC/backspace
  {
     key = 'q';//key = 0x0a;
     //if(fstate<USBMENU && fstate!=(PASSWORD+1))system("umount /tmp/usb &");//unmount usb
  }

  if(key_mode && key_pos > 3) key_pos=0;


  if((key_code == 0x42) && fstate==2 && cy==1) //F8:delete member entry
  {
      t = time(NULL);
      tm = *localtime(&t);
      sprintf(temp_buf,"%02d%02d",tm.tm_hour,tm.tm_min);
      //if(lcd_buffer[1][9] == temp_buf[0] && lcd_buffer[1][10] ==temp_buf[1] && lcd_buffer[1][11] ==temp_buf[2] && lcd_buffer[1][13]==temp_buf[3])
      if(1)
      {

         printf("DeleteEntry:\r\n");
         cx=14;
         if(fat_only==0)cy=3;
         else cy=2;

         key = 0x0a;
         entry_delete=1;
         /*
         dfd = open(entry_file,O_WRONLY | O_CREAT, 0666);
         lseek(dfd,entry_offset,SEEK_SET);
         write(fd,"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",43);
         close(dfd);
         if(fat_only){snf=0;}
         sprintf(temp_buf,"%%%s/%c/%02d%02d%02d/%s/%s/%04d/%s/%c/L%05.2f%d/F%04.1f%d/S%04.1f%d/A%07.2lf/%02d:%02d/R%5.2f/I%s$",str_buf,sc,tm.tm_mday,tm.tm_mon+1,tm.tm_year-100,&str_buf[6],&str_buf[11],mid,str,str[60],lit,lit_dirty,fat,fat_dirty,snf,fat_dirty,amount,tm.tm_hour, tm.tm_min,rate,IMEI);
         */

      }
      else{ cx=9;
      key='q';}
  }


  //funciton key
  if(fstate==0){
  if(key_code == 0x37)   //F1
  {
     key = '*';
  }
  if(key_code == 0x3b)   //F1
  {
     key = 'a';
  }
  if(key_code == 0x3c)
  {
     key = 'b';
  }
  if(key_code == 0x3e) //F4:REPORT
  {
     #ifdef PROJ_KMD
     key = 'd';
     #endif
  }
  if(key_code== 0x3d)  //F3:EDIT MEMBER MASTER
  {
     //#ifdef PROJ_KMD
     key = 'c';
     //#endif
  }
  if(key_code == 0x3f) //F5: EDIT DATA
  {
     #ifdef PROJ_KMD
     key = 'e';
     #endif
  }
  if(key_code == 0x40)
  {
     key = 'f';
  }
  if(key_code == 0x41)
  {
     key = 'g';
  }
  if(key_code == 0x42) //F8
  {
     key = 'h';

     system("rm /tmp/tprint");
  }
  if(key_code == 0x58)  //F12 - setting screen
  {
     key = 'z';

  }
  }
  
  if(key_mode==1) kwait_feed = 2;
  if(key_mode==1 && ( key == 'q' || key == 0x0a  )) {kwait_feed=0;key_pos=0;}

}

int dfd;
#ifdef OLD_KB
void get_key2(unsigned long key_code)
{


  if(key_code & 0x04)
  {
     key = '1';
     if(key_mode) key = k1[key_pos++];

  }
  if(key_code & 0x08)
  {
     key = '2';
     if(key_mode) key = k2[key_pos++];
  }
  if(key_code & 0x10)
  {
     key = '3';
     if(key_mode) key = k3[key_pos++];
  }
  if(key_code & 0x02)
  {
     key = '4';
     if(key_mode) key = k4[key_pos++];
  }
  if(key_code & 0x800)
  {
     key = '5';
     if(key_mode) key = k5[key_pos++];
  }
  if(key_code & 0x1000)
  {
     key = '6';
     if(key_mode) key = k6[key_pos++];
  }
  if(key_code & 0x400)
  {
     key = '7';
     if(key_mode) key = k7[key_pos++];
  }
  if(key_code & 0x200)
  {
     key = '8';
     if(key_mode) key = k8[key_pos++];
  }
  if(key_code & 0x100000)
  {
     key = '9';
     if(key_mode) key = k9[key_pos++];
  }
  if(key_code & 0x80000) //ENTER
  {
     key = 0x0a; //key = 'q';
  }
  if(key_code & 0x40000)
  {
     key = '0';

  }
  if(key_code & 0x20000) //ESC
  {
     key = 'q';//key = 0x0a;
     //if(fstate<USBMENU && fstate!=(PASSWORD+1))system("umount /tmp/usb &");//unmount usb
  }

  if(key_mode && key_pos > 3) key_pos=0;


  if((key_code & 0x8000) && fstate==2 && cy==1) //F8:delete member entry
  {
      t = time(NULL);
      tm = *localtime(&t);
      sprintf(temp_buf,"%02d%02d",tm.tm_hour,tm.tm_min);
      if(lcd_buffer[1][9] == temp_buf[0] && lcd_buffer[1][10] ==temp_buf[1] && lcd_buffer[1][11] ==temp_buf[2] && lcd_buffer[1][13]==temp_buf[3])
      {

         printf("DeleteEntry:\r\n");
         cx=14;
         if(fat_only==0)cy=3;
         else cy=2;

         key = 0x0a;
         entry_delete=1;
         /*
         dfd = open(entry_file,O_WRONLY | O_CREAT, 0666);
         lseek(dfd,entry_offset,SEEK_SET);
         write(fd,"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",43);
         close(dfd);
         if(fat_only){snf=0;}
         sprintf(temp_buf,"%%%s/%c/%02d%02d%02d/%s/%s/%04d/%s/%c/L%05.2f%d/F%04.1f%d/S%04.1f%d/A%07.2lf/%02d:%02d/R%5.2f/I%s$",str_buf,sc,tm.tm_mday,tm.tm_mon+1,tm.tm_year-100,&str_buf[6],&str_buf[11],mid,str,str[60],lit,lit_dirty,fat,fat_dirty,snf,fat_dirty,amount,tm.tm_hour, tm.tm_min,rate,IMEI);
         */

      }
      else{ cx=9;
      key='q';}
  }


  //funciton key
  if(fstate==0){
  if(key_code == 0x37)   //F1
  {
     key = '*';
  }
  if(key_code & 0x20)   //F1
  {
     key = 'a';
  }
  if(key_code & 0x40)
  {
     key = 'b';
  }
  if(key_code & 0x100) //F4:REPORT
  {
     #ifdef PROJ_KMD
     key = 'd';
     #endif
  }
  if(key_code & 0x80)  //F3:EDIT MEMBER MASTER
  {
     //#ifdef PROJ_KMD
     key = 'c';
     //#endif
  }
  if(key_code & 0x4000) //F5: EDIT DATA
  {
     #ifdef PROJ_KMD
     key = 'e';
     #endif
  }
  if(key_code & 0x2000)
  {
     key = 'f';
  }
  if(key_code & 0x010000)
  {
     key = 'g';
  }
  if(key_code & 0x8000) //F8
  {
     key = 'h';

     system("rm /tmp/tprint");
  }
  }
  if(key_mode==1) kwait_feed = 12;
  if(key_mode==1 && ( key == 'q' || key == 0x0a  )) {kwait_feed=0;key_pos=0;}

}
#endif
void load_settings()
{
  int fd,i;


  fd = open("/tmp/mmc/dpu_settings.dat",O_RDONLY);  //
  if(fd<=0)return;
  read(fd,dpu_settings[0],16);      //collection point name
  read(fd,dpu_settings[1],16);      //collection point code
  read(fd,dpu_settings[2],16);      //project code
  read(fd,dpu_settings[3],16);      //dist code
  read(fd,dpu_settings[4],16);      //IP
  read(fd,dpu_settings[5],16);      //OPERATOR
  read(fd,dpu_settings[6],16);      //GPRS SMS

  for(i=0;i<7;i++)
  {
    dpu_settings[i][16]=0;

    if( !(dpu_settings[i][0] >='0' && dpu_settings[i][0] <='9') && !(dpu_settings[i][0] >='A' && dpu_settings[i][0] <='Z')) {dpu_settings[i][0] = 0;}
    puts(dpu_settings[i]);puts("\n");
  }
  memcpy(scode,&dpu_settings[1][5],4);
  scode[4]=0;
  printf("scode=%s\r\n",scode);
  //read(fd,dpu_settings[0],16);
  close(fd);
}
void load_rate_chart(unsigned char * filepath,char flag) // flag : buf/mix  , cow
{
  int i,row,col,d,m,y,mid;
  char * tok;
  char name[17];
  char mob[17];
  FILE *file;// = fopen(filepath, "r"); // open rate chart csv
  size_t line_size=1024;
  char line[1024];  // maximum line width
  row=0;




	t = time(NULL);
	tm = *localtime(&t);    //tm.tm_mday,tm.tm_mon+1,tm.tm_year-100
	tm.tm_mon += 1;
	tm.tm_year -=100;



	// update rate1 and rate2 files according to current day.
	system_call("ls /tmp/mmc/nr*.csv",line); //nr121_08_15.csv  nr221_08_15.csv
    line[20] = 0;
	puts(&line[8]);
    line[14] = 0;line[17] = 0;
        d = atoi(&line[12]); m = atoi(&line[15]); y = atoi(&line[18]);
        printf("Next Rate Date = %02d:%02d:%02d\r\n",d,m,y);
        printf("Current Date =  %02d:%02d:%02d\r\n",tm.tm_mday,tm.tm_mon,tm.tm_year);
        if( tm.tm_year >= y && tm.tm_mon >= m && tm.tm_mday >= d && (d !=0 && m != 0 && y !=0 ))
        {
            puts("Applying New rate chart...\r\n");
            sprintf(line,"cp /tmp/mmc/nr1%02d_%02d_%02d.csv /tmp/mmc/rate1.csv",d,m,y);
            system(line);
            sprintf(line,"cp /tmp/mmc/nr2%02d_%02d_%02d.csv /tmp/mmc/rate2.csv",d,m,y);
            system(line);
            puts("Removing Next rate chart...\r\n");
            system("rm /tmp/mmc/nr*.csv");

            //remove next rate files
        }
  //read member list
  file=0;
  if(flag==0)
  {    
    file = fopen("/tmp/mmc/mmlist.txt","r");
    if(access("/tmp/mmc/member.dat",F_OK)==-1)
    {
        fd = open("/tmp/mmc/member.dat",O_WRONLY | O_CREAT, 0666);  //
    }
    else fd=0;

    mmlist[0]=0xFFF;
  }
  if(file)
  { i=0;
    while(fgets(line, sizeof(line), file)) //read each member number
    {
       tok = strtok(line,","); // get id
       if(tok != NULL)
       {
         mmlist[i] = atoi(tok);
         mid = mmlist[i];
         printf("mmlist[%d],%d\r\n",i,mmlist[i]);
       }
       if(fd)
       {
           
		   lseek(fd,mid*32,SEEK_SET); 
		   memset(name,0,16);
		   memset(mob,0,16);
	       tok = strtok(NULL,","); // get name
	       if(tok != NULL)
	       {
	           
	          strcpy(name,tok);
	          write(fd,name,16);      //member name  

	       }
	       tok = strtok(NULL,","); // get mobile#
	       if(tok != NULL)
	       {
	          //lseek(fd,mid*32,SEEK_SET); 
	          strcpy(mob,tok);
	          write(fd,mob,16);      //member mobile

	       }
	       if(dpu_settings[6][8]=='Y' || dpu_settings[6][8]=='S') //only dump if cow/buf enabled
	       {
		       lseek(fd,(1000+mid)*32,SEEK_SET); 
		       write(fd,name,16);      //member name  
		       write(fd,mob,16);      //member mobile
	       }
	       puts(name);
	       puts(mob);
       }
       i++;
    }
    fclose(file);
    if(fd){close(fd);system("sync"); /*system("cp /tmp/mmc/member.dat  /tmp/mmc/recovery");*/}

  }

  system("sync");

  file = fopen(filepath, "r"); // open rate chart csv
  if(!file) return;
  //fgets(line, sizeof(line)); //skip first header line

  while(fgets(line, sizeof(line), file)  && row < 80)//fgets(line, sizeof(line), file)
  {

     for(i=0;line[i] != '\r';i++)
     {
        if(line[i] == ',' ) line[i] = 0;
     }
     line[i] = 0;

     if(row==0){row++;continue;}

     i=0;

     while(line[i++] != 0);

     //printf("offset=%d\n",i);
     col=0;

     for(;col<125;)
     {
         if(flag==0){
         rate_chart[row][col] = atof(&line[i]);}
         else{
         rate_chart2[row][col] = atof(&line[i]);}

         i += strlen(&line[i])+1; // point to next value
         col++;
         //printf("%s",&line[i]);

     }
     //puts("\n");
     row++;

  }
  fclose(file);

}

void load_rtc()
{

    char sbuf[32];
    char str[32];
    char line[50];
    unsigned int h,m,s,dy,mn,yr;


    system_call("i2cget -y 1 0x51 0x05",&line[0]);   //day
    usleep(150);
    system_call("i2cget -y 1 0x51 0x07",&line[6]);  //month
    usleep(150);
    system_call("i2cget -y 1 0x51 0x08",&line[12]);  //year
    usleep(150);
    line[4] = 0;line[10]=0;line[16]=0;

    //strtol(&line[2], NULL, 16);
    dy = strtol(&line[2],NULL,16); mn = strtol(&line[8],NULL,16); yr = strtol(&line[14],NULL,16);
    //dy = atoi(&line[2]); mn = atoi(&line[8]); yr = atoi(&line[14]);
    dy = dy & 0x3F; mn = mn & 0x1F;  yr &= 0x7F;

    //dy = ((dy>>4)*10) + dy&0x0F;   mn = ((mn>>4)*10) + mn&0x0F;   yr = ((yr>>4)*10) + yr&0x0F;

    //printf("day=%d",dy);

    sprintf(&line[14],"%02x",yr);
    sprintf(&line[8],"%02x",mn);
    sprintf(&line[2],"%02x",dy);


	sprintf(str,"/tmp/mmc/M%d.mloc",dy); // check for session lock
	if(access( str, F_OK ) == -1)
	{
	   system("rm *.mloc");//remove all file
	}

	sprintf(str,"/tmp/mmc/E%d.eloc",dy); // check for session lock
	if(access( str, F_OK ) == -1)
	{
	   system("rm *.eloc");//remove all file
	}


    //current_time = yr*mn*dy;

    strcpy(str,"date -s ");
    sprintf(&str[8],"\"20%s-%s-%s ",&line[14],&line[8],&line[2]); // setdate command
    //puts(str);

    //system_call(str,line);
    //set time
    system_call("i2cget -y 1 0x51 0x04",&line[0]);
    usleep(150);
    system_call("i2cget -y 1 0x51 0x03",&line[6]);
    usleep(150);
    system_call("i2cget -y 1 0x51 0x02",&line[12]);
    usleep(150);

    line[4] = 0;line[10]=0;line[16]=0;

    h = strtol(&line[2],NULL,16); m = strtol(&line[8],NULL,16); s = strtol(&line[14],NULL,16);
    //h = atoi(&line[2]); m = atoi(&line[8]); s = atoi(&line[14]);
    h = h & 0x3F; m = m & 0x7F;  s &= 0x7F;
   //h = ((h>>4)*10) + h&0x0F;   m = ((m>>4)*10) + m&0x0F;   s = ((s>>4)*10) + s&0x0F;

    sprintf(&line[2],"%02x",h);
    sprintf(&line[8],"%02x",m);
    sprintf(&line[14],"%02x",s);

    //strcpy(str,"date +%T -s ");
    sprintf(&str[20],"%s:%s:%s\"",&line[2],&line[8],&line[14]); // settime command
    puts(str);

    system_call(str,line);

    system_call("date -R --rfc-2822",line);
    puts(line);puts("\n");





}
void print_seperator(int size)
{
  write(uart1_fd,"----------------------------------------------------------------------------------------",size);
}
void system_call2(char * cmd,char *output)
{
    int offset=0;

    FILE* pipe = popen(cmd, "r");
         if (!pipe) return ;
    //puts("Reading I2C ...\r\n");

    //while(!feof(pipe))
    {
        sleep(1);
        //usleep(400000);
    	while(fgets(&output[offset], 200, pipe) != NULL)
    	{
            puts(&output[offset]);puts("\r\n");
            //usleep(400000);   
    	    offset = strlen(output)-1;
    	}
    }
    pclose(pipe);
}
void system_call(char * cmd,char *output)
{
    int offset=0;

    FILE* pipe = popen(cmd, "r");
         if (!pipe) return ;
    //puts("Reading I2C ...\r\n");

    while(!feof(pipe))
    {
        usleep(1000);
    	if(fgets(&output[offset], 20, pipe) != NULL)
    	{
    	    offset = strlen(output);
    	}
    }
    pclose(pipe);
}


int print_line=0;
int print_page=1;
char pbuf[64];
char header_line[100];

int page_type=0;
int page_size[]={0,62,62,62,63};
int page_offset[]={0,9,9,0,9};

void print_page_no(int header_type)
{
   if(dpu_settings[5][10] == 'D' && deduct_report==0)
   {
    
	print_line++;
	if(print_line > (page_size[header_type]-(regional*page_offset[page_type])))
	{
	print_line=0;
	sprintf(pbuf,"\r\n                               PAGE %d\r\n",print_page);
	write(uart1_fd,pbuf,strlen(pbuf));
	usleep(10000);
	write(uart1_fd,EJECT,1);//EJECT PAPER
	usleep(10000);
        if(header_type==1) //passbook header
        {
	     /*write(uart1_fd,"----------------------------------------------------\r\n",54);print_line++;
	     if(regional==0)
	     {
	         write(uart1_fd,"   Date   | SSN |  LIT  |  FAT  |  SNF  |  AMOUNT   |\r\n",55);print_line++;
	     }
	     write(uart1_fd,header_line,strlen(header_line));print_line++;
	     write(uart1_fd,"----------------------------------------------------\r\n",54);print_line++;
	     */
        }
        if(header_type==2)//bonus
        {
             PRINT_TB3;print_seperator(strlen(header_line)-6);PRINT_CR;print_line++;
             PRINT_TB3;write(uart1_fd,header_line,strlen(header_line));print_line++;// write(uart1_fd,"| MEM  | LTR  | DAYS |  AMOUNT  |  BONUS  |\r\n",45);print_line++;
             PRINT_TB3;print_seperator(strlen(header_line)-6);PRINT_CR;print_line++;

        }
        if(header_type==3) //payment
        {
            
            if(regional)enable_regional();
            print_seperator(strlen(header_line)-12);PRINT_CR;print_line++;
            write(uart1_fd,header_line,strlen(header_line));print_line++;//write(uart1_fd,"| MEM  | LTRS  | SSN |  AMOUNT  |  SIGNATURE   |\r\n",51);print_line++;
            print_seperator(strlen(header_line)-12);PRINT_CR;print_line++;
            if(regional)exit_regional();

        }
        if(header_type==4) //session
        {
           PRINT_TB3;print_seperator(strlen(header_line)-6);PRINT_CR;print_line++;
           PRINT_TB3;write(uart1_fd,header_line,strlen(header_line));print_line++;//write(uart1_fd,"| SR. | MEM  | LTRS  | FAT   |  SNF   |  AMOUNT  |\r\n",52);print_line++;
           PRINT_TB3;print_seperator(strlen(header_line)-6);PRINT_CR;print_line++;

        }
	print_page++;
	}
   }
}

void printer_send(int fd,char *buf,int size)
{
    if(print_opt ==2)return ;
    if(dpu_settings[5][10] == 'D'){
    if(page_type==1)PRINT_TB1;//passbook
    if(page_type==2)PRINT_TB2;//bonus
    }
    write(fd,buf,size);

    if(dpu_settings[5][10] == 'D' && buf[size-1]=='\n') // page line & page count
    {
       print_page_no(page_type);
    }
    if(dpu_settings[5][10] == 'T')
    {
        usleep(300000);
    }

}
char hprint=0;
//F4
void print_passbook()
{
  FILE * fd_s1,* fd_s2,* fd_mm;
  int start_id,end_id,dt,ncount;
  int start_day,start_month,start_year;
  int end_day,end_month,end_year,i;
  char name[17];
  float lit,fat,snf,amt,deduct;
  double total_lit,total_amt,total_deduct;
  unsigned long offset;
  char temp_buf[150];
  char hbuf[50];

  if(print_en==0)return;

  PT_ON;sleep(3);
  close(uart1_fd);     
  if(dpu_settings[5][10] == 'D'){ system("stty -F /dev/ttyS1 19200 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr "); }
  else                          { system("stty -F /dev/ttyS1 9600 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr "); }
  uart1_fd = open ("/dev/ttyS1", O_RDWR | O_NOCTTY | O_SYNC);     
    
       
  EN_PRINT;

  print_line=0;
  print_page=1;
  page_type = 1;

  memcpy(str_buf,&lcd_buffer[1][5],4);str_buf[4]=0;
  start_id = atoi(str_buf);

  memcpy(str_buf,&lcd_buffer[1][10],4);str_buf[4]=0;
  end_id = atoi(str_buf);

  //start_id =0;
  //end_id =0;

  memcpy(str_buf,&lcd_buffer[2][6],8);str_buf[2]=str_buf[5]=str_buf[8]=0;          // start 01/05/15
  memcpy(&str_buf[16],&lcd_buffer[3][6],8);str_buf[18]=str_buf[21]=str_buf[24]=0;  // end   01/05/16



  
  start_day = atoi(&str_buf[0]);
  end_day = atoi(&str_buf[16]);

  start_month = atoi(&str_buf[3]);
  end_month = atoi(&str_buf[19]);

  start_year = atoi(&str_buf[6]);
  end_year = atoi(&str_buf[22]);

  print_where();
  if(display_en) 
  {
     close(uart1_fd);
     uart1_fd  = open ("/dev/null", O_RDWR | O_NOCTTY | O_SYNC);  //redirect uart data to /dev/null
  }
  con=0;cx=15;lcd_notify("[Printing...   ]",1);

  printf("%d,%d & %d,%d\n",start_month,end_month,start_year,end_year);

  if(start_month != end_month  ||  start_year != end_year  || start_day > end_day)
  {
     clear_lcd();
     lcd_puts(0,1,"  INVALID DATE  ");
     update_lcd();
     usleep(2000000);
     return;
  }
  if(dpu_settings[5][10] == 'T'){
  temp_buf[0] = 0x1B;temp_buf[1] = 0x21;temp_buf[2] = 0x21;
  write(uart1_fd,temp_buf,3);
  }
  else  if(regional >0)
  {
    enable_regional();
  }

  if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
  else printer_send(uart1_fd,"\r\n",2);
  i=0;
  memcpy(temp_buf,dpu_settings[0],16);while(i<16){if(temp_buf[i++]=='_')break;} temp_buf[i-1]=0;

   i = strlen(temp_buf); i = (21-i)/2;

   //printer_send(uart1_fd,"                     ",i-2); // keep label in center

   printer_send(uart1_fd,temp_buf,strlen(temp_buf));printer_send(uart1_fd,"\r\n",2);

  if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
  else printer_send(uart1_fd,"\r\n",2);

  //if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
 
  if(regional ==0){
  if(special_report==0 && deduct_report==0) printer_send(uart1_fd,"Member's Passbook    \r\n",23);
  else if(special_report)                   printer_send(uart1_fd,"Special  Report      \r\n",23);
  else if(deduct_report )                   printer_send(uart1_fd,"Deduction  Report    \r\n",23);
  }
  else
  {
  if(special_report==0 && deduct_report==0) { printer_send(uart1_fd,labels[MP_BOOK],strlen(labels[MP_BOOK])); printer_send(uart1_fd,"\r\n",2);}
  else if(special_report)                   { printer_send(uart1_fd,labels[SP_REPORT],strlen(labels[SP_REPORT])); printer_send(uart1_fd,"\r\n",2);}
  else if(deduct_report )                   { write(uart1_fd,"   ",3);printer_send(uart1_fd,labels[DEDUCT],strlen(labels[DEDUCT])); write(uart1_fd,"  ",2);write(uart1_fd,&labels[PAY_REPORT][7],strlen(&labels[PAY_REPORT][7])); PRINT_CR;}
  }

  if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
  //else printer_send(uart1_fd,"\r\n",2);
  t = time(NULL);
  tm = *localtime(&t);

  sprintf(temp_buf,"   %02d:%02d  %02d/%02d/%02d\r\n",tm.tm_hour,tm.tm_min,tm.tm_mday,tm.tm_mon+1,tm.tm_year-100);
  /*if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);*/ printer_send(uart1_fd,temp_buf,strlen(temp_buf));

  sprintf(temp_buf,"S:%02d/%02d/%02d E:%02d/%02d/%02d\n",start_day,start_month,start_year,end_day,end_month,end_year);

  if(regional && dpu_settings[5][10] == 'D') sprintf(temp_buf,"%s:%02d  %s:%02d\n",labels[S_START],start_day,labels[S_END],end_day);


  /*if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);*/ printer_send(uart1_fd,temp_buf,strlen(temp_buf));

  if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);


  sprintf(temp_buf,"/tmp/mmc/morning/%02d_%02d.dat",start_month,start_year);
  fd_s1 = fopen(temp_buf,"rb");
  printf("FILE:%s\n",temp_buf);
  sprintf(temp_buf,"/tmp/mmc/evening/%02d_%02d.dat",start_month,start_year);
  fd_s2 = fopen(temp_buf,"rb");
  fd_mm = fopen("/tmp/mmc/member.dat","rb");  //member data base
  usleep(600000);
  if(special_report) {start_id=0;end_id =2000;}
  if(display_en) end_id=start_id;
  for(i=0;i<150;i++)temp_buf[i]=0;


  if(deduct_report)
  {
      if(dpu_settings[5][10] == 'D')printer_send(uart1_fd,"---------------------\r\n",23);//print_page_no(1);
      if(regional==0)printer_send(uart1_fd,"  Date   SSN    DED. \r\n",23);
      else           {sprintf(temp_buf,"  %s   %s    %s \r\n",labels[DATE],labels[SESSION],labels[DEDUCT]);printer_send(uart1_fd,temp_buf,strlen(temp_buf));}
      if(dpu_settings[5][10] == 'D')printer_send(uart1_fd,"---------------------\r\n",23);//print_page_no(1);
  }


  hprint=0;
  while(start_id <= end_id)
  {
       memset(name,0,16);
       fseek(fd_mm,start_id*32,SEEK_SET);
       fread(name,16,1,fd_mm);
       i=0;while(i<16){if(name[i]=='_') {name[i]=0;break;}i++; }  name[i]=0;
       name[16]=0;
       printf("MID=%d, %s\n",start_id,name);
       //if(isalpha(name[0])) // valid name
       {


               lit =fat=snf=amt=deduct=ncount=0;

	       for(dt=start_day;dt<=end_day;dt++)   //get record for each day of both session
	       {
		    offset = (dt-1)*(2000*43) + (start_id*43);

		    if(fd_s1) //morning
		    {
		      fseek(fd_s1,offset,SEEK_SET);
		      fread(str_buf, 43,1,fd_s1); str_buf[42]=0;
		      if(isdigit(str_buf[0]))//((str_buf[0] >='0' && str_buf[0] <='9'))
		      {
		        printf("%s\n",str_buf);
			str_buf[15] = str_buf[20] = str_buf[25] = str_buf[34] = 0;

                        if(special_report && str_buf[6] == '0' && str_buf[7] == '0') str_buf[9] = 0;

                        if(isdigit(str_buf[9]))  // non-zero records
                        {
				if(ncount==0) // header line
				{


					if(dpu_settings[5][10] == 'T')
					{
                                                
                                                if(deduct_report==0){
						temp_buf[0] = 0x1B;temp_buf[1] = 0x21;temp_buf[2] = 0x01; //small font
						write(uart1_fd,temp_buf,3);
						usleep(30000);
						if(ws_mode==0)
						{
						     if(fat_only==0)printer_send(uart1_fd,"  Date   SSN  LT    FAT  SNF    AMT  \r\n",39);
                                                     else           printer_send(uart1_fd,"  Date   SSN  LT    FAT    AMT  \r\n",34);
                                                 }
                                                 else
                                                 {
 						     if(fat_only==0)printer_send(uart1_fd,"  Date   SSN  KG    FAT  SNF    AMT  \r\n",39);
                                                     else           printer_send(uart1_fd,"  Date   SSN  KG    FAT    AMT  \r\n",34);                                                
                                                 }
                                                 
						}
                                                else {
						//printer_send(uart1_fd,"  Date   SSN    DED. \r\n",25);
						}

						//sprintf(temp_buf,"%04d %s\r\n",start_id,name);
						//printer_send(uart1_fd,temp_buf,strlen(temp_buf));
                        //usleep(600000);
					}
					else
					{
                                               
                                               if(deduct_report==0){

                                               if(regional==0){
                                                   //printer_send(uart1_fd,"----------------------------------------------------\r\n",54);//print_page_no(1);
                                                   PRINT_TB1;print_seperator(52);
                                                   PRINT_CR;
                                                   if(ws_mode==0)
                                                   {
                                                   if(fat_only==0)printer_send(uart1_fd,"   Date   | SSN |  LIT  |  FAT  |  SNF  |  AMOUNT   |\r\n",55);
                                                   else           printer_send(uart1_fd,"   Date   | SSN |  LIT  |  FAT  |  AMOUNT   |\r\n",47);
                                                   }
                                                   else
                                                   {
                                                   if(fat_only==0)printer_send(uart1_fd,"   Date   | SSN |  KG   |  FAT  |  SNF  |  AMOUNT   |\r\n",55);
                                                   else           printer_send(uart1_fd,"   Date   | SSN |  KG   |  FAT  |  AMOUNT   |\r\n",47);                                                   
                                                   }
                                                   
                                                   //printer_send(uart1_fd,"----------------------------------------------------\r\n",54);//===print_page_no(1);
                                                   PRINT_TB1;print_seperator(52);
                                                   PRINT_CR;
                                                   for(i=0;i<127;i++){
                                                       temp_buf[i]=0;
                                                   }
                                               }
                                               else
                                               {
                                                    enable_regional();
                                                    if(fat_only==0)sprintf(temp_buf,"   %s   |  %s |  %s |  %s  |%s|    %s   |\r\n",labels[DATE],labels[SS],labels[LITER],labels[FAT],labels[SNF],labels[AMOUNT]);
                                                    else          sprintf(temp_buf,"   %s   |  %s |  %s |  %s  |    %s   |\r\n",labels[DATE],labels[SS],labels[LITER],labels[FAT],labels[AMOUNT]);}
                                                    if(regional !=0){
                                                    PRINT_TB1;print_seperator(strlen(temp_buf)-7);
                                                    PRINT_CR;
                                                    printer_send(uart1_fd,temp_buf,strlen(temp_buf));
                                                    PRINT_TB1;print_seperator(strlen(temp_buf)-7);
                                                    PRINT_CR;
                                                    }
                                                    //--exit_regional();
                                               }
                                               else
                                               {
                                                  /*if(atof(&str_buf[35])>0){
                                                  printer_send(uart1_fd,"----------------------\r\n",24);//print_page_no(1);
					                              if(regional==0)printer_send(uart1_fd,"  Date   SSN    DED. \r\n",23);
					                              else           {sprintf(temp_buf,"  %s   %s    %s \r\n",labels[DATE],labels[SESSION],labels[DEDUCT]);printer_send(uart1_fd,temp_buf,strlen(temp_buf));}
					                              printer_send(uart1_fd,"----------------------\r\n",24);//print_page_no(1);
					                              }*/
                                               }
                                               //===print_page_no(1);



                                               //PRINT_TB1;

					}
			       if(regional==0)sprintf(temp_buf," Mem = %04d %s\r\n",start_id,name);
			       else           sprintf(temp_buf," %s = %04d %s\r\n",labels[MEM_NO],start_id,name);
			       strcpy(hbuf,temp_buf);

			       if(deduct_report==0)printer_send(uart1_fd,temp_buf,strlen(temp_buf));
	               usleep(100000);
				}


			  lit   +=atof(&str_buf[9]);
			  fat   +=atof(&str_buf[16]);
			  snf   +=atof(&str_buf[21]);
			  amt   +=atof(&str_buf[26]);
                          deduct += atof(&str_buf[35]);
 		          temp_buf[0]=0;		
                          if(dpu_settings[5][10] == 'T') {
                           if(deduct_report==0){ 
 				if(fat_only==0) sprintf(temp_buf,"  %02d/%02d/%02d M %6.2f %4.1f %4.1f %7.2f\r\n",dt,start_month,start_year,atof(&str_buf[9]),atof(&str_buf[16]),atof(&str_buf[21]),atof(&str_buf[26]));
                                else sprintf(temp_buf,"  %02d/%02d/%02d M %6.2f %4.1f %7.2f\r\n",dt,start_month,start_year,atof(&str_buf[9]),atof(&str_buf[16]),atof(&str_buf[26])); 
                                printer_send(uart1_fd,temp_buf,strlen(temp_buf));
                                usleep(200000);
                           }

                           else if(atof(&str_buf[35])>0) { if(hprint==0){printer_send(uart1_fd,hbuf,strlen(hbuf));hprint=1;}sprintf(temp_buf," %02d/%02d/%02d M  %7.2f\r\n",dt,start_month,start_year,atof(&str_buf[35]));
                          printer_send(uart1_fd,temp_buf,strlen(temp_buf));
                          usleep(90000);
                          }
                          }
                          else{  //dot matrix
                          temp_buf[0]=0; 

                          if(deduct_report==0){ 
		                      if(fat_only==0) sprintf(temp_buf," %02d/%02d/%02d |  M  | %6.2f |  %4.1f |  %4.1f |  %7.2f  |\r\n",dt,start_month,start_year,atof(&str_buf[9]),atof(&str_buf[16]),atof(&str_buf[21]),atof(&str_buf[26]));
		                      else            sprintf(temp_buf," %02d/%02d/%02d |  M  | %6.2f |  %4.1f |  %7.2f  |\r\n",dt,start_month,start_year,atof(&str_buf[9]),atof(&str_buf[16]),atof(&str_buf[26]));

		                      printer_send(uart1_fd,temp_buf,strlen(temp_buf));
                          }
                          else if(atof(&str_buf[35])>0) { if(hprint==0){printer_send(uart1_fd,hbuf,strlen(hbuf));hprint=1;}sprintf(temp_buf," %02d/%02d/%02d M  %7.2f\r\n",dt,start_month,start_year,atof(&str_buf[35]));
                          printer_send(uart1_fd,temp_buf,strlen(temp_buf));
                          }
                          usleep(40000);
                          }
		                  ncount++;

                        }
		      }

		    }
                    
		    if(fd_s2)//evening
		    {
                     memset(str_buf,0,43);
		     fseek(fd_s2,offset,SEEK_SET);
		     fread(str_buf, 43,1,fd_s2); str_buf[42]=0;
		     if(isdigit(str_buf[0]))    //((str_buf[0] >='0' && str_buf[0] <='9'))
		     {
		        printf("%s\n",str_buf);
			str_buf[15] = str_buf[20] = str_buf[25] = str_buf[34] = '0';
			if(special_report && str_buf[6] == '0' && str_buf[7] == '0') str_buf[9] = 0;

                        if(isdigit(str_buf[9]))  //non-zero records
                        {
				if(ncount==0)
				{
					if(dpu_settings[5][10] == 'T')
					{
                                                if(deduct_report==0){
						temp_buf[0] = 0x1B;temp_buf[1] = 0x21;temp_buf[2] = 0x01; //small font
						write(uart1_fd,temp_buf,3);
						usleep(30000);
						if(ws_mode==0)
						{
						 if(fat_only==0)printer_send(uart1_fd,"  Date   SSN  LT    FAT  SNF    AMT  \r\n",39);
                                                 else           printer_send(uart1_fd,"  Date   SSN  LT    FAT    AMT  \r\n",34);
						}
						else{
						 if(fat_only==0)printer_send(uart1_fd,"  Date   SSN  KG    FAT  SNF    AMT  \r\n",39);
                                                 else           printer_send(uart1_fd,"  Date   SSN  KG    FAT    AMT  \r\n",34);						
						}
						}
                                                else {
						 //printer_send(uart1_fd,"  Date   SSN     DED \r\n",23);
						}

						//sprintf(temp_buf,"%04d %s\r\n",start_id,name);
						//printer_send(uart1_fd,temp_buf,strlen(temp_buf));
                        //usleep(100000);
					}
					else//dot matrix printer
					{
                                               

						   if(deduct_report==0){

 					       if(regional==0){	
 					       PRINT_TB1;print_seperator(52);PRINT_CR;//printer_send(uart1_fd,"----------------------------------------------------\r\n",54);//===print_page_no(1);
					       if(ws_mode==0)
					       {
					       if(fat_only==0)printer_send(uart1_fd,"   Date   | SSN |  LIT  |  FAT  |  SNF  |  AMOUNT   |\r\n",55);
                                               else           printer_send(uart1_fd,"   Date   | SSN |  LIT  |  FAT  |  AMOUNT   |\r\n",47); 
                                               }
                                               else
                                               {
                                               if(fat_only==0)printer_send(uart1_fd,"   Date   | SSN |  KG   |  FAT  |  SNF  |  AMOUNT   |\r\n",55);
                                               else           printer_send(uart1_fd,"   Date   | SSN |  KG   |  FAT  |  AMOUNT   |\r\n",47); 
                                               }
                                               PRINT_TB1;print_seperator(52);PRINT_CR;//printer_send(uart1_fd,"----------------------------------------------------\r\n",54);//===print_page_no(1);
                                               for(i=0;i<127;i++)temp_buf[i]=0;
                                               }
                                               else
                                               {
 					                            enable_regional();	
					                            if(fat_only==0)sprintf(temp_buf,"   %s   |  %s |  %s |  %s  |%s|    %s   |\r\n",labels[DATE],labels[SS],labels[LITER],labels[FAT],labels[SNF],labels[AMOUNT]);
                                                else           sprintf(temp_buf,"   %s   |  %s |  %s |  %s  |    %s   |\r\n",labels[DATE],labels[SS],labels[LITER],labels[FAT],labels[AMOUNT]);

                                               PRINT_TB1;print_seperator(strlen(temp_buf)-7);PRINT_CR;
                                               printer_send(uart1_fd,temp_buf,strlen(temp_buf)); 
                                               PRINT_TB1;print_seperator(strlen(temp_buf)-7);PRINT_CR;
                                               //--exit_regional();
					       }

                           }
                           else
                           {
                              /*if(atof(&str_buf[35])>0){
                              printer_send(uart1_fd,"----------------------\r\n",24);
                              if(regional==0)printer_send(uart1_fd,"  Date   SSN    DED. \r\n",23);
                              else           {sprintf(temp_buf,"  %s   %s    %s \r\n",labels[DATE],labels[SESSION],labels[DEDUCT]);printer_send(uart1_fd,temp_buf,strlen(temp_buf));}
                              printer_send(uart1_fd,"----------------------\r\n",24);
                              }*/
                           }



					}
                   if(regional==0)sprintf(temp_buf," Mem = %04d %s\r\n",start_id,name);
			       else           sprintf(temp_buf," %s = %04d %s\r\n",labels[MEM_NO],start_id,name);
			       strcpy(hbuf,temp_buf);   
			       if(deduct_report==0)printer_send(uart1_fd,temp_buf,strlen(temp_buf));
                                       usleep(100000);


				}

			  lit   +=atof(&str_buf[9]);
			  fat   +=atof(&str_buf[16]);
			  snf   +=atof(&str_buf[21]);
			  amt   +=atof(&str_buf[26]);
                          deduct += atof(&str_buf[35]);
			  temp_buf[0]=0;
                          if(dpu_settings[5][10] == 'T') {

                            if(deduct_report==0){
                              if(fat_only==0)    sprintf(temp_buf,"  %02d/%02d/%02d E %6.2f %4.1f %4.1f %7.2f\r\n",dt,start_month,start_year,atof(&str_buf[9]),atof(&str_buf[16]),atof(&str_buf[21]),atof(&str_buf[26]));
                              else               sprintf(temp_buf,"  %02d/%02d/%02d E %6.2f %4.1f %7.2f\r\n",dt,start_month,start_year,atof(&str_buf[9]),atof(&str_buf[16]),atof(&str_buf[26]));
                              printer_send(uart1_fd,temp_buf,strlen(temp_buf));
                              usleep(200000);
                            }
                            else if(atof(&str_buf[35])>0)  {if(hprint==0){printer_send(uart1_fd,hbuf,strlen(hbuf));hprint=1;} sprintf(temp_buf," %02d/%02d/%02d E  %7.2f\r\n",dt,start_month,start_year,atof(&str_buf[35]));
                            printer_send(uart1_fd,temp_buf,strlen(temp_buf));
                            usleep(90000);
                          }

                          }
                          else{ //dot matrix
                          temp_buf[0]=0;
                          if(deduct_report==0){
                          if(fat_only==0)sprintf(temp_buf," %02d/%02d/%02d |  E  | %6.2f |  %4.1f |  %4.1f |  %7.2f  |\r\n",dt,start_month,start_year,atof(&str_buf[9]),atof(&str_buf[16]),atof(&str_buf[21]),atof(&str_buf[26]));
                          else           sprintf(temp_buf," %02d/%02d/%02d |  E  | %6.2f |  %4.1f |  %7.2f  |\r\n",dt,start_month,start_year,atof(&str_buf[9]),atof(&str_buf[16]),atof(&str_buf[26]));
                          printer_send(uart1_fd,temp_buf,strlen(temp_buf));         
                          }
                          else if(atof(&str_buf[35])>0) {if(hprint==0){printer_send(uart1_fd,hbuf,strlen(hbuf));hprint=1;} sprintf(temp_buf," %02d/%02d/%02d E  %7.2f\r\n",dt,start_month,start_year,atof(&str_buf[35]));
                          printer_send(uart1_fd,temp_buf,strlen(temp_buf));
                          }
                          usleep(40000);

                          }
		          ncount++;
                        }
		     }

		    }
		    str_buf[0]=0;
		}//print total

                if(dpu_settings[5][10] == 'T' && ncount >0) {
		          temp_buf[0] = 0x1B;temp_buf[1] = 0x21;temp_buf[2] = 0x21; //large font
		          write(uart1_fd,temp_buf,3);
                  usleep(600000);
                }
                if(regional) enable_regional();
                if(ncount >0){
                if(dpu_settings[5][10] == 'D') 
                {  //PRINT_TB1;
                   if(deduct_report==0)printer_send(uart1_fd,"----------------------------------------------------\r\n",54);
                   else if(deduct>0) {printer_send(uart1_fd,"----------------------\r\n",24);}
                }

		        if(dpu_settings[5][10] == 'T' && deduct>0) printer_send(uart1_fd,"*********************\r\n",23);

                //===print_page_no(1); 
                if(deduct_report==0){
                    if(dpu_settings[5][10] == 'T') printer_send(uart1_fd,"*********************\r\n",23);
					if(regional==0)
					{
					 if (ws_mode==0)sprintf(temp_buf,"TOT LIT : %8.2lf\r\n",lit);
					 else           sprintf(temp_buf,"TOT KG  : %8.2lf\r\n",lit);
					}
					else { sprintf(temp_buf,"%s : %8.2lf\r\n",labels[TOT_LTR],lit);}

					if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"                        ",24); printer_send(uart1_fd,temp_buf,strlen(temp_buf));//===print_page_no(1);
					if(regional==0)sprintf(temp_buf,"TOT AMT : %8.2lf\r\n",amt);
					else            sprintf(temp_buf,"%s : %8.2lf\r\n",labels[TOT_AMT],amt);

					if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"                        ",24); printer_send(uart1_fd,temp_buf,strlen(temp_buf));//===print_page_no(1);
                }
                else if(deduct>0){
                        //PRINT_TB1;

                        hprint=0;
						if(regional==0) sprintf(temp_buf,"TOT DEDUCT:%8.2lf\r\n",deduct);
						else sprintf(temp_buf,"%s:%8.2lf\r\n",labels[TOT_DEDUCT],deduct);
						printer_send(uart1_fd,temp_buf,strlen(temp_buf));
						if(dpu_settings[5][10] == 'T') printer_send(uart1_fd,"*********************\r\n",23);
						else printer_send(uart1_fd,"---------------------\r\n",23);
                }

                }

        }
        /*
		  if(display_en) 
		  {
		    clear_lcd();
		    sprintf(temp_buf,"DS:%02d DE:%02d  %s",start_day,end_day,month_str[start_month-1]);
		    lcd_puts(0,0,temp_buf);
		    sprintf(temp_buf,"M:%4d L:%7.2F",start_id,lit);
		    lcd_puts(0,1,temp_buf);
		    sprintf(temp_buf,"Deduct:%8.2lf",deduct);
		    lcd_puts(0,2,temp_buf);
		    sprintf(temp_buf,"Rs:%8.2f N:%d",amt,ncount);
		    lcd_puts(0,3,temp_buf);
		    
		    update_lcd();
		    kbhit_wait();       
		    //close(uart1_fd);
		    //uart1_fd = open ("/dev/ttyATH0", O_RDWR | O_NOCTTY | O_SYNC);
		  }

		  */
           //---usleep(100000);
           start_id++;
  }
  deduct_report=0;
  special_report=0;  
  printer_send(uart1_fd,"\r\n\r\n\r\n\r\n",8);

  //sprintf(pbuf,"\r\n                               PAGE %d\r\n\r\n\r\n\r\n\r\n\r\n",print_page);
  if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,pbuf,strlen(pbuf));

  if(regional>0) exit_regional();

  if(display_en) 
  {
    clear_lcd();
    sprintf(temp_buf,"DS:%02d DE:%02d  %s",start_day,end_day,month_str[start_month-1]);
    lcd_puts(0,0,temp_buf);
    sprintf(temp_buf,"M:%4d %c:%7.2F",start_id-1,ws_text[ws_mode][0],lit);
    lcd_puts(0,1,temp_buf);
    sprintf(temp_buf,"Deduct:%8.2lf",deduct);
    lcd_puts(0,2,temp_buf);
    sprintf(temp_buf,"Rs:%8.2f N:%d",amt,ncount);
    lcd_puts(0,3,temp_buf);
    
    update_lcd();
    kbhit_wait();       
     close(uart1_fd);
     uart1_fd = open ("/dev/ttyS1", O_RDWR | O_NOCTTY | O_SYNC);
  }

  else sleep(3);
  
  //--set_interface_attribs (uart1_fd, B2400, 0);
  if(fd_s1) fclose(fd_s1);
  if(fd_s2) fclose(fd_s2);
  sleep(3);
#ifdef PCB_V1
  PT_OFF;
#endif
}
void print_bonus_report(int mid,unsigned char * from,unsigned char * to)
{
  FILE * fd_s1,* fd_s2,* fd_mm;

  int month,year,start,end,i,dt,ncount,ndays,flag;
  unsigned long offset;
  float lit;//,fat,snf,amt;
  double total_amt,bonus_total,bonus_amt;
  int start_day,start_month,start_year;
  int end_day,end_month,end_year;
  int tstart_day,tstart_month,tstart_year;
  if(print_en==0)return;
  char name[17];

  PT_ON;sleep(3);
  close(uart1_fd);     
  if(dpu_settings[5][10] == 'D'){ system("stty -F /dev/ttyS1 19200 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr "); }
  else                          { system("stty -F /dev/ttyS1 9600 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr "); }
  uart1_fd = open ("/dev/ttyS1", O_RDWR | O_NOCTTY | O_SYNC);     

  EN_PRINT;
  con=0;lcd_notify("[Printing...   ]",1);
  print_line=0;
  print_page=1;
  page_type = 2;

  memcpy(str_buf,from,8);str_buf[2]=str_buf[5]=str_buf[8]=0;        // start 01/05/15
  memcpy(&str_buf[16],to,8);str_buf[18]=str_buf[21]=str_buf[24]=0;  // end   01/05/16

  tstart_day = start_day = atoi(&str_buf[0]);
  end_day = atoi(&str_buf[16]);

  tstart_month = start_month = atoi(&str_buf[3]);
  end_month = atoi(&str_buf[19]);

  tstart_year = start_year = atoi(&str_buf[6]);
  end_year = atoi(&str_buf[22]);

  if(start_day > end_day || start_year > end_year)
  {
     clear_lcd();
     lcd_puts(0,1,"  INVALID DATE  ");
     update_lcd();
     usleep(2000000);
     return;
  }
  fd_mm = fopen("/tmp/mmc/member.dat","rb");  //member data base
  if(dpu_settings[5][10] == 'T'){
  name[0] = 0x1B;name[1] = 0x21;name[2] = 0x21;
  write(uart1_fd,name,3);
  }

  if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
  else printer_send(uart1_fd,"\r\n",2);
  i=0;
  memcpy(temp_buf,dpu_settings[0],16);while(i<16){if(temp_buf[i++]=='_')break;} temp_buf[i-1]=0;

  i = strlen(temp_buf); i = (21-i)/2;
  //--printer_send(uart1_fd,"                     ",i+1); // keep label in center
  //if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
  printer_send(uart1_fd,temp_buf,strlen(temp_buf));printer_send(uart1_fd,"\r\n",2);

  if(regional>0)enable_regional();
 
 //printer_send(uart1_fd,"CHIKHODRA            \r\n",23);
  if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
  else printer_send(uart1_fd,"\r\n",2);
  //if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); 

  if(regional==0)printer_send(uart1_fd,"BONUS   REPORT    \r\n",20);
  else  { printer_send(uart1_fd,labels[B_REPORT],strlen(labels[B_REPORT]));printer_send(uart1_fd,"\r\n",2);}        

  if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
  //else printer_send(uart1_fd,"\r\n",2);
  if(regional==0)sprintf(temp_buf,"BONUS %% :%5.2f\r\n",bonus);
  else sprintf(temp_buf,"%s %% :%5.2f\r\n",labels[BONUS],bonus);

  //if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); 
  printer_send(uart1_fd,temp_buf,strlen(temp_buf));
  if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
  //else printer_send(uart1_fd,"\r\n",2);

  if(regional==0)sprintf(temp_buf,"S:%02d/%02d/%02d E:%02d/%02d/%02d\r\n",start_day,start_month,start_year,end_day,end_month,end_year);
  else sprintf(temp_buf,"%s: %02d/%02d/%02d %s: %02d/%02d/%02d\r\n",labels[S_START],start_day,start_month,start_year,labels[S_END],end_day,end_month,end_year); 

  //if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
   printer_send(uart1_fd,temp_buf,strlen(temp_buf));



  if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
  //else printer_send(uart1_fd,"\r\n",2);

  total_amt = 0;
  mid =0;
  bonus_total=bonus_amt=0;

  if(dpu_settings[5][10] == 'D'){

  if(regional==0){//printer_send(uart1_fd,"| MEM  | LTR  | DAYS |  AMOUNT  |  BONUS  |\r\n",45);
    if(ws_mode==0)strcpy(header_line,"| MEM  |      LTR    |  DAYS |    AMOUNT   |   BONUS    |\r\n");
    else          strcpy(header_line,"| MEM  |      KG     |  DAYS |    AMOUNT   |   BONUS    |\r\n"); 
    PRINT_TB2;print_seperator(strlen(header_line)-3);PRINT_CR;
    printer_send(uart1_fd,header_line,strlen(header_line));
    PRINT_TB2;print_seperator(strlen(header_line)-3);PRINT_CR;
  }
  else {
    sprintf(temp_buf,"| %s  |     %s    |  %s  |    %s   |    %s    |\r\n",labels[MEM_NO],labels[LITER],labels[DAYS],labels[AMOUNT],labels[BONUS]);
    strcpy(header_line,temp_buf);
    PRINT_TB2;print_seperator(strlen(header_line)-3);PRINT_CR;
    printer_send(uart1_fd,temp_buf,strlen(temp_buf));
    PRINT_TB2;print_seperator(strlen(header_line)-3);PRINT_CR;
  }

  }
  usleep(300000);
  while(mid<2000)
  {
          //02:00:00,003.50,07.1,08.6,00078.92
          start_day = tstart_day;
          start_month = tstart_month;
          start_year =  tstart_year;
          total_amt =0;
          lit = 0;
          ndays=0;
	  while(start_year <= end_year)
	  {
		  sprintf(temp_buf,"/tmp/mmc/morning/%02d_%02d.dat",start_month,start_year);
		  fd_s1 = fopen(temp_buf,"rb");
		  //printf("FILE:%s\n",temp_buf);
		  sprintf(temp_buf,"/tmp/mmc/evening/%02d_%02d.dat",start_month,start_year);
		  fd_s2 = fopen(temp_buf,"rb");
	 	  //printf("FILE:%s\n",temp_buf);

                  if(fd_s1>0 || fd_s2>0)
                  {
			  for(i=(start_day-1);i<=30;i++)
			  {
                            if( (start_year == end_year) && (start_month == end_month) && (i == (end_day))) break;
			    offset = i*(2000*43) + (mid*43);
                            flag =0;
                            str_buf[0]=0;
			    if(fd_s1)
			    {

			      fseek(fd_s1,offset,SEEK_SET);
			      fread(str_buf, 43,1,fd_s1); str_buf[34]=0;

			      if((str_buf[0] >='0' && str_buf[0] <='9'))
			      {
				printf("%s\n",str_buf);
				str_buf[15] = str_buf[20] = str_buf[25] = str_buf[34] = 0;
                                lit   +=atof(&str_buf[9]);
				total_amt   +=atof(&str_buf[26]);
                                flag=1;

			      }

			    }
                            str_buf[0]=0;
			    if(fd_s2)
			    {
			     fseek(fd_s2,offset,SEEK_SET);
			     fread(str_buf, 43,1,fd_s2); str_buf[34]=0;
			     if((str_buf[0] >='0' && str_buf[0] <='9'))
			     {
				printf("%s\n",str_buf);
				str_buf[15] = str_buf[20] = str_buf[25] = str_buf[34] = 0;
                                lit   +=atof(&str_buf[9]);
				total_amt   +=atof(&str_buf[26]);
                                flag=1;

			     }

			    }
                            if(flag) ndays++;



			  }

                  }

		  if(fd_s1) fclose(fd_s1);
		  if(fd_s2) fclose(fd_s2);
		   if( (start_year == end_year) && (start_month == end_month)  && (i == (end_day-1))) break;
		  start_day = 1;
		  start_month++;
		  if(start_month >12)
		  {
		     start_month =1;start_year++;
		  }


            }

            if(total_amt)
            {
	       memset(name,0,16);
	       fseek(fd_mm,mid*32,SEEK_SET);
	       fread(name,16,1,fd_mm);   name[16]=0;
               //
               i=0;while(i<16){if(name[i]=='_') {name[i]=0;break;}i++; } name[i]=0;


               puts(name);
	       printf("Total Amount: % 11.2lf\n",total_amt);
               if(dpu_settings[5][10] == 'T'){

	       sprintf(temp_buf,"%04d:%s\r\n",mid,name);    //id name
	       printer_send(uart1_fd,temp_buf,strlen(temp_buf));//123456.87

	       sprintf(temp_buf,"Days  :%03d\r\%s :%11.2lf\r\n",ndays,ws_text[ws_mode],lit);//mid,total_amt,(total_amt*bonus)/100);
	       printer_send(uart1_fd,temp_buf,strlen(temp_buf));

	       sprintf(temp_buf,"Amount:%11.2f\r\nBonus :%11.2f\r\n",total_amt,(total_amt*bonus)/100);//mid,total_amt,(total_amt*bonus)/100);
	       printer_send(uart1_fd,temp_buf,strlen(temp_buf));

	       printer_send(uart1_fd,"*********************\r\n",23);usleep(800000);
               }
               else // dot-matrix
               {

                   sprintf(temp_buf,"| %4d | %11.2f |  %3d  | %11.2f | %9.2f |\r\n",mid,lit,ndays,total_amt,(total_amt*bonus)/100);
                   printer_send(uart1_fd,temp_buf,strlen(temp_buf)); //===print_page_no(2);
                   usleep(100000);

               }
               bonus_total += total_amt;
               bonus_amt   += (total_amt*bonus)/100;
            }

            mid++;

  }

  if(dpu_settings[5][10] == 'D')printer_send(uart1_fd,"----------------------------------------------------------\r\n",61);
  else  printer_send(uart1_fd,"*********************\r\n",23);
  //===print_page_no(2);

  if(regional==0)sprintf(temp_buf,"TOTAL:%15.2lf\r\n",bonus_total);
  else           sprintf(temp_buf,"%s:%15.2lf\r\n",labels[AMOUNT],bonus_total); 

  if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); printer_send(uart1_fd,temp_buf,strlen(temp_buf)); //===print_page_no(2);
  if(regional==0)sprintf(temp_buf,"BONUS:%15.2lf\r\n\r\n\r\n\r\n\r\n",bonus_amt);
  else           sprintf(temp_buf,"%s:%15.2lf\r\n\r\n\r\n\r\n\r\n",labels[BONUS],bonus_amt); 

  if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); printer_send(uart1_fd,temp_buf,strlen(temp_buf)); //===print_page_no(2);
  if(fd_mm)fclose(fd_mm);
  sleep(1);
  exit_regional();
  //--set_interface_attribs (uart1_fd, B2400, 0);
  sleep(3);
#ifdef PCB_V1
  PT_OFF;
#endif
}
//F4
void print_payment_report(unsigned char * from,unsigned char * to)
{
  FILE * fd_s1,* fd_s2,* fd_mm;

  int month,year,start,end,i,dt,ncount;
  unsigned long offset;
  float lit,fat,snf,amt,deduct;
  double total_lit,total_amt,kg_fat,kg_snf,total_deduct;
  char name[17];
  
  PT_ON;sleep(3);
  
  if(print_en==0)return;
  exit_regional();
  
  
  close(uart1_fd);     
  if(dpu_settings[5][10] == 'D'){ system("stty -F /dev/ttyS1 19200 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr "); }
  else                          { system("stty -F /dev/ttyS1 9600 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr "); }

  uart1_fd = open ("/dev/ttyS1", O_RDWR | O_NOCTTY | O_SYNC);     

  memcpy(str_buf,from,8);str_buf[2]=str_buf[5]=str_buf[8]=0;
  memcpy(&str_buf[16],to,8);str_buf[18]=str_buf[21]=str_buf[24]=0;
  EN_PRINT;
  
  
  print_line=0;
  print_page=1;
  page_type = 3;
  
  print_where();
  
  if(display_en) 
  {
     close(uart1_fd);
     uart1_fd  = open ("/dev/null", O_RDWR | O_NOCTTY | O_SYNC);  //redirect uart data to /dev/null
  }

  con=0;lcd_notify("[Printing...   ]",1); 

  start = atoi(&str_buf[0]);
  end = atoi(&str_buf[16]);
  printf("From:%d To:%d\n",start,end);
  month = atoi(&str_buf[3]);
  year = atoi(&str_buf[6]);
  if(atoi(&str_buf[3]) != atoi(&str_buf[19])  ||  atoi(&str_buf[6]) != atoi(&str_buf[22]) || start > end)
  {
     clear_lcd();
     lcd_puts(0,1,"  INVALID DATE  ");
     update_lcd();
     usleep(2000000);
     return;
  }

  sprintf(temp_buf,"/tmp/mmc/morning/%s_%s.dat",&str_buf[3],&str_buf[6]);
  fd_s1 = fopen(temp_buf,"rb");
  printf("FILE:%s\n",temp_buf);
  sprintf(temp_buf,"/tmp/mmc/evening/%s_%s.dat",&str_buf[19],&str_buf[22]);
  fd_s2 = fopen(temp_buf,"rb");

  printf("FILE:%s\n",temp_buf);
  fd_mm = fopen("/tmp/mmc/member.dat","rb");  //member data base


  if(dpu_settings[5][10] == 'T'){
  name[0] = 0x1B;name[1] = 0x21;name[2] = 0x21;
  write(uart1_fd,name,3);
  }

  if(regional>0) enable_regional();

  if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
  else printer_send(uart1_fd,"\r\n",2);
  i=0;
  memcpy(temp_buf,dpu_settings[0],16);while(i<16){if(temp_buf[i++]=='_')break;} temp_buf[i-1]=0;

  i = strlen(temp_buf); i = (21-i)/2;
  if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); printer_send(uart1_fd,"                     ",i+1); // keep label in center

  printer_send(uart1_fd,temp_buf,strlen(temp_buf));printer_send(uart1_fd,"\r\n",2);

  //printer_send(uart1_fd,"CHIKHODRA            \r\n",23);
  if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
  else printer_send(uart1_fd,"\r\n",2);
  if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
  if(regional==0) printer_send(uart1_fd,"   PAYMENT REPORT    \r\n",23);
  else  { printer_send(uart1_fd,"     ",5);printer_send(uart1_fd,labels[PAY_REPORT],strlen(labels[PAY_REPORT]));printer_send(uart1_fd,"\r\n",2);} 
  if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
  else printer_send(uart1_fd,"\r\n",2);

  system_call("date -R --rfc-2822",temp_buf);
  system_call("date -I",temp_buf);
  temp_buf[4] =0;temp_buf[7] =0;temp_buf[10] =0;temp_buf[22] =0;

  sprintf(str_buf,"   %s  %s/%s/%s\r\n",&temp_buf[17],&temp_buf[8],&temp_buf[5],&temp_buf[2]);
  if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); printer_send(uart1_fd,str_buf,strlen(str_buf));  //printer_send(uart1_fd,"     HH:MM  DD/MM/YY    \r\n",25);

  if(dpu_settings[5][10] == 'T') sprintf(temp_buf,"S:%02d/%02d/%02d E:%02d/%02d/%02d\n",start,month,year,end,month,year);//sprintf(temp_buf,"   DS:%02d    DE:%02d\n",start,end);
  else if(regional ==0)sprintf(temp_buf,"Date = %02d/%02d/%02d to %02d/%02d/%02d\r\n",start,month,year,end,month,year);
  else                 sprintf(temp_buf,"%s = %02d/%02d/%02d to %02d/%02d/%02d\r\n",labels[DATE],start,month,year,end,month,year);     
  
  if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); printer_send(uart1_fd,temp_buf,strlen(temp_buf));
  if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"--------------------------------------------------------------------------------\r\n",82);

  
  if(ws_mode==0)
  {
        if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"   LT   |SN|     AMT \r\n",23);
        else if(regional==0){printer_send(uart1_fd,"  MEM|       NAME     |   LTRS  | SSN|  AMOUNT  | DEDUCT |  NET AMT | SIGN\r\n",76); 
         strcpy(header_line,"  MEM|       NAME     |   LTRS  | SSN|  AMOUNT  | DEDUCT |  NET AMT | SIGN\r\n");
        }
        else   { sprintf(temp_buf,"| %s |         %s        |    %s    | %s |     %s    |   %s   |  %s | %s\r\n",labels[MEM_NO],labels[NAME],labels[LITER],labels[SESSION],labels[AMOUNT],labels[DEDUCT],labels[NET_AMOUNT],labels[SIGN]);
                 printer_send(uart1_fd,temp_buf,strlen(temp_buf));
                 strcpy(header_line,temp_buf);
        }
  }
  else
  {
        if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"   KG   |SN|     AMT \r\n",23);
        else if(regional==0){printer_send(uart1_fd,"  MEM|       NAME     |   KGs   | SSN|  AMOUNT  | DEDUCT |  NET AMT | SIGN\r\n",76); 
         strcpy(header_line,"  MEM|       NAME     |   KGs   | SSN|  AMOUNT  | DEDUCT |  NET AMT | SIGN\r\n");
        }
        else   { sprintf(temp_buf,"| %s |         %s        |    %s    | %s |     %s    |   %s   |  %s | %s\r\n",labels[MEM_NO],labels[NAME],labels[LITER],labels[SESSION],labels[AMOUNT],labels[DEDUCT],labels[NET_AMOUNT],labels[SIGN]);
                 printer_send(uart1_fd,temp_buf,strlen(temp_buf));
                 strcpy(header_line,temp_buf);
        }  
  }
  
  
  if(regional>0)exit_regional();

  usleep(400000);
  total_lit=total_amt=total_deduct=0;
  for(i=0;i<2000;i++)       // scan for each active members
  {
    memset(name,0,16);
	fseek(fd_mm,i*32,SEEK_SET);
	fread(name,16,1,fd_mm);   name[16]=0;

        //if( (name[0] >='0' && name[0] <='9') || (name[0] >='A' && name[0] <='Z')) //valid name
        {
           dt=0;
           while(dt<16){if(name[dt]=='_') {name[dt]=0;break;}dt++; }
           name[dt]=0;

           lit =fat=snf=amt=ncount=deduct=0;//=kg_fat=kg_snf=0;
           for(dt=start;dt<=end;dt++)   //get record for each day of both session for a member
           {
            offset = (dt-1)*(2000*43) + (i*43);
            if(fd_s1)
            {

              fseek(fd_s1,offset,SEEK_SET);
              fread(str_buf, 43,1,fd_s1); str_buf[43]=0;
              if((str_buf[0] >='0' && str_buf[0] <='9'))
              {
                printf("%s\n",str_buf);
		str_buf[15] = str_buf[20] = str_buf[25] = str_buf[34] = str_buf[42] = 0;
                if(isdigit(str_buf[9]))//digit only
                {
		   lit   +=atof(&str_buf[9]);
		   fat   +=atof(&str_buf[16]);
		   snf   +=atof(&str_buf[21]);
		   amt   +=atof(&str_buf[26]);
                   deduct += atof(&str_buf[35]);
                   //kg_fat += (lit*fat);
                   //kg_snf += (lit*snf);
                   ncount++;
                }
              }

            }

            if(fd_s2)
            {
             memset(str_buf,0,43);
             fseek(fd_s2,offset,SEEK_SET);
             fread(str_buf, 43,1,fd_s2); str_buf[43]=0;
             if((str_buf[0] >='0' && str_buf[0] <='9'))
             {
                printf("%s\n",str_buf);
		str_buf[15] = str_buf[20] = str_buf[25] = str_buf[34] = 0;
                if(isdigit(str_buf[9]))
                {
		  lit   +=atof(&str_buf[9]);
		  fat   +=atof(&str_buf[16]);
		  snf   +=atof(&str_buf[21]);
		  amt   +=atof(&str_buf[26]);
                  deduct += atof(&str_buf[35]);
                  //kg_fat += (lit*fat);
                  //kg_snf += (lit*snf);
                  ncount++;
                }
             }

            }
            str_buf[0]=0;
           }
           //amt -= deduct;
           total_deduct +=deduct;
           total_lit += lit;
           //total_fat += fat;
           //total_snf += snf;
           total_amt += amt;

           if(ncount >0)
           {
		   //printf("MID=%d % 7.2f % 7.2f % 7.2f % 7.2f\n",i,lit,(kg_fat/lit),(kg_snf/lit),amt);
                   if(dpu_settings[5][10] == 'T'){
		   printer_send(uart1_fd,"*********************\r\n",23);
                   sprintf(temp_buf,"%4d:%s\r\n",i,name);
		   printer_send(uart1_fd,temp_buf,strlen(temp_buf));

                   sprintf(temp_buf,"%7.2f |%2d| %8.2f\r\n",lit,ncount,amt);//sprintf(temp_buf,"\r\n%03d|%6.1f|%02d|%7.2f\r\n",i,lit,ncount,amt);
		   printer_send(uart1_fd,temp_buf,strlen(temp_buf));

                   sprintf(temp_buf,"Deduct:%7.2f\r\n",deduct);
		   printer_send(uart1_fd,temp_buf,strlen(temp_buf));

                   sprintf(temp_buf,"NetAmt:%8.2f\r\n",amt-deduct);
		   printer_send(uart1_fd,temp_buf,strlen(temp_buf));

                   usleep(800000);// 10ms wait



                   }
                   else
                   {
		            printer_send(uart1_fd,"--------------------------------------------------------------------------------\r\n",82);//===print_page_no(3);
                   //sprintf(temp_buf,"%s\r\n",name);
		   //printer_send(uart1_fd,temp_buf,strlen(temp_buf));//===print_page_no(3);
                   //usleep(30000);
                   sprintf(temp_buf," %4d|%-16s| %7.2f | %2d | %8.2f |%7.2f | %8.2f |\r\n",i,name,lit,ncount,amt,deduct,amt-deduct);
                   //exit_regional();
                   //printer_send(uart1_fd,temp_buf,22);
                   //enable_regional();
                   //printer_send(uart1_fd,&temp_buf[22],strlen(temp_buf)-22);//===print_page_no(3);
		   printer_send(uart1_fd,temp_buf,strlen(temp_buf));//===print_page_no(3);
                   usleep(30000);
                   }
           }


        }
        //if(dpu_settings[5][10] == 'T')usleep(400000);
  }
  if(regional>0) enable_regional();

  if(dpu_settings[5][10] == 'T') printer_send(uart1_fd,"*********************\r\n",23);
  else  printer_send(uart1_fd,"--------------------------------------------------------------------------------\r\n",82);//===print_page_no(3);
  //===print_page_no(3);
   usleep(400000);
  if(regional==0)
  { 
    if(ws_mode==0) sprintf(temp_buf,"TOT LIT : %8.2lf\r\n",total_lit); 
    else           sprintf(temp_buf,"TOT KG  : %8.2lf\r\n",total_lit); 
  }
  else           sprintf(temp_buf,"%s : %8.2lf\r\n",labels[TOT_LTR],total_lit);
   usleep(300000);
  if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); printer_send(uart1_fd,temp_buf,strlen(temp_buf)); //===print_page_no(3);

  if(regional==0)sprintf(temp_buf,"TOT AMT : %8.2lf\r\n",total_amt);
  else           sprintf(temp_buf,"%s : %8.2lf\r\n",labels[TOT_AMT],total_amt);
  usleep(400000);
  if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); printer_send(uart1_fd,temp_buf,strlen(temp_buf)); //===print_page_no(3);

  if(regional==0)sprintf(temp_buf,"DEDUCT  : %8.2lf\r\n",total_deduct);
  else           sprintf(temp_buf,"%s  : %8.2lf\r\n",labels[DEDUCT],total_deduct); 
  if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); printer_send(uart1_fd,temp_buf,strlen(temp_buf));//===print_page_no(3);
  usleep(400000);
  if(regional==0)sprintf(temp_buf,"NET AMT : %8.2lf\r\n\r\n\r\n\r\n\r\n",total_amt-total_deduct);
  else           sprintf(temp_buf,"%s : %8.2lf\r\n\r\n\r\n\r\n\r\n",labels[NET_AMOUNT],total_amt-total_deduct);



  if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); printer_send(uart1_fd,temp_buf,strlen(temp_buf)); //===print_page_no(3);
  usleep(400000);
  if(display_en)
  {
    
    clear_lcd();
    sprintf(temp_buf,"DS:%02d DE:%02d  %s",start,end,month_str[month-1]);
    lcd_puts(0,0,temp_buf);
    if(ws_mode==0) sprintf(temp_buf,"Ltr:%7.2f",total_lit);
    else           sprintf(temp_buf,"Kg :%7.2f",total_lit);
    lcd_puts(0,1,temp_buf);
    sprintf(temp_buf,"Deduct:%8.2f",total_deduct);
    lcd_puts(0,2,temp_buf);
    sprintf(temp_buf,"Rs:%8.2f",total_amt);
    lcd_puts(0,3,temp_buf);
    
    update_lcd();
    kbhit_wait();  
    close(uart1_fd);
    uart1_fd = open ("/dev/ttyS1", O_RDWR | O_NOCTTY | O_SYNC);
    //---display_en=0;  
  }
  else sleep(1);
  if(regional>0) exit_regional();


  if(fd_s1) fclose(fd_s1);

  if(fd_s2) fclose(fd_s2);

  fclose(fd_mm);
  sleep(3);
#ifdef PCB_V1
  PT_OFF;
#endif
  //--set_interface_attribs (uart1_fd, B2400, 0);
}
/*
2015-07-15
Sun, 05 Jul 2015 12:30:39 +0000
10:21:12,055.55,08.5,08.6,01369.31n
*/

void tfont_small()
{
    temp_buf[0] = 0x1B;temp_buf[1] = 0x21;temp_buf[2] = 0x01; //large font
	 write(uart1_fd,temp_buf,3);
	 usleep(30000);

}
void tfont_big()
{
    temp_buf[0] = 0x1B;temp_buf[1] = 0x21;temp_buf[2] = 0x21; //large font
	 write(uart1_fd,temp_buf,3);
	 usleep(30000);

}
void print_session_report( int mode,int session,int type)
{
   unsigned char buf[50];
   char tx_buf[100];
   char str_buf1[100];
   char dirty[4];
   char sc,type_bc;
   char name[17];
   int n,id,nrec,dt,mt,yr,i,id_max,mid;
   float total_lit,avg_fat,avg_snf,amt,kg_fat,kg_snf,lit,rl,amount,fat,snf;
   unsigned long offset;
   int fusb;
   FILE *fd_mm;
   FILE *fsort;
   char xprint_en;
   //puts(dpu_settings[0]);
   if(display_en) {xprint_en = print_en; print_en=0;}
   system("rm /tmp/print");//remove old print file
   system("rm /tmp/tprint");//remove old print file
  close(uart1_fd);     
  if(dpu_settings[5][10] == 'D'){ system("stty -F /dev/ttyS1 19200 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr "); }
  else                          { system("stty -F /dev/ttyS1 9600 min 0 time 5 -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke -opost -onlcr "); }

  uart1_fd = open ("/dev/ttyS1", O_RDWR | O_NOCTTY | O_SYNC);     
   PT_ON;sleep(3);
  // EN_PRINT;
   if(dpu_settings[6][8]=='N')
   {
     print_line=0;
     print_page=1;
   }
   else if((dpu_settings[6][8]=='Y'||dpu_settings[6][8]=='S') && type==0) 
   {
     print_line=0;
     print_page=1;
   }
   page_type = 4;

   fd_mm = fopen("/tmp/mmc/member.dat","rb");  //member data base

   puts("Printing..\r\n");

   con=0;
   if(print_opt==2)lcd_puts(1,2,"Sending Data...");
   if(fstate >SAVE_SESSION)
   {
     lcd_notify("[Saving To USB ]",1);
   }
   else
   {
     lcd_notify("[Printing...   ]",1);
   }

   str_buf[2]=str_buf[5]=str_buf[8]=0;
   dt = atoi(str_buf);
   mt = atoi(&str_buf[3]);
   yr = atoi(&str_buf[6]);


   if(session==1)
   {
       #ifdef PROJ_MAHI
       sprintf(buf,"echo \"1\" >  /tmp/mmc/M%d.mloc",dt);
       system(buf);//make file for this session
       #endif
       sprintf(buf,"//tmp/mmc//morning//%s_%s.dat",&str_buf[3],&str_buf[6]);
   }
   else
   {
       #ifdef PROJ_MAHI
       sprintf(buf,"echo \"2\" >  /tmp/mmc/E%d.eloc",dt);
       system(buf);//make file for this session
       #endif

       sprintf(buf,"//tmp/mmc//evening//%s_%s.dat",&str_buf[3],&str_buf[6]);
   }
   printf("FILE:%s\n",buf);
   FILE *file = fopen(buf, "rb");
   
   if(file<=0) {update_lcd();return;}
   if(print_en)
   {
           if(regional>0)enable_regional();
	   if(dpu_settings[5][10] == 'T')
	   {
		   tx_buf[0] = 0x1B;tx_buf[1] = 0x21;tx_buf[2] = 0x21;
		   write(uart1_fd,tx_buf,3);
	   }
	   if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
	   else printer_send(uart1_fd,"\r\n",2);

	   i=0;
	   memcpy(temp_buf,dpu_settings[0],16);while(i<16){if(temp_buf[i++]=='_')break;} temp_buf[i-1]=0;

	   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);

	   i = strlen(temp_buf); i = (21-i)/2;
	   printer_send(uart1_fd,"                     ",i+1); // keep label in center

	   printer_send(uart1_fd,temp_buf,strlen(temp_buf));printer_send(uart1_fd,"\r\n",2);

	   if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
	   else printer_send(uart1_fd,"\r\n",2);
	   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);

       if(regional==0){
		   if(mode==1)
		   printer_send(uart1_fd,"   SESSION  REPORT   ",21);
		   else if(union_index<1)
		   printer_send(uart1_fd,"  SESSION   SUMMARY  ",21);
           else
           printer_send(uart1_fd,"   DAIRY  REGISTER   ",21);
       }
       else
       {
           printer_send(uart1_fd,"     ",5);
		   if(mode==1)
		   printer_send(uart1_fd,labels[SS_REPORT],strlen(labels[SS_REPORT]));
		   else if(union_index<1)
		   printer_send(uart1_fd,labels[S_SUMMARY],strlen(labels[S_SUMMARY]));
           else//DREPORT
           printer_send(uart1_fd,labels[DREPORT],strlen(labels[DREPORT]));
           //printer_send(uart1_fd,"\r\n",2);
       } 
       if(dpu_settings[5][10] == 'D'){
           if(mode !=1) {PRINT_CR;}
           printer_send(uart1_fd,"        ",8); sprintf(tx_buf,"       %s/%s/%s\r\n",&str_buf[0],&str_buf[3],&str_buf[6]);
       }
       else
       {
          sprintf(tx_buf,"       %s/%s/%s\r\n",&str_buf[0],&str_buf[3],&str_buf[6]);
       }




	   if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
	   else{printer_send(uart1_fd,tx_buf,strlen(tx_buf));}
      }

	   id=0;
	   id_max=1000;

	   if(dpu_settings[6][8]=='Y'||dpu_settings[6][8]=='S')//if ENABLED BUFFALO/COW
	   {
	      if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
	      if(type==0)
	      {
		if(print_en){ if(regional==0)printer_send(uart1_fd,"       BUFFALO\r\n",16);else{PRINT_SP;printer_send(uart1_fd,labels[BUF],strlen(labels[BUF]));PRINT_CR;}}
		id = 0;
		id_max=1000;
        type_bc='B';
	      }
	      else
	      {
		if(print_en){ if(regional==0)printer_send(uart1_fd,"         COW  \r\n",16);else{PRINT_SP;printer_send(uart1_fd,labels[COW],strlen(labels[BUF]));PRINT_CR;}}
		id = 1000;
		id_max=2000;
        type_bc = 'C';
	      }
              

	   }

   fusb=0;
   if(access( "/dev/sda", F_OK ) != -1)
   {
	flag_scan=0;

	system("mount /dev/sda1 /tmp/usb");//CODE:
        dpu_settings[1][9]=0;
    system_cmd("mkdir /tmp/usb/session",scode,"","",""); 
        if(session==1)
	sprintf(temp_buf,"/tmp/usb/session%s/%s%s%s_mor_%s.csv",scode,&str_buf[0],&str_buf[3],&str_buf[6],&dpu_settings[1][5]);
        else
        sprintf(temp_buf,"/tmp/usb/session%s/%s%s%s_eve_%s.csv",scode,&str_buf[0],&str_buf[3],&str_buf[6],&dpu_settings[1][5]);

        if (type ==0 )
        fusb = open(temp_buf,O_WRONLY | O_CREAT |O_TRUNC, 0666);   //MIX / BUF
        else          fusb = open(temp_buf,O_WRONLY | O_APPEND, 0666); //COW

        if (type ==0 )
        {
          if(ws_mode==0) write(fusb,"Type,MemberID,Time,Liters,Fat,SNF,Rate/Lit,Amount,Name\n",55);
          else           write(fusb,"Type,MemberID,Time,Kgs   ,Fat,SNF,Rate/Lit,Amount,Name\n",55); 
        } 
   }
   if(print_en)
   {
	   //sprintf(tx_buf,"       %s/%s/%s\r\n",&str_buf[0],&str_buf[3],&str_buf[6]);
	   if(dpu_settings[5][10] == 'T')// printer_send(uart1_fd,"        ",8);
	   printer_send(uart1_fd,tx_buf,strlen(tx_buf));  //printer_send(uart1_fd,"     HH:MM  DD/MM/YY    \r\n",25);

	   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
	   if(session==1)
	   {
	      if(regional==0)printer_send(uart1_fd,"    M O R N I N G    \r\n",23);
              else{PRINT_SP;printer_send(uart1_fd,labels[MOR],strlen(labels[MOR]));PRINT_CR;}
              sc = 'M';
	   }
	   else
	   {
	      if(regional==0)printer_send(uart1_fd,"    E V E N I N G    \r\n",23);
              else{PRINT_SP;printer_send(uart1_fd,labels[EVE],strlen(labels[EVE]));PRINT_CR;} 
              sc = 'E';
	   }
	   if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
	   //else if(mode==1) printer_send(uart1_fd,"-------------------------------------------------\r\n",51);

	   if(mode==1)
	   {
	     if(dpu_settings[5][10] == 'T') 
	      {
	        if(ws_mode==0)
	        {
                  if(session_format==0) {if(fat_only==0)printer_send(uart1_fd,"MEM |FAT/LIT| SNF/AMT\r\n",23);else printer_send(uart1_fd,"MEM |FAT/LIT|  AMT   \r\n",23); puts("\r\nMEM |FAT/LIT| SNF/AMT\r\n");}
	          else{
	              tfont_small();
                  if(fat_only==0)printer_send(uart1_fd,"Time   Mem    Lit   Fat  Snf   Amount \r\n",40);
                  else           printer_send(uart1_fd,"Time   Mem    Lit   Fat        Amount \r\n",40);
	              tfont_big();
	            }
	         }
	         else
	         {
	                           if(session_format==0) {if(fat_only==0)printer_send(uart1_fd,"MEM |FAT/KG | SNF/AMT\r\n",23);else printer_send(uart1_fd,"MEM |FAT/KG |  AMT   \r\n",23); puts("\r\nMEM |FAT/KG | SNF/AMT\r\n");}
	          else{
	              tfont_small();
                  if(fat_only==0)printer_send(uart1_fd,"Time   Mem    Kg    Fat  Snf   Amount \r\n",40);
                  else           printer_send(uart1_fd,"Time   Mem    Kg    Fat        Amount \r\n",40);
	              tfont_big();
	            }
	         
	         
	         }
	            
	            
	      }
	     else{ 
               if(regional==0){
               if(fat_only==0){

                   if(ws_mode==0) strcpy(header_line,"| SR. |MEM |  LTRS  |  FAT  |  SNF  |   AMOUNT  |\r\n");
                   else           strcpy(header_line,"| SR. |MEM |  KGs   |  FAT  |  SNF  |   AMOUNT  |\r\n");
	                PRINT_TB3;print_seperator(strlen(header_line)-2);PRINT_CR;
	                PRINT_TB3;printer_send(uart1_fd,header_line,strlen(header_line));
	                PRINT_TB3;print_seperator(strlen(header_line)-2);PRINT_CR;
                }
	             else { 
	                if(ws_mode==0) strcpy(header_line,"| SR. |MEM |  LTRS  |  FAT  |   AMOUNT  |\r\n");
	                else           strcpy(header_line,"| SR. |MEM |  KGs   |  FAT  |   AMOUNT  |\r\n");
	                PRINT_TB3;print_seperator(strlen(header_line)-2);PRINT_CR;
	                PRINT_TB3;printer_send(uart1_fd,header_line,strlen(header_line));
	                PRINT_TB3;print_seperator(strlen(header_line)-2);PRINT_CR;
	             }
               }
               else
               {
                  if(fat_only==0)
                  {
                    sprintf(temp_buf,"| %s | %s|  %s |  %s  | %s |   %s   |\r\n",labels[SN],labels[MEM_NO],labels[LITER],labels[FAT],labels[SNF],labels[AMOUNT]);
                  }
                  else 
                  {
                    sprintf(temp_buf,"| %s | %s|  %s |  %s  |    %s   |\r\n",labels[SN],labels[MEM_NO],labels[LITER],labels[FAT],labels[AMOUNT]);
                  }
                  strcpy(header_line,temp_buf);

                  //printer_send(uart1_fd,temp_buf,strlen(temp_buf)); 

                  PRINT_TB3;print_seperator(strlen(header_line)-6);PRINT_CR;
                  PRINT_TB3;printer_send(uart1_fd,header_line,strlen(header_line));
                  PRINT_TB3;print_seperator(strlen(header_line)-6);PRINT_CR;

               } 
              }
	     if(dpu_settings[5][10] == 'T')printer_send(uart1_fd,"*********************\r\n",23);
	     //else printer_send(uart1_fd,"-----------------------------------------------\r\n",49);

	   }

   }
   sleep(1);
   offset = (dt-1)*(2000*43) + (id*43);
   fseek(file,offset,SEEK_SET);
   printf("day_offset: %d \n",offset);

   total_lit = avg_fat = avg_snf = nrec = amt = kg_fat=kg_snf=0;
   
   
   
            memcpy(str_buf1,&dpu_settings[2][4],3);str_buf1[3]=0;      // project code
            memcpy(&str_buf1[6],&dpu_settings[2][12],4);str_buf1[10]=0; // dist code
            memcpy(&str_buf1[11],&dpu_settings[1][5],4);str_buf1[15]=0;// collect point code
            
            if(uart0_fd<=0) uart0_fd = open ("/dev/ttyS0", O_RDWR | O_NOCTTY | O_SYNC);
            set_interface_attribs (uart0_fd, B9600, 0);
            EN_GPRS;
            //--sleep(1);
            //puts(dpu_settings[4]);
         
            
   
   while(!feof(file) && id < id_max)   //scan each record for current date  for MIX/BUF
   {
      memset(buf,0,43);
      n = fread(buf, 43,1,file); buf[43]=0;

      if(buf[0] >= '0' && buf[0] <= '9' && n==1)
      {
         //if(id<1000)
         if((dpu_settings[6][8]=='Y'||dpu_settings[6][8]=='S') && id >999)  mid = id-1000;
         else mid = id;

         sprintf(tx_buf,"%4d| ",mid);//000| 012345


         //else
         //sprintf(tx_buf,"%03d|",id-1000);

         puts(buf);

         buf[15] = buf[20] = buf[25] = buf[34] = 0; buf[5]=0;// 12:23:
         total_lit +=atof(&buf[9]);
         avg_fat   =atof(&buf[16]);
         avg_snf   =atof(&buf[21]);
         amt       +=atof(&buf[26]);
         lit = atof(&buf[9]);

         amount = atof(&buf[26]);

         kg_fat += (avg_fat*atof(&buf[9]));
         kg_snf += (avg_snf*atof(&buf[9]));

        memset(name,0,16);
        fseek(fd_mm,mid*32,SEEK_SET);
        fread(name,16,1,fd_mm);         
        i=0;while(i<16){if(name[i]=='_') {name[i]=0;break;}i++; }  name[i]=0;
        //sync to server. 
        
        if(fstate <SAVE_SESSION)
        {
            sprintf(temp_buf,"%%%s/%c/%02d%02d%02d/%s/%s/%04d/%s/%c/L%05.2f%d/F%04.1f%c/S%04.1f%c/A%07.2lf/%s/R%5.2f/I%s$,G$$$CMD,GET_RATE",str_buf1,sc,dt,mt,yr,&str_buf1[6],&str_buf1[11],mid,name,type_bc,lit,buf[7],avg_fat,buf[6],avg_snf,buf[6],amount,buf,(amount/lit),IMEI);
            if(strcmp("000.000.000.000 ",dpu_settings[4])!=0   && dpu_settings[6][15]=='N')
            {
                ws_write(uart0_fd,temp_buf,strlen(temp_buf));
                //usleep(400000);//---25/09/21 sleep(1);
                puts(temp_buf);puts("\n");
            }   
        }   
         if(mode==1 && print_en)
         {
           

           if(dpu_settings[5][10] == 'T')
           {
           //buf[14] = buf[20] = buf[25] = buf[34] = ' ';

			           dirty[0]=dirty[1]=' ';
			           if(buf[6]=='1')dirty[1]='*';       //fat dirty
			           if(buf[7]=='1')dirty[0]='*';  //lit dirty
                       if(session_format==0)//#ifdef SESSION_FORMAT1
	                       {
				           if(fat_only==0)
				           {
				              sprintf(temp_buf,"%4d| %4.1f %c|%4.1f    \r\n",mid,avg_fat,dirty[1],avg_snf);
				              printer_send(uart1_fd,temp_buf,strlen(temp_buf));
				              puts(temp_buf);
				              sprintf(temp_buf,"    |%6.2f%c|%7.2f \r\n",lit,dirty[0],amount);
				              printer_send(uart1_fd,temp_buf,strlen(temp_buf));
				              puts(temp_buf);
				           }
				           else
				           {
				              sprintf(temp_buf,"%4d| %4.1f %c|        \r\n",mid,avg_fat,dirty[1]);
				              printer_send(uart1_fd,temp_buf,strlen(temp_buf));
				              sprintf(temp_buf,"    |%6.2f%c|%7.2f \r\n",lit,dirty[0],amount);
				              printer_send(uart1_fd,temp_buf,strlen(temp_buf));
				           }
						   //printer_send(uart1_fd,tx_buf,5); printer_send(uart1_fd,&buf[9],7); printer_send(uart1_fd,&buf[16],5);printer_send(uart1_fd,&buf[27],7);printer_send(uart1_fd,"\n",1);
						   //if(fat_only==0){printer_send(uart1_fd,"        |",9); printer_send(uart1_fd,&buf[21],5); printer_send(uart1_fd,"\n",1);}   // SNF

						   printer_send(uart1_fd,"\n",1);usleep(700000);// 80ms wait for printer busy
					   }
					   else
					   {
						   //sort --field-separator=','   -k2 report.csv // id,time,....
						   buf[5]=0;
                            if(fat_only==0)sprintf(temp_buf,"echo '%s %4d %6.2f%c %4.1f%c %4.1f %7.2f\n' >> /tmp/print",buf,mid,lit,dirty[0],avg_fat,dirty[1],avg_snf,amount);
                            else           sprintf(temp_buf,"echo '%s %4d %6.2f%c %4.1f%c      %7.2f\n' >> /tmp/print",buf,mid,lit,dirty[0],avg_fat,dirty[1],amount);

                            if(lit_mode==0) temp_buf[22] =' ';
						   puts(temp_buf);
						   system(temp_buf);

					   }

                    


	           }
	           else//dot-matrix
	           {
	              sprintf(str,"| %03d |",nrec+1);  
	              buf[15] = buf[20] = buf[25] = buf[34] = ' ';/*tx_buf[3]=' ';tx_buf[4]='|';tx_buf[5]=' ';*/
	              strcpy(temp_buf," | ");
	              strcpy(&temp_buf[8]," | ");

	              if(buf[7]=='1')strcpy(temp_buf,"*| ");       //lit dirty
	              if(buf[6]=='1')strcpy(&temp_buf[8],"*| ");  //fat dirty
	              PRINT_TB3;
	              printer_send(uart1_fd,str,8);printer_send(uart1_fd,tx_buf,6);printer_send(uart1_fd,&buf[9],6);printer_send(uart1_fd,temp_buf,strlen(temp_buf));  printer_send(uart1_fd,&buf[16],5);printer_send(uart1_fd,&temp_buf[8],strlen(&temp_buf[8]));
	              if(fat_only==0){printer_send(uart1_fd,&buf[21],5);printer_send(uart1_fd," |  ",4);}
	              else printer_send(uart1_fd," ",1);
	              printer_send(uart1_fd,&buf[26],8);printer_send(uart1_fd," |\n",3);

	              usleep(80000);
	              //===print_page_no(4);
	           }
         }
         if(fusb)
         {
           buf[8]=buf[15] = buf[20] = buf[25] = buf[34] = 0;

	       memset(name,0,16);
	       fseek(fd_mm,mid*32,SEEK_SET);
	       fread(name,16,1,fd_mm);
	       i=0;while(i<16){if(name[i]=='_') {name[i]=0;break;}i++; }  name[i]=0;
	       name[16]=0;


           if(dpu_settings[6][8]=='N')
           {
               sprintf(temp_buf,"M,%04d,%s,%s,%s,%s,%4.2f,%s,%s\n",mid,buf,&buf[9],&buf[16],&buf[21],(amount/lit),&buf[26],name);
           }
           else
           {
              if(type==0)sprintf(temp_buf,"B,%04d,%s,%s,%s,%s,%4.2f,%s,%s\n",mid,buf,&buf[9],&buf[16],&buf[21],(amount/lit),&buf[26],name);
              else       sprintf(temp_buf,"C,%04d,%s,%s,%s,%s,%4.2f,%s,%s\n",mid,buf,&buf[9],&buf[16],&buf[21],(amount/lit),&buf[26],name);  
           }
           write(fusb,temp_buf,strlen(temp_buf));
           puts(temp_buf);
         }

         nrec++;
      }
      
      id++;
   }
   //send sorted row to printer
   if(session_format && print_opt==1 && print_en)
   {
     system("sort  -k1 /tmp/print >> /tmp/tprint"); // -k1=sort by time      -k2=sort by id
      if(dpu_settings[5][10] == 'T') tfont_small();
	 fsort  = fopen("/tmp/tprint","r");
	 puts("#################################");
	 while(fgets(temp_buf,50,fsort))
	 {
	    if(strlen(temp_buf)>10)
	    {
	       puts(temp_buf);
	       write(uart1_fd,temp_buf,strlen(temp_buf));
	       usleep(700000);
	    }
	 }
	 puts("#################################");
	 fclose(fsort);
     if(dpu_settings[5][10] == 'T') tfont_big();


   }

   if(fd_mm) fclose(fd_mm);

   //
   if(total_lit>0)
   {
      kg_fat = (float) kg_fat/total_lit;
      kg_snf = (float) kg_snf/total_lit;
   }
   else
   {
      kg_snf=kg_fat=0;
   }
   if(fusb)
   {
            if(ws_mode==0)sprintf(temp_buf,"\nTotal Member,%d\nTotal Liter,%6.1f\nAverage Fat,%4.1f\nAverage SNF,%4.1f\nTotal Amount,%8.2f\n",nrec,total_lit,kg_fat,kg_snf,amt); 
            else          sprintf(temp_buf,"\nTotal Member,%d\nTotal Kg   ,%6.1f\nAverage Fat,%4.1f\nAverage SNF,%4.1f\nTotal Amount,%8.2f\n",nrec,total_lit,kg_fat,kg_snf,amt);
            write(fusb,temp_buf,strlen(temp_buf)); 
   }
   if(fusb) close(fusb);
   system("sync");
   if(print_en)
   {

	   if(dpu_settings[5][10] == 'T' && mode==1)printer_send(uart1_fd,"*********************\r\n",23);
	   else if(dpu_settings[5][10] == 'D'){printer_send(uart1_fd,"        ",8);
	    if(mode!=1) printer_send(uart1_fd,"----------------------\r\n",24);
	    else printer_send(uart1_fd,"-----------------------------------------------\r\n\r\n",51); 
	    }

	   
	   //===print_page_no(4);
	   if(union_index < 1)   //check if DAIRY REPORT or NOT
	   {
	       
		   if(regional==0) sprintf(buf,"Tot Mem: %3d\r\n",nrec);
		   else            sprintf(buf,"%s: %3d\r\n",labels[MEMBERS],nrec);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));

           if(session_single_dp == 1) //single point decimal enabled for session report 
           {
               
		   if(regional==0)
		   { 
		     if(ws_mode==0) sprintf(buf,"Tot Lit: %6.1f\r\n",total_lit);
		     else           sprintf(buf,"Tot Kg : %6.1f\r\n",total_lit);
		   }
                   else           sprintf(buf,"%s: %6.1f\r\n",labels[TOT_LTR],total_lit);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));

		   if(regional==0)sprintf(buf,"Avg Fat: %4.1f\r\n",kg_fat);
                   else           sprintf(buf,"%s: %4.1f\r\n",labels[AVG_FAT],kg_fat);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));
                   
                   if(fat_only==0){
		   if(regional==0)sprintf(buf,"Avg SNF: %4.1f\r\n",kg_snf); 
                   else           sprintf(buf,"%s: %4.1f\r\n",labels[AVG_SNF],kg_snf); 

           
		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));
                   }
                   
                   
           }
           else // 11/01/18  
           {
		   if(regional==0)
		   {
		     if(ws_mode==0) sprintf(buf,"Tot Lit: %6.2f\r\n",total_lit);
		     else           sprintf(buf,"Tot Kg : %6.2f\r\n",total_lit);
		   }
                   else           sprintf(buf,"%s: %6.2f\r\n",labels[TOT_LTR],total_lit);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));

		   if(regional==0)sprintf(buf,"Avg Fat: %4.2f\r\n",kg_fat);
                   else           sprintf(buf,"%s: %4.2f\r\n",labels[AVG_FAT],kg_fat);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));
                   
                   if(fat_only==0){
		   if(regional==0)sprintf(buf,"Avg SNF: %4.2f\r\n",kg_snf); 
                   else           sprintf(buf,"%s: %4.2f\r\n",labels[AVG_SNF],kg_snf); 

           
		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));
                   }
               
           }    

		   //# of can print
		   if(mode !=1 && union_index <1)//only for summery report
		   {
			   if(dpu_settings[6][8]=='Y'||dpu_settings[6][8]=='S')//cow/buf
			   {
			        if(type==0){
			        sprintf(buf,"Buf Can: %d\r\n",summery_buf_can); 
			        if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); printer_send(uart1_fd,buf,strlen(buf));
			        }
			        else{
	                sprintf(buf,"Cow Can: %d\r\n",summery_cow_can);
	                if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); printer_send(uart1_fd,buf,strlen(buf));
	                }
			   }
			   else
			   {
			        sprintf(buf,"Can    : %d\r\n",summery_buf_can); 
			        if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8); printer_send(uart1_fd,buf,strlen(buf));
			   }
		   }


		   if(regional==0)sprintf(buf,"Tot Amt: Rs. %8.2f\r\n\r\n",amt);
                   else           sprintf(buf,"%s: Rs. %8.2f\r\n\r\n",labels[TOT_AMT],amt); 
		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));



		   if((dpu_settings[6][8]=='Y'||dpu_settings[6][8]=='S') && id_max==2000)
		   {
		    PRINT_CR;PRINT_CR;

		   }
		   if(dpu_settings[6][8]=='N'){PRINT_CR;PRINT_CR;}
		   if(type == 0 && mode==1){PRINT_EJECT;print_line=0;}

		   usleep(500000);
	   }
           else // DAIRY REPORT
           {
                   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   if(regional==0)printer_send(uart1_fd,"Purchase:\r\n",11);
                   else  {printer_send(uart1_fd,labels[PURCHASE],strlen(labels[PURCHASE]));PRINT_CR;}                 

		   if(regional==0)
		   {
		     if(ws_mode==0) sprintf(buf,"Liter: %5.2f\r\n",total_lit);
		     else           sprintf(buf,"Kg   : %5.2f\r\n",total_lit);
                   }
                   else sprintf(buf,"%s: %5.2f\r\n",labels[LITER],total_lit);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));

		   if(regional==0)sprintf(buf,"Amount: %9.2f\r\n",amt);
                   else sprintf(buf,"%s: %9.2f\r\n",labels[AMOUNT],amt);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));

		   if(regional==0)sprintf(buf,"Avg Fat: %4.2f\r\n",kg_fat);
                   else           sprintf(buf,"%s: %4.2f\r\n",labels[AVG_FAT],kg_fat);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));
                   if(fat_only==0){
		   if(regional==0)sprintf(buf,"Avg SNF: %4.2f\r\n",kg_snf);
                   else sprintf(buf,"%s: %4.2f\r\n",labels[AVG_SNF],kg_snf);     
		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));
	           }

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,"---------------------\r\n",23);

                   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   if(regional==0)printer_send(uart1_fd,"LocalSale:\r\n",12);
                   else {printer_send(uart1_fd,labels[L_SALE],strlen(labels[L_SALE])); PRINT_CR;}


		   if(regional==0)
		   { 
		     if(ws_mode==0) sprintf(buf,"Lit: %7.2f\r\n",uinfo[type].local_sale);
		     else           sprintf(buf,"Kg : %7.2f\r\n",uinfo[type].local_sale);
		  }
                   else   sprintf(buf,"%s: %7.2f\r\n",labels[LITER],uinfo[type].local_sale);    

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));

		   if(regional==0)sprintf(buf,"Amt: %8.2f\r\n",uinfo[type].lamount);
                   else sprintf(buf,"%s: %8.2f\r\n",labels[AMOUNT],uinfo[type].lamount);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));

                   usleep(500000);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,"---------------------\r\n",23);

                   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   if(regional==0)printer_send(uart1_fd,"Union Sale:\r\n",13);
                   else {printer_send(uart1_fd,labels[U_SALE],strlen(labels[U_SALE])); PRINT_CR;}          

		   if(regional==0)
		   {
		     if(ws_mode==0)sprintf(buf,"Liter: %7.2f\r\n",uinfo[type].union_receipt);
		     else          sprintf(buf,"Kg   : %7.2f\r\n",uinfo[type].union_receipt); 
		   }
                   else sprintf(buf,"%s: %7.2f\r\n",labels[LITER],uinfo[type].union_receipt);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));

		   if(regional==0)sprintf(buf,"Amount: %8.2f\r\n",uinfo[type].uamount);
                   else sprintf(buf,"%s: %8.2f\r\n",labels[AMOUNT],uinfo[type].uamount);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));

		   if(regional==0)sprintf(buf,"Avg Fat: %4.2f\r\n",uinfo[type].milk_fat);
                   else sprintf(buf,"%s: %4.2f\r\n",labels[AVG_FAT],uinfo[type].milk_fat);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));
                   if(fat_only==0){  
		   if(regional==0)sprintf(buf,"Avg SNF: %4.2f\r\n",uinfo[type].milk_snf);
                   else sprintf(buf,"%s: %4.2f\r\n",labels[AVG_SNF],uinfo[type].milk_snf);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));
                   } 
                   usleep(500000); 

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,"---------------------\r\n",23);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
                   if(regional==0)printer_send(uart1_fd,"Summary\r\n",9);
                   else {printer_send(uart1_fd,labels[SUMMARY],strlen(labels[SUMMARY]));PRINT_CR;}

		   if(regional==0)sprintf(buf,"Weight: %6.2f\r\n",(uinfo[type].union_receipt+uinfo[type].local_sale)-total_lit);
                   else    sprintf(buf,"%s: %6.2f\r\n",labels[LITER],(uinfo[type].union_receipt+uinfo[type].local_sale)-total_lit);


		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));




		   if(regional==0)sprintf(buf,"Profit: %7.2f\r\n\r\n",(uinfo[type].lamount+uinfo[type].uamount)-amt);
                   else sprintf(buf,"%s: %7.2f\r\n\r\n",labels[PROFIT],(uinfo[type].lamount+uinfo[type].uamount)-amt);

		   if(dpu_settings[5][10] == 'D') printer_send(uart1_fd,"        ",8);
		   printer_send(uart1_fd,buf,strlen(buf));
           usleep(400000);

		   if((dpu_settings[6][8]=='Y'||dpu_settings[6][8]=='S') && id_max==2000)
		   {
		    PRINT_CR;PRINT_CR;


		   }
		   if(dpu_settings[6][8]=='N'){PRINT_CR;PRINT_CR;}

           }
   }
   if(regional>0) exit_regional();
   if(display_en) {
    if(session==1) strcpy(buf,"MOR");
    else           strcpy(buf,"EVN");	

    if(type == 0)  strcpy(&buf[6],"BUF");
    else           strcpy(&buf[6],"COW");
    clear_lcd();
    sprintf(temp_buf,"%02d/%02d/%02d %s %s",dt,mt,yr,buf,&buf[6]);
    lcd_puts(0,0,temp_buf);
    if(ws_mode==0) sprintf(temp_buf,"M: %3d Lt:%7.2f",nrec,total_lit);
    else           sprintf(temp_buf,"M: %3d Kg:%7.2f",nrec,total_lit); 
    lcd_puts(0,1,temp_buf);
    if(fat_only==0)sprintf(temp_buf,"F: %4.1f S:%4.1f",kg_fat,kg_snf);
    else           sprintf(temp_buf,"F: %4.1f ",kg_fat); 
    lcd_puts(0,2,temp_buf);
    sprintf(temp_buf,"AMT: Rs%8.2f",amt);
    lcd_puts(0,3,temp_buf);

    update_lcd();
    kbhit_wait();
    
    print_en = xprint_en;
   }
  
   fclose(file);
   //set_interface_attribs (uart1_fd, B2400, 0);
   if(fstate <SAVE_SESSION)sleep(5);
#ifdef PCB_V1
  PT_OFF;
#endif
   //update_lcd();
}

